import React, { useState } from 'react';
import { useAttendance } from '../context/AttendanceContext';
import { RegularizationRequest } from '../types';
import {
  FileCheck2,
  CheckCircle2,
  XCircle,
  Clock,
  Calendar,
  AlertCircle,
  Sparkles,
  Search,
  Filter,
  Check,
  X,
  MessageSquare,
  ShieldCheck,
  ExternalLink,
} from 'lucide-react';

export const ApprovalsDesk: React.FC = () => {
  const {
    regularizationRequests,
    approveRegularization,
    rejectRegularization,
    currentEmployee,
  } = useAttendance();

  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeReviewNoteId, setActiveReviewNoteId] = useState<string | null>(null);
  const [reviewNote, setReviewNote] = useState('');

  const filteredRequests = regularizationRequests.filter((req) => {
    if (filterStatus !== 'all' && req.status !== filterStatus) return false;
    if (
      searchQuery &&
      !req.employeeName.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !req.explanation.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !req.linkedCalendarEventTitle?.toLowerCase().includes(searchQuery.toLowerCase())
    ) {
      return false;
    }
    return true;
  });

  const pendingCount = regularizationRequests.filter((r) => r.status === 'pending').length;
  const approvedCount = regularizationRequests.filter((r) => r.status === 'approved').length;

  const handleApprove = (id: string) => {
    approveRegularization(id, reviewNote || undefined);
    setActiveReviewNoteId(null);
    setReviewNote('');
  };

  const handleReject = (id: string) => {
    rejectRegularization(id, reviewNote || undefined);
    setActiveReviewNoteId(null);
    setReviewNote('');
  };

  return (
    <div className="space-y-6">
      {/* Overview Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
              Pending Approvals
            </span>
            <span className="text-2xl font-extrabold text-slate-900 mt-1 block">
              {pendingCount}
            </span>
            <span className="text-[11px] text-amber-600 font-medium">
              Requires Manager Sign-Off
            </span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600">
            <Clock className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
              Regularized This Month
            </span>
            <span className="text-2xl font-extrabold text-slate-900 mt-1 block">
              {approvedCount}
            </span>
            <span className="text-[11px] text-emerald-600 font-medium">
              Calendar Cross-Checked
            </span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-600">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
              Current Approver Persona
            </span>
            <span className="text-base font-bold text-slate-900 mt-1 block truncate">
              {currentEmployee.name}
            </span>
            <span className="text-[11px] text-slate-500">
              {currentEmployee.isManager ? 'Manager Privileges Granted' : 'Employee Access Mode'}
            </span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-indigo-50 border border-indigo-200 flex items-center justify-center text-indigo-600">
            <ShieldCheck className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Main Request Table & Filter Controls */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Attendance Regularization Queue
            </h2>
            <p className="text-xs text-slate-500">
              Cross-reference calendar invites with punch records to approve or reject corrections
            </p>
          </div>

          {/* Filter Pills & Search */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search employee or meeting..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8 pr-3 py-1.5 text-xs border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
              />
            </div>

            <div className="flex items-center space-x-1 bg-slate-100 p-1 rounded-xl text-xs font-medium">
              <button
                onClick={() => setFilterStatus('all')}
                className={`px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${
                  filterStatus === 'all' ? 'bg-white text-slate-900 shadow-2xs font-semibold' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                All ({regularizationRequests.length})
              </button>
              <button
                onClick={() => setFilterStatus('pending')}
                className={`px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${
                  filterStatus === 'pending' ? 'bg-white text-slate-900 shadow-2xs font-semibold' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Pending ({pendingCount})
              </button>
              <button
                onClick={() => setFilterStatus('approved')}
                className={`px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${
                  filterStatus === 'approved' ? 'bg-white text-slate-900 shadow-2xs font-semibold' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Approved ({approvedCount})
              </button>
            </div>
          </div>
        </div>

        {/* Requests List */}
        {filteredRequests.length === 0 ? (
          <div className="text-center py-12 border border-dashed border-slate-200 rounded-2xl">
            <FileCheck2 className="w-8 h-8 text-slate-300 mx-auto mb-2" />
            <p className="text-xs font-semibold text-slate-700">No requests found</p>
            <p className="text-[11px] text-slate-400 mt-0.5">
              All attendance records for this filter criteria have been resolved.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredRequests.map((req) => (
              <div
                key={req.id}
                className="border border-slate-200 rounded-2xl p-5 hover:border-slate-300 transition-all bg-white shadow-2xs"
              >
                {/* Header: Employee Info & Status Badge */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 gap-3">
                  <div className="flex items-center space-x-3">
                    <img
                      src={req.employeeAvatar}
                      alt={req.employeeName}
                      className="w-10 h-10 rounded-full object-cover ring-2 ring-slate-100"
                    />
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-bold text-slate-900 text-sm">
                          {req.employeeName}
                        </span>
                        <span className="text-[10px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded-full font-medium">
                          {req.reasonCategory.replace('_', ' ').toUpperCase()}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-500 mt-0.5 flex items-center space-x-2">
                        <span>Discrepancy Date: <strong className="text-slate-700">{req.date}</strong></span>
                        <span>•</span>
                        <span>Submitted: {req.submittedAt}</span>
                      </div>
                    </div>
                  </div>

                  {/* Status Badge */}
                  <div>
                    {req.status === 'pending' ? (
                      <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-800 border border-amber-200">
                        <Clock className="w-3.5 h-3.5 mr-1 text-amber-600" />
                        Pending Review
                      </span>
                    ) : req.status === 'approved' ? (
                      <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                        <CheckCircle2 className="w-3.5 h-3.5 mr-1 text-emerald-600" />
                        {req.autoRegularized ? 'Auto-Regularized' : 'Approved'}
                      </span>
                    ) : (
                      <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-red-50 text-red-800 border border-red-200">
                        <XCircle className="w-3.5 h-3.5 mr-1 text-red-600" />
                        Rejected
                      </span>
                    )}
                  </div>
                </div>

                {/* Discrepancy Diff: Original Punch vs Requested Regularization */}
                <div className="my-4 grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                  {/* Original Punch */}
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80">
                    <span className="text-slate-400 font-semibold uppercase text-[10px] block mb-1">
                      Original Punch Recorded
                    </span>
                    <div className="flex items-center space-x-4 font-mono-code font-bold text-slate-800">
                      <div>
                        In: <span className="text-amber-700">{req.originalCheckIn || 'Missed Punch'}</span>
                      </div>
                      <div>
                        Out: <span>{req.originalCheckOut || 'None'}</span>
                      </div>
                    </div>
                  </div>

                  {/* Requested Regularization */}
                  <div className="p-3 bg-indigo-50/60 rounded-xl border border-indigo-200/80">
                    <span className="text-indigo-600 font-semibold uppercase text-[10px] block mb-1">
                      Requested Regularization
                    </span>
                    <div className="flex items-center space-x-4 font-mono-code font-bold text-indigo-950">
                      <div>
                        In: <span className="text-indigo-700">{req.requestedCheckIn}</span>
                      </div>
                      <div>
                        Out: <span className="text-indigo-700">{req.requestedCheckOut}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Linked Calendar Evidence Callout */}
                {req.linkedCalendarEventTitle && (
                  <div className="mb-4 p-3.5 bg-emerald-50/80 border border-emerald-200 rounded-xl text-xs text-slate-700">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-emerald-900 flex items-center">
                        <Sparkles className="w-3.5 h-3.5 mr-1.5 text-emerald-600" />
                        Verified Calendar Event Proof
                      </span>
                      <span className="text-[10px] font-semibold text-emerald-700 bg-white px-2 py-0.5 rounded-full border border-emerald-200">
                        Google Workspace Calendar
                      </span>
                    </div>
                    <p className="font-semibold text-slate-900">
                      &ldquo;{req.linkedCalendarEventTitle}&rdquo;
                    </p>
                    {req.calendarProofSnippet && (
                      <p className="text-[11px] text-slate-600 mt-1 font-mono-code">
                        {req.calendarProofSnippet}
                      </p>
                    )}
                  </div>
                )}

                {/* Explanation text */}
                <div className="text-xs text-slate-600 bg-slate-50/50 p-3 rounded-xl border border-slate-100">
                  <span className="font-bold text-slate-800 block mb-0.5">
                    Employee Note:
                  </span>
                  <p>{req.explanation}</p>
                </div>

                {/* Review Details if already reviewed */}
                {req.reviewedBy && (
                  <div className="mt-3 pt-3 border-t border-slate-100 text-[11px] text-slate-500 flex flex-wrap items-center justify-between gap-2">
                    <div>
                      Reviewed by: <strong className="text-slate-700">{req.reviewedBy}</strong> on {req.reviewedAt}
                    </div>
                    {req.reviewerNotes && (
                      <div className="italic text-slate-600">
                        &ldquo;{req.reviewerNotes}&rdquo;
                      </div>
                    )}
                  </div>
                )}

                {/* Manager Actions if Pending */}
                {req.status === 'pending' && (
                  <div className="mt-4 pt-3 border-t border-slate-100 space-y-2">
                    {activeReviewNoteId === req.id ? (
                      <div className="space-y-2">
                        <textarea
                          placeholder="Optional reviewer comment (e.g. Verified with client meeting invite)..."
                          value={reviewNote}
                          onChange={(e) => setReviewNote(e.target.value)}
                          className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20"
                          rows={2}
                        />
                        <div className="flex justify-end space-x-2">
                          <button
                            onClick={() => {
                              setActiveReviewNoteId(null);
                              setReviewNote('');
                            }}
                            className="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
                          >
                            Cancel
                          </button>
                          <button
                            onClick={() => handleReject(req.id)}
                            className="px-3 py-1.5 text-xs font-semibold bg-red-600 hover:bg-red-700 text-white rounded-lg cursor-pointer"
                          >
                            Confirm Reject
                          </button>
                          <button
                            onClick={() => handleApprove(req.id)}
                            className="px-4 py-1.5 text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg cursor-pointer"
                          >
                            Confirm Approve
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="flex flex-wrap items-center justify-end gap-2">
                        <button
                          onClick={() => setActiveReviewNoteId(req.id)}
                          className="inline-flex items-center px-3 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors cursor-pointer"
                        >
                          <MessageSquare className="w-3.5 h-3.5 mr-1 text-slate-400" />
                          Add Reviewer Note
                        </button>
                        <button
                          onClick={() => rejectRegularization(req.id)}
                          className="inline-flex items-center px-3 py-1.5 text-xs font-semibold text-red-700 bg-red-50 hover:bg-red-100 border border-red-200 rounded-xl transition-colors cursor-pointer"
                        >
                          <X className="w-3.5 h-3.5 mr-1" />
                          Reject
                        </button>
                        <button
                          onClick={() => approveRegularization(req.id)}
                          className="inline-flex items-center px-4 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs transition-colors cursor-pointer"
                        >
                          <Check className="w-3.5 h-3.5 mr-1" />
                          Approve with Calendar Evidence
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
