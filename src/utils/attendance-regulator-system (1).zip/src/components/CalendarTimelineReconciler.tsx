import React, { useState, useMemo } from 'react';
import { useAttendance } from '../context/AttendanceContext';
import { CalendarEvent, CalendarEventType } from '../types';
import {
  Calendar,
  Clock,
  Plus,
  RefreshCw,
  Users,
  MapPin,
  CheckCircle2,
  AlertTriangle,
  ExternalLink,
  Sparkles,
  Layers,
  ChevronLeft,
  ChevronRight,
  FileSpreadsheet,
} from 'lucide-react';

interface CalendarTimelineReconcilerProps {
  onOpenRegularizationModal: (presetDate?: string, calendarEventId?: string) => void;
}

export const CalendarTimelineReconciler: React.FC<CalendarTimelineReconcilerProps> = ({
  onOpenRegularizationModal,
}) => {
  const {
    currentEmployee,
    calendarEvents,
    addCalendarEvent,
    syncGoogleCalendarFeed,
    checkInRecords,
    currentTime,
  } = useAttendance();

  const [selectedDate, setSelectedDate] = useState<string>(() => {
    return currentTime.toISOString().split('T')[0];
  });
  const [showAddEventModal, setShowAddEventModal] = useState(false);
  const [syncingGoogle, setSyncingGoogle] = useState(false);

  // New Event Form State
  const [newEventTitle, setNewEventTitle] = useState('');
  const [newEventStart, setNewEventStart] = useState('10:00');
  const [newEventEnd, setNewEventEnd] = useState('11:00');
  const [newEventType, setNewEventType] = useState<CalendarEventType>('client_meeting');
  const [newEventLocation, setNewEventLocation] = useState('');
  const [newEventAttendees, setNewEventAttendees] = useState('');
  const [newEventDesc, setNewEventDesc] = useState('');

  // Events filtered for current employee and selected date
  const employeeEvents = useMemo(() => {
    return calendarEvents
      .filter((ev) => ev.employeeId === currentEmployee.id && ev.date === selectedDate)
      .sort((a, b) => a.startTime.localeCompare(b.startTime));
  }, [calendarEvents, currentEmployee.id, selectedDate]);

  // Check-in record for selected date
  const selectedDateRecord = useMemo(() => {
    return checkInRecords.find(
      (r) => r.employeeId === currentEmployee.id && r.date === selectedDate
    );
  }, [checkInRecords, currentEmployee.id, selectedDate]);

  // Handle Google Calendar live sync
  const handleSyncGCal = () => {
    setSyncingGoogle(true);
    setTimeout(() => {
      syncGoogleCalendarFeed(currentEmployee.id);
      setSyncingGoogle(false);
    }, 600);
  };

  // Handle Add Calendar Event submission
  const handleCreateEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEventTitle) return;

    addCalendarEvent({
      employeeId: currentEmployee.id,
      title: newEventTitle,
      description: newEventDesc,
      startTime: newEventStart,
      endTime: newEventEnd,
      date: selectedDate,
      type: newEventType,
      location: newEventLocation || 'Virtual Meeting',
      isExternal: newEventType === 'client_meeting' || newEventType === 'offsite',
      attendees: newEventAttendees
        ? newEventAttendees.split(',').map((s) => s.trim())
        : [currentEmployee.email],
      source: 'manual',
    });

    setNewEventTitle('');
    setNewEventDesc('');
    setShowAddEventModal(false);
  };

  // Convert "HH:mm" to percentage position for timeline (from 08:00 to 19:00 = 11 hours = 660 mins)
  const timelineStartHour = 8;
  const timelineEndHour = 19;
  const totalTimelineMinutes = (timelineEndHour - timelineStartHour) * 60; // 660 mins

  const getPositionPercent = (timeStr: string) => {
    const [h, m] = timeStr.split(':').map(Number);
    const minutesFromStart = (h - timelineStartHour) * 60 + m;
    const clamped = Math.max(0, Math.min(totalTimelineMinutes, minutesFromStart));
    return (clamped / totalTimelineMinutes) * 100;
  };

  const getDurationPercent = (startStr: string, endStr: string) => {
    const [sH, sM] = startStr.split(':').map(Number);
    const [eH, eM] = endStr.split(':').map(Number);
    const sMin = (sH - timelineStartHour) * 60 + sM;
    const eMin = (eH - timelineStartHour) * 60 + eM;
    const dur = Math.max(15, eMin - sMin);
    return (dur / totalTimelineMinutes) * 100;
  };

  // Hours ticks
  const hourTicks = Array.from(
    { length: timelineEndHour - timelineStartHour + 1 },
    (_, i) => timelineStartHour + i
  );

  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-6">
      {/* Calendar Header with Date Navigation & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-5 border-b border-slate-100 gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <h2 className="text-base font-bold text-slate-900">
              Employee Calendar & Attendance Reconciler
            </h2>
            <span className="px-2 py-0.5 rounded-full text-[11px] font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200">
              Synced
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Cross-references scheduled meetings with physical & remote check-in intervals
          </p>
        </div>

        {/* Date Selector & Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Date Picker Input */}
          <div className="flex items-center space-x-1.5 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5">
            <Calendar className="w-3.5 h-3.5 text-slate-500" />
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="text-xs font-semibold text-slate-800 bg-transparent focus:outline-hidden"
            />
          </div>

          {/* Sync GCal Button */}
          <button
            onClick={handleSyncGCal}
            disabled={syncingGoogle}
            className="inline-flex items-center px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
            title="Fetch latest meetings from Google Calendar feed"
          >
            <RefreshCw className={`w-3.5 h-3.5 mr-1.5 ${syncingGoogle ? 'animate-spin text-indigo-600' : ''}`} />
            <span>Sync Google Cal</span>
          </button>

          {/* Add Event Button */}
          <button
            onClick={() => setShowAddEventModal(true)}
            className="inline-flex items-center px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5 mr-1" />
            <span>Add Meeting</span>
          </button>
        </div>
      </div>

      {/* Visual Timeline Section: 08:00 - 19:00 */}
      <div>
        <div className="flex items-center justify-between mb-3 text-xs font-semibold text-slate-600">
          <span>Day Timeline (08:00 AM – 07:00 PM)</span>
          <div className="flex items-center space-x-4 text-[11px]">
            <span className="flex items-center">
              <span className="w-2.5 h-2.5 rounded-sm bg-indigo-200 mr-1.5" />
              Official Shift
            </span>
            <span className="flex items-center">
              <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500 mr-1.5" />
              Calendar Events
            </span>
            <span className="flex items-center">
              <span className="w-2.5 h-2.5 rounded-sm bg-blue-600 mr-1.5" />
              Actual Check-In
            </span>
            <span className="flex items-center">
              <span className="w-2.5 h-2.5 rounded-sm bg-amber-400 mr-1.5" />
              Breaks
            </span>
          </div>
        </div>

        {/* Timeline Tracks Container */}
        <div className="bg-slate-50/70 border border-slate-200 rounded-2xl p-4 sm:p-5 relative overflow-x-auto">
          {/* Hour Axis Markers */}
          <div className="relative h-6 border-b border-slate-200 mb-3 text-[11px] font-mono-code text-slate-400 select-none">
            {hourTicks.map((hour) => {
              const pct = ((hour - timelineStartHour) / (timelineEndHour - timelineStartHour)) * 100;
              return (
                <div
                  key={hour}
                  className="absolute -translate-x-1/2"
                  style={{ left: `${pct}%` }}
                >
                  {hour < 12 ? `${hour}am` : hour === 12 ? '12pm' : `${hour - 12}pm`}
                </div>
              );
            })}
          </div>

          {/* Track 1: Shift Baseline Track */}
          <div className="mb-4">
            <div className="text-[11px] font-medium text-slate-500 mb-1 flex items-center justify-between">
              <span>Shift Schedule (Standard 09:00 – 18:00)</span>
              <span className="text-[10px] text-slate-400">Core Hours: 10:00 - 16:00</span>
            </div>
            <div className="relative h-8 bg-slate-200/60 rounded-lg overflow-hidden border border-slate-300/40">
              {/* Shift Band */}
              <div
                className="absolute top-0 bottom-0 bg-indigo-100/90 border border-indigo-300/60 rounded-md flex items-center px-2 text-[11px] font-semibold text-indigo-900"
                style={{
                  left: `${getPositionPercent('09:00')}%`,
                  width: `${getDurationPercent('09:00', '18:00')}%`,
                }}
              >
                {/* Grace Period Strip */}
                <div
                  className="absolute top-0 bottom-0 left-0 bg-emerald-100 border-r border-emerald-300 flex items-center px-1 text-[9px] font-bold text-emerald-800"
                  style={{ width: `${getDurationPercent('09:00', '09:15')}%` }}
                  title="15-minute arrival grace period"
                >
                  Grace
                </div>
                <span className="ml-10 hidden sm:inline">Official Work Window (09:00 - 18:00)</span>
              </div>
            </div>
          </div>

          {/* Track 2: Synced Calendar Events Track */}
          <div className="mb-4">
            <div className="text-[11px] font-medium text-slate-500 mb-1 flex items-center justify-between">
              <span>Synced Calendar Schedule ({employeeEvents.length} events)</span>
              <span className="text-[10px] text-emerald-700 font-medium">Google Workspace & Meetings</span>
            </div>
            <div className="relative h-11 bg-slate-200/50 rounded-lg border border-slate-300/40 overflow-hidden">
              {employeeEvents.length === 0 ? (
                <div className="h-full flex items-center justify-center text-xs text-slate-400 italic">
                  No scheduled calendar meetings on this day
                </div>
              ) : (
                employeeEvents.map((ev) => {
                  const left = getPositionPercent(ev.startTime);
                  const width = getDurationPercent(ev.startTime, ev.endTime);
                  const isExternal = ev.isExternal;

                  return (
                    <div
                      key={ev.id}
                      className={`absolute top-1 bottom-1 rounded-md px-2 flex items-center justify-between text-xs font-semibold shadow-2xs border overflow-hidden cursor-pointer hover:brightness-95 transition-all ${
                        isExternal
                          ? 'bg-emerald-500 text-white border-emerald-600'
                          : 'bg-indigo-500 text-white border-indigo-600'
                      }`}
                      style={{ left: `${left}%`, width: `${width}%` }}
                      title={`${ev.title} (${ev.startTime} - ${ev.endTime}) - ${ev.location || 'Virtual'}`}
                    >
                      <span className="truncate text-[11px]">
                        {ev.startTime} {ev.title}
                      </span>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Track 3: Actual Punch Interval & Breaks Track */}
          <div>
            <div className="text-[11px] font-medium text-slate-500 mb-1 flex items-center justify-between">
              <span>Actual Check-In & Physical / Remote Presence</span>
              {selectedDateRecord && (
                <span
                  className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                    selectedDateRecord.regularityStatus === 'compliant'
                      ? 'bg-emerald-50 text-emerald-700'
                      : selectedDateRecord.regularityStatus === 'regularized'
                      ? 'bg-blue-50 text-blue-700'
                      : 'bg-amber-50 text-amber-700'
                  }`}
                >
                  Status: {selectedDateRecord.regularityStatus.toUpperCase()}
                </span>
              )}
            </div>
            <div className="relative h-11 bg-slate-200/50 rounded-lg border border-slate-300/40 overflow-hidden">
              {!selectedDateRecord ? (
                <div className="h-full flex items-center justify-center text-xs text-slate-400 italic">
                  No check-in recorded for this date
                </div>
              ) : (
                <>
                  {/* Punch Span */}
                  <div
                    className={`absolute top-1 bottom-1 rounded-md border flex items-center px-2 text-xs font-semibold text-white shadow-2xs ${
                      selectedDateRecord.regularityStatus === 'irregular'
                        ? 'bg-amber-600 border-amber-700'
                        : selectedDateRecord.regularityStatus === 'regularized'
                        ? 'bg-blue-600 border-blue-700'
                        : 'bg-indigo-600 border-indigo-700'
                    }`}
                    style={{
                      left: `${getPositionPercent(selectedDateRecord.checkInTime.slice(0, 5))}%`,
                      width: `${getDurationPercent(
                        selectedDateRecord.checkInTime.slice(0, 5),
                        selectedDateRecord.checkOutTime
                          ? selectedDateRecord.checkOutTime.slice(0, 5)
                          : `${currentTime.getHours()}:${currentTime.getMinutes()}`
                      )}%`,
                    }}
                  >
                    <span className="truncate text-[11px]">
                      Checked In: {selectedDateRecord.checkInTime.slice(0, 5)}{' '}
                      {selectedDateRecord.checkOutTime
                        ? `– ${selectedDateRecord.checkOutTime.slice(0, 5)}`
                        : '(Active)'}
                    </span>
                  </div>

                  {/* Render Breaks inside Punch */}
                  {selectedDateRecord.breaks.map((b) => (
                    <div
                      key={b.id}
                      className="absolute top-1 bottom-1 bg-amber-400 border border-amber-500 rounded text-[10px] text-amber-950 font-bold flex items-center justify-center"
                      style={{
                        left: `${getPositionPercent(b.startTime.slice(0, 5))}%`,
                        width: `${getDurationPercent(
                          b.startTime.slice(0, 5),
                          b.endTime ? b.endTime.slice(0, 5) : `${currentTime.getHours()}:${currentTime.getMinutes()}`
                        )}%`,
                      }}
                      title={`${b.type} break`}
                    >
                      ☕
                    </div>
                  ))}
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Reconciled Discrepancy Highlight Card */}
      {selectedDateRecord && selectedDateRecord.regularityStatus === 'irregular' && (
        <div className="bg-amber-50/90 border border-amber-200 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start space-x-3">
            <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <p className="text-xs font-bold text-slate-900">
                Attendance Discrepancy Reconciliation Opportunity
              </p>
              <p className="text-xs text-slate-600 mt-0.5">
                Check-in occurred at{' '}
                <strong className="text-slate-800">
                  {selectedDateRecord.checkInTime.slice(0, 5)}
                </strong>
                . Calendar analysis shows you had scheduled meetings that overlap with standard shift start.
              </p>
            </div>
          </div>

          <button
            onClick={() => onOpenRegularizationModal(selectedDate)}
            className="inline-flex items-center justify-center px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors shrink-0 cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 mr-1.5" />
            Regularize with Calendar Evidence
          </button>
        </div>
      )}

      {/* Calendar Events List for the Day */}
      <div>
        <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3">
          Scheduled Calendar Events ({employeeEvents.length})
        </h3>

        {employeeEvents.length === 0 ? (
          <div className="p-6 text-center border border-dashed border-slate-200 rounded-xl text-slate-400 text-xs">
            No calendar events found for {selectedDate}. Click &ldquo;Add Meeting&rdquo; or &ldquo;Sync Google Cal&rdquo;.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {employeeEvents.map((ev) => (
              <div
                key={ev.id}
                className="p-3.5 rounded-xl border border-slate-200 bg-white hover:border-slate-300 transition-all flex flex-col justify-between space-y-2.5"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <span
                      className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold mb-1 ${
                        ev.isExternal
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                      }`}
                    >
                      {ev.isExternal ? 'External / Client' : 'Internal Team'}
                    </span>
                    <h4 className="text-xs font-bold text-slate-900 leading-snug">
                      {ev.title}
                    </h4>
                  </div>
                  <div className="text-right font-mono-code text-[11px] font-bold text-slate-700 shrink-0">
                    {ev.startTime} – {ev.endTime}
                  </div>
                </div>

                {ev.description && (
                  <p className="text-[11px] text-slate-500 line-clamp-2">
                    {ev.description}
                  </p>
                )}

                <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-[11px] text-slate-500">
                  <div className="flex items-center space-x-1.5 truncate">
                    <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                    <span className="truncate">{ev.location || 'Virtual Meeting'}</span>
                  </div>

                  {/* Regularization Link Action */}
                  <button
                    onClick={() => onOpenRegularizationModal(selectedDate, ev.id)}
                    className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 hover:underline shrink-0 ml-2 cursor-pointer"
                  >
                    Use as Regularization Proof ➔
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add Calendar Event Modal */}
      {showAddEventModal && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-4">
              <h3 className="text-sm font-bold text-slate-900 flex items-center">
                <Calendar className="w-4 h-4 mr-1.5 text-indigo-600" />
                Add Calendar Event
              </h3>
              <button
                onClick={() => setShowAddEventModal(false)}
                className="text-slate-400 hover:text-slate-600 text-lg leading-none cursor-pointer"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleCreateEvent} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Meeting Title
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Client Technical Requirement Workshop"
                  value={newEventTitle}
                  onChange={(e) => setNewEventTitle(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Start Time
                  </label>
                  <input
                    type="time"
                    required
                    value={newEventStart}
                    onChange={(e) => setNewEventStart(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 font-mono-code"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    End Time
                  </label>
                  <input
                    type="time"
                    required
                    value={newEventEnd}
                    onChange={(e) => setNewEventEnd(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 font-mono-code"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Event Category
                </label>
                <select
                  value={newEventType}
                  onChange={(e) => setNewEventType(e.target.value as CalendarEventType)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                >
                  <option value="client_meeting">External Client Meeting (Auto-Regularize Eligible)</option>
                  <option value="internal_meeting">Internal Team Sync</option>
                  <option value="offsite">Offsite / Customer Site Visit</option>
                  <option value="interview">Candidate Interview</option>
                  <option value="travel">Business Travel / Transit</option>
                  <option value="focus_work">Deep Focus Work</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Location / Conference Room
                </label>
                <input
                  type="text"
                  placeholder="e.g. Acme HQ, 450 Mission St or Google Meet"
                  value={newEventLocation}
                  onChange={(e) => setNewEventLocation(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Attendees (comma-separated emails)
                </label>
                <input
                  type="text"
                  placeholder="client@partner.com, manager@nexuscorp.io"
                  value={newEventAttendees}
                  onChange={(e) => setNewEventAttendees(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddEventModal(false)}
                  className="px-4 py-2 border border-slate-200 text-slate-600 rounded-xl hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl cursor-pointer"
                >
                  Save Meeting
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
