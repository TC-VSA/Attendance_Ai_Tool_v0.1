import React from 'react';

interface TalentCarriageLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'hero';
  showTagline?: boolean;
  variant?: 'light' | 'dark';
}

export const TalentCarriageLogo: React.FC<TalentCarriageLogoProps> = ({
  className = '',
  size = 'md',
  showTagline = true,
  variant = 'light',
}) => {
  const iconSizes = {
    sm: 'w-7 h-7',
    md: 'w-10 h-10',
    lg: 'w-12 h-12',
    hero: 'w-16 h-16',
  };

  const textStyles = {
    sm: {
      brand: 'text-sm',
      sub: 'text-[8px]',
      gap: 'space-x-2',
    },
    md: {
      brand: 'text-base',
      sub: 'text-[9.5px]',
      gap: 'space-x-2.5',
    },
    lg: {
      brand: 'text-xl',
      sub: 'text-[11px]',
      gap: 'space-x-3',
    },
    hero: {
      brand: 'text-2xl',
      sub: 'text-xs',
      gap: 'space-x-3.5',
    },
  };

  const currentStyle = textStyles[size];

  return (
    <div className={`flex items-center ${currentStyle.gap} ${className}`}>
      {/* Precision 3D Vector Sphere matching TC Logo 4d */}
      <svg
        className={`${iconSizes[size]} shrink-0 drop-shadow-md select-none`}
        viewBox="0 0 160 160"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          {/* Cyan/Teal Gradient for Top Segments */}
          <linearGradient id="tcTealGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#2CE8D5" />
            <stop offset="45%" stopColor="#00C4B4" />
            <stop offset="100%" stopColor="#088E9B" />
          </linearGradient>

          {/* Mint Highlight for Layer Peaks */}
          <linearGradient id="tcMintGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#6EE7B7" />
            <stop offset="100%" stopColor="#14B8A6" />
          </linearGradient>

          {/* Copper / Warm Specular Reflection Band */}
          <linearGradient id="tcCopperGrad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#87584A" />
            <stop offset="25%" stopColor="#DC9E88" />
            <stop offset="50%" stopColor="#FBD7C7" />
            <stop offset="75%" stopColor="#DC9E88" />
            <stop offset="100%" stopColor="#7E4A3B" />
          </linearGradient>

          {/* Royal Blue Bottom Hemisphere */}
          <linearGradient id="tcBlueGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#1D65EA" />
            <stop offset="60%" stopColor="#1251CD" />
            <stop offset="100%" stopColor="#083896" />
          </linearGradient>

          {/* Subtle 3D Inner Sphere Shadow */}
          <radialGradient id="tcSphereShade" cx="40%" cy="35%" r="65%">
            <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.4" />
            <stop offset="60%" stopColor="#000000" stopOpacity="0" />
            <stop offset="100%" stopColor="#000000" stopOpacity="0.35" />
          </radialGradient>
        </defs>

        {/* Base Sphere Container with 3D Clip */}
        <g>
          {/* Top Layer 1: Dome Cap */}
          <path
            d="M 50 24 Q 80 12 110 24 Q 80 18 50 24 Z"
            fill="url(#tcTealGrad)"
          />
          <ellipse cx="80" cy="20" rx="26" ry="7" fill="url(#tcMintGrad)" />

          {/* Top Slices (Teal & Cyan Layered Bands) */}
          <ellipse cx="80" cy="31" rx="44" ry="8" fill="#0C737E" />
          <ellipse cx="80" cy="29" rx="42" ry="7" fill="url(#tcTealGrad)" />

          <ellipse cx="80" cy="42" rx="55" ry="9" fill="#0A5B64" />
          <ellipse cx="80" cy="40" rx="53" ry="8" fill="url(#tcMintGrad)" />

          <ellipse cx="80" cy="54" rx="63" ry="10" fill="#0C737E" />
          <ellipse cx="80" cy="51" rx="61" ry="9" fill="url(#tcTealGrad)" />

          <ellipse cx="80" cy="66" rx="68" ry="10" fill="#084950" />
          <ellipse cx="80" cy="63" rx="66" ry="9" fill="url(#tcTealGrad)" />

          {/* Copper Metallic Specular Band */}
          <ellipse cx="80" cy="74" rx="70" ry="10" fill="url(#tcCopperGrad)" />

          {/* Bottom Royal Blue Hemisphere */}
          <path
            d="M 10 74 A 70 70 0 0 0 150 74 Z"
            fill="url(#tcBlueGrad)"
          />

          {/* Divider Highlight Ring */}
          <ellipse cx="80" cy="74" rx="70" ry="4" fill="#60A5FA" fillOpacity="0.4" />

          {/* Overlay Sphere Shadow */}
          <circle cx="80" cy="80" r="70" fill="url(#tcSphereShade)" />
        </g>
      </svg>

      {/* Brand Typography */}
      <div className="flex flex-col select-none leading-none">
        <div className={`font-black tracking-tight flex items-baseline space-x-1 ${currentStyle.brand}`}>
          <span className="text-[#00C4B4] drop-shadow-xs">Talent</span>
          <span className="text-[#1D5BD8] drop-shadow-xs">Carriage</span>
        </div>
        {showTagline && (
          <span
            className={`font-extrabold tracking-wider uppercase mt-1 ${
              variant === 'dark' ? 'text-[#BFD6E1]' : 'text-[#1D5BD8]'
            } ${currentStyle.sub}`}
          >
            Imagine Innovate Transform
          </span>
        )}
      </div>
    </div>
  );
};
