import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  MessageSquare,
  Clock,
  PhoneCall,
  CheckCircle2,
  ExternalLink,
  ChevronRight,
  MoreVertical,
  AlertCircle,
  HelpCircle,
  User,
} from 'lucide-react';
import { useAttendance } from '../context/AttendanceContext';
import { FollowUpCase, FollowUpStatus } from '../types';

interface CasesTableViewProps {
  onOpenWhatsApp: (caseId: string) => void;
  onOpenCallCenter: (caseId: string) => void;
}

export const CasesTableView: React.FC<CasesTableViewProps> = ({
  onOpenWhatsApp,
  onOpenCallCenter,
}) => {
  const {
    followUpCases,
    selectedCaseId,
    setSelectedCaseId,
    sendFirstWhatsApp,
    sendTwoDayReminder,
    markCaseVerified,
  } = useAttendance();

  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<string>('all');

  // Filter cases based on search and tab
  const filteredCases = useMemo(() => {
    return followUpCases.filter((c) => {
      const q = searchQuery.toLowerCase();
      const matchesSearch =
        c.employeeName.toLowerCase().includes(q) ||
        (c.employeeCode && c.employeeCode.toLowerCase().includes(q)) ||
        c.department.toLowerCase().includes(q) ||
        c.reportingManager.toLowerCase().includes(q) ||
        c.date.toLowerCase().includes(q);

      if (!matchesSearch) return false;

      if (activeFilter === 'all') return true;
      if (activeFilter === 'waiting') return c.status === 'waiting' || c.status === 'sent';
      if (activeFilter === 'leave') return c.status === 'pending-leave';
      if (activeFilter === 'regularization') return c.status === 'pending-regularization';
      if (activeFilter === 'call')
        return c.status === 'call-required' || c.status === 'hr-escalated' || c.stage === 'stage_3_call';
      if (activeFilter === 'verification') return c.status === 'verification';
      if (activeFilter === 'done') return c.status === 'verified';

      return true;
    });
  }, [followUpCases, searchQuery, activeFilter]);

  const getStatusBadge = (status: FollowUpStatus) => {
    switch (status) {
      case 'waiting':
      case 'sent':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-amber-100 text-amber-800 border border-amber-200">
            Waiting reply
          </span>
        );
      case 'pending-leave':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-blue-100 text-blue-800 border border-blue-200">
            Pending leave
          </span>
        );
      case 'pending-regularization':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-indigo-100 text-indigo-800 border border-indigo-200">
            Pending regularization
          </span>
        );
      case 'call-required':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-rose-100 text-rose-800 border border-rose-200 animate-pulse">
            Call required
          </span>
        );
      case 'hr-escalated':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-purple-100 text-purple-800 border border-purple-200">
            HR Escalated
          </span>
        );
      case 'verification':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-cyan-100 text-cyan-800 border border-cyan-200">
            Verification
          </span>
        );
      case 'verified':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
            Verified & Done
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-slate-100 text-slate-700">
            {status}
          </span>
        );
    }
  };

  return (
    <div className="space-y-4">
      {/* Controls Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            id="cases-search-input"
            type="text"
            placeholder="Search by employee name, code, dept, manager..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-4 py-2 text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500"
          />
        </div>

        {/* Filter Tabs */}
        <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 md:pb-0 text-xs">
          {[
            { id: 'all', label: 'All Cases', count: followUpCases.length },
            {
              id: 'waiting',
              label: 'Waiting',
              count: followUpCases.filter((c) => c.status === 'waiting' || c.status === 'sent').length,
            },
            {
              id: 'leave',
              label: 'Leave Needed',
              count: followUpCases.filter((c) => c.status === 'pending-leave').length,
            },
            {
              id: 'regularization',
              label: 'Regularization',
              count: followUpCases.filter((c) => c.status === 'pending-regularization').length,
            },
            {
              id: 'call',
              label: 'Call Required',
              count: followUpCases.filter(
                (c) => c.status === 'call-required' || c.status === 'hr-escalated'
              ).length,
            },
            {
              id: 'done',
              label: 'Closed',
              count: followUpCases.filter((c) => c.status === 'verified').length,
            },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveFilter(tab.id)}
              className={`px-3 py-1.5 rounded-lg font-bold shrink-0 transition flex items-center space-x-1.5 ${
                activeFilter === tab.id
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              <span>{tab.label}</span>
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                  activeFilter === tab.id
                    ? 'bg-white/20 text-white'
                    : 'bg-slate-200 text-slate-700'
                }`}
              >
                {tab.count}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Cases Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-[#073B5C] text-[#BFD6E1] text-[10px] uppercase font-bold tracking-wider">
              <tr>
                <th className="py-3 px-4">Employee</th>
                <th className="py-3 px-3">Date</th>
                <th className="py-3 px-3">Code</th>
                <th className="py-3 px-3">Reply</th>
                <th className="py-3 px-3">Action Required</th>
                <th className="py-3 px-3">Case Status</th>
                <th className="py-3 px-4 text-right">Next Step</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredCases.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400">
                    No cases match the selected search or filter criteria.
                  </td>
                </tr>
              ) : (
                filteredCases.map((c) => {
                  const isSelected = c.id === selectedCaseId;
                  const isCallReq = c.status === 'call-required' || c.stage === 'stage_3_call';

                  return (
                    <tr
                      key={c.id}
                      onClick={() => setSelectedCaseId(c.id)}
                      className={`cursor-pointer transition ${
                        isSelected ? 'bg-teal-50/70 font-medium' : 'hover:bg-slate-50/80'
                      }`}
                    >
                      {/* Employee name & sub info */}
                      <td className="py-3 px-4">
                        <div className="flex items-center space-x-2.5">
                          <div className="w-8 h-8 rounded-full bg-slate-100 text-slate-700 font-bold flex items-center justify-center text-xs shrink-0 border border-slate-200">
                            {c.employeeName.charAt(0)}
                          </div>
                          <div>
                            <div className="font-black text-slate-900 leading-tight">
                              {c.employeeName}
                            </div>
                            <div className="text-[11px] text-slate-500 font-medium mt-0.5">
                              {c.department} · Mgr: {c.reportingManager}
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Absent date */}
                      <td className="py-3 px-3 font-mono font-semibold text-slate-700 whitespace-nowrap">
                        {c.date}
                      </td>

                      {/* Session Code */}
                      <td className="py-3 px-3 whitespace-nowrap">
                        <span
                          className={`font-mono font-bold text-[11px] px-2 py-0.5 rounded ${
                            c.code === 'A|A'
                              ? 'bg-rose-100 text-rose-800 border border-rose-200'
                              : 'bg-amber-100 text-amber-800 border border-amber-200'
                          }`}
                        >
                          {c.code}
                        </span>
                      </td>

                      {/* Reply */}
                      <td className="py-3 px-3 max-w-[200px] truncate text-slate-700">
                        <span
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedCaseId(c.id);
                            onOpenWhatsApp(c.id);
                          }}
                          className="hover:text-teal-700 hover:underline cursor-pointer inline-flex items-center gap-1"
                        >
                          {c.reply}
                          {c.replyType === 'button' && (
                            <span className="text-[9px] bg-slate-100 text-slate-600 px-1 rounded">
                              Quick
                            </span>
                          )}
                        </span>
                      </td>

                      {/* Action Required */}
                      <td className="py-3 px-3 text-slate-800 font-semibold max-w-[180px] truncate">
                        {c.action}
                      </td>

                      {/* Case Status */}
                      <td className="py-3 px-3 whitespace-nowrap">
                        {getStatusBadge(c.status)}
                      </td>

                      {/* Next Step Action Button */}
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        {isCallReq ? (
                          <button
                            id={`call-case-btn-${c.id}`}
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedCaseId(c.id);
                              onOpenCallCenter(c.id);
                            }}
                            className="inline-flex items-center space-x-1.5 bg-rose-600 hover:bg-rose-500 text-white px-3 py-1.5 rounded-lg text-xs font-bold transition shadow-xs"
                          >
                            <PhoneCall className="w-3.5 h-3.5" />
                            <span>Call Now</span>
                          </button>
                        ) : c.status === 'verification' ? (
                          <button
                            id={`verify-case-btn-${c.id}`}
                            onClick={(e) => {
                              e.stopPropagation();
                              markCaseVerified(c.id);
                            }}
                            className="inline-flex items-center space-x-1.5 bg-emerald-600 hover:bg-emerald-500 text-white px-3 py-1.5 rounded-lg text-xs font-bold transition shadow-xs"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Verify HRMS</span>
                          </button>
                        ) : c.status === 'verified' ? (
                          <span className="text-emerald-700 font-bold text-xs inline-flex items-center gap-1">
                            <CheckCircle2 className="w-4 h-4" />
                            <span>Closed</span>
                          </span>
                        ) : (
                          <button
                            id={`wa-case-btn-${c.id}`}
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedCaseId(c.id);
                              onOpenWhatsApp(c.id);
                            }}
                            className="inline-flex items-center space-x-1.5 bg-teal-700 hover:bg-teal-600 text-white px-3 py-1.5 rounded-lg text-xs font-bold transition shadow-xs"
                          >
                            <MessageSquare className="w-3.5 h-3.5" />
                            <span>WhatsApp</span>
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
