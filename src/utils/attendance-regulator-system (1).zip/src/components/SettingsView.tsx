import React, { useState, useEffect } from 'react';
import {
  Settings,
  Shield,
  Clock,
  MessageSquare,
  Sparkles,
  Save,
  RotateCcw,
  CheckCircle2,
  Lock,
  Globe,
  Smartphone,
  Volume2,
  Play,
} from 'lucide-react';
import { useAttendance } from '../context/AttendanceContext';
import {
  fetchElevenLabsVoices,
  playAttendanceVoice,
  stopAttendanceVoice,
  ElevenLabsVoice,
} from '../utils/elevenLabsClient';

export const SettingsView: React.FC = () => {
  const { appSettings, updateAppSettings, policy, updatePolicy, resetToDemoData } = useAttendance();

  const [savedToast, setSavedToast] = useState(false);
  const [elevenVoices, setElevenVoices] = useState<ElevenLabsVoice[]>([]);
  const [isElevenConfigured, setIsElevenConfigured] = useState(false);
  const [selectedVoiceId, setSelectedVoiceId] = useState(
    appSettings.defaultVoiceId || 's5aK934V462dE7L7kO62' // Kabir (Hindi Male)
  );
  const [isPlayingPreview, setIsPlayingPreview] = useState(false);

  useEffect(() => {
    fetchElevenLabsVoices().then((res) => {
      setIsElevenConfigured(res.configured);
      if (res.voices && res.voices.length > 0) {
        setElevenVoices(res.voices);
      }
      if (appSettings.defaultVoiceId) {
        setSelectedVoiceId(appSettings.defaultVoiceId);
      } else if (res.defaultVoiceId) {
        setSelectedVoiceId(res.defaultVoiceId);
      }
    });
  }, [appSettings.defaultVoiceId]);

  const handleTestElevenLabsVoice = async () => {
    setIsPlayingPreview(true);
    const selectedVoice = elevenVoices.find((v) => v.id === selectedVoiceId);
    const isHindi =
      selectedVoice?.language?.toLowerCase().includes('hindi') ||
      selectedVoiceId === 'g5CIjZEefAph4nQFvHAz';

    const testText = isHindi
      ? 'नमस्ते, यह टैलेंट कैरिज की ओर से ऑटोमेटेड अटेंडेंस फॉलो-अप कॉल है। अंग्रेजी में सुनने के लिए # बटन दबाएं। For listening in English, press the hash sign button.'
      : 'Hello, this is Rohan from the Talent Carriage automated attendance desk. Your attendance regularization for yesterday is pending approval from your manager.';

    await playAttendanceVoice(
      testText,
      selectedVoiceId,
      () => setIsPlayingPreview(true),
      () => setIsPlayingPreview(false),
      () => setIsPlayingPreview(false)
    );
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateAppSettings({ defaultVoiceId: selectedVoiceId });
    setSavedToast(true);
    setTimeout(() => setSavedToast(false), 3000);
  };

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Settings Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-slate-100 text-slate-700 border border-slate-200 flex items-center gap-1.5">
              <Settings className="w-3.5 h-3.5" />
              System Configuration
            </span>
            <span className="text-xs text-slate-500 font-medium">.env & Policy Engine</span>
          </div>
          <h2 className="text-2xl font-black text-slate-900 mt-1">
            Attendance Agent Settings
          </h2>
          <p className="text-xs text-slate-600">
            Configure automation timings, ElevenLabs voice engine, WhatsApp integration parameters, and shift policies.
          </p>
        </div>

        {savedToast && (
          <div className="bg-emerald-100 border border-emerald-300 text-emerald-800 px-4 py-2 rounded-xl text-xs font-bold flex items-center space-x-2 animate-fadeIn">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>Settings saved successfully!</span>
          </div>
        )}
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* Section: ElevenLabs AI Voice Engine */}
        <div className="bg-white p-6 rounded-2xl border border-purple-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-purple-100 pb-3">
            <div className="flex items-center space-x-2 font-bold text-slate-900 text-sm">
              <Volume2 className="w-4 h-4 text-purple-600" />
              <span>ElevenLabs Voice Engine (11labs.io)</span>
            </div>
            <span
              className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full ${
                isElevenConfigured
                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                  : 'bg-amber-100 text-amber-800 border border-amber-300'
              }`}
            >
              {isElevenConfigured ? 'API Connected' : 'Ready (Fallback / Add Key in Secrets)'}
            </span>
          </div>

          <p className="text-xs text-slate-600">
            Automated Day 3 voice calls are spoken using high-fidelity human neural voices from ElevenLabs.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="font-bold text-slate-700 block mb-1">
                Default ElevenLabs Voice Persona
              </label>
              <select
                id="settings-voice-select"
                value={selectedVoiceId}
                onChange={(e) => {
                  setSelectedVoiceId(e.target.value);
                  updateAppSettings({ defaultVoiceId: e.target.value });
                }}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs font-semibold text-slate-800 focus:outline-none focus:ring-1 focus:ring-purple-500"
              >
                {elevenVoices.map((v) => (
                  <option key={v.id} value={v.id}>
                    {v.name} — {v.description} ({v.gender}) [{v.accent}]
                  </option>
                ))}
              </select>
              <p className="text-[11px] text-slate-400 mt-1">
                Admin preference for automated Stage 3 phone calls (e.g., Kabir Hindi Male, Rohan Indian English Male).
              </p>
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">
                Default Call Escalation Language
              </label>
              <select
                id="settings-call-lang-select"
                value={appSettings.defaultCallLanguage || 'hindi'}
                onChange={(e) =>
                  updateAppSettings({
                    defaultCallLanguage: e.target.value as 'hindi' | 'english',
                  })
                }
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs font-semibold text-slate-800 focus:outline-none focus:ring-1 focus:ring-purple-500"
              >
                <option value="hindi">हिन्दी (Hindi) — Default (Ends with: "For listening in English press #")</option>
                <option value="english">English (Indian Male Voice: Rohan) — Typical Indian Accent</option>
              </select>
              <p className="text-[11px] text-slate-400 mt-1">
                When user receives the call, Hindi plays by default, prompting user to press # for English.
              </p>
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">
                Default WhatsApp Chat Language
              </label>
              <select
                id="settings-whatsapp-lang-select"
                value={appSettings.defaultWhatsAppLanguage || 'english'}
                onChange={(e) =>
                  updateAppSettings({
                    defaultWhatsAppLanguage: e.target.value as 'hindi' | 'english',
                  })
                }
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs font-semibold text-slate-800 focus:outline-none focus:ring-1 focus:ring-purple-500"
              >
                <option value="english">English (Standard) — With "🌐 Change Language" button always given at end</option>
                <option value="hindi">हिन्दी (Hindi) — With "🌐 भाषा बदलें" button always given at end</option>
              </select>
              <p className="text-[11px] text-slate-400 mt-1">
                Initial template sent to absentees; chat includes permanent Change Language option.
              </p>
            </div>

            <div className="flex flex-col justify-end">
              <button
                type="button"
                id="settings-test-voice-btn"
                onClick={handleTestElevenLabsVoice}
                disabled={isPlayingPreview}
                className="flex items-center justify-center space-x-2 bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white p-2.5 rounded-lg text-xs font-bold transition shadow-xs"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>{isPlayingPreview ? 'Playing Voice Sample...' : 'Test ElevenLabs Voice Audio'}</span>
              </button>
              <p className="text-[10px] text-slate-400 mt-1 text-center">
                Plays live preview of Hindi or English voice with the press '#' prompt.
              </p>
            </div>
          </div>

          <div className="p-3 bg-purple-50/70 border border-purple-200 rounded-xl text-xs text-purple-900 flex items-start space-x-2">
            <Lock className="w-4 h-4 text-purple-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold">Secure Secret Management:</span> To connect your ElevenLabs account, provide <code className="bg-purple-100 px-1 py-0.5 rounded text-purple-800 font-mono text-[11px]">ELEVENLABS_API_KEY</code> in the AI Studio Settings / Secrets panel. The server securely proxies all text-to-speech audio without exposing API keys to client browsers.
            </div>
          </div>
        </div>

        {/* Section 1: Automation Timers & Scheduler */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center space-x-2 font-bold text-slate-900 text-sm border-b border-slate-100 pb-3">
            <Clock className="w-4 h-4 text-teal-600" />
            <span>Automation Trigger & Scheduler</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="font-bold text-slate-700 block mb-1">
                Daily Absentee Check Time (IST)
              </label>
              <input
                type="time"
                value={appSettings.dailyCheckTime}
                onChange={(e) => updateAppSettings({ dailyCheckTime: e.target.value })}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs font-mono font-bold text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-500"
              />
              <p className="text-[11px] text-slate-400 mt-1">
                Scheduled execution time to sweep previous day's attendance register.
              </p>
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">
                Company Timezone
              </label>
              <input
                type="text"
                value={appSettings.timeZone}
                onChange={(e) => updateAppSettings({ timeZone: e.target.value })}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs font-mono text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-500"
              />
              <p className="text-[11px] text-slate-400 mt-1">Default is Asia/Kolkata (IST).</p>
            </div>
          </div>

          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200">
            <div>
              <div className="font-bold text-xs text-slate-800">
                Automated Daily Check Scheduler
              </div>
              <div className="text-[11px] text-slate-500">
                Automatically scans attendance files at check time and triggers Stage 1 WhatsApp messages.
              </div>
            </div>
            <input
              type="checkbox"
              checked={appSettings.schedulerEnabled}
              onChange={(e) => updateAppSettings({ schedulerEnabled: e.target.checked })}
              className="w-4 h-4 text-teal-600 rounded focus:ring-teal-500"
            />
          </div>
        </div>

        {/* Section 2: WhatsApp & Meta Cloud API */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center space-x-2 font-bold text-slate-900 text-sm border-b border-slate-100 pb-3">
            <MessageSquare className="w-4 h-4 text-teal-600" />
            <span>WhatsApp Integration & Dry Run Mode</span>
          </div>

          <div className="flex items-center justify-between p-3 rounded-xl bg-amber-50/60 border border-amber-200">
            <div>
              <div className="font-bold text-xs text-amber-900">Dry Run Mode</div>
              <div className="text-[11px] text-amber-700">
                Simulates real WhatsApp responses inside browser without deducting Meta Cloud API units.
              </div>
            </div>
            <button
              type="button"
              onClick={() => updateAppSettings({ dryRun: !appSettings.dryRun })}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition ${
                appSettings.dryRun
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-slate-200 text-slate-700'
              }`}
            >
              {appSettings.dryRun ? 'Dry Run Active' : 'Live WhatsApp'}
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="font-bold text-slate-700 block mb-1">
                WhatsApp Template Name
              </label>
              <input
                type="text"
                value={appSettings.waTemplateName}
                onChange={(e) => updateAppSettings({ waTemplateName: e.target.value })}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs font-mono text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-500"
              />
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">
                Template Quick Reply Buttons Count
              </label>
              <input
                type="number"
                value={appSettings.waTemplateButtons}
                onChange={(e) =>
                  updateAppSettings({ waTemplateButtons: parseInt(e.target.value, 10) || 4 })
                }
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs font-mono text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-500"
              />
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">
                WhatsApp Phone Number ID
              </label>
              <input
                type="text"
                value={appSettings.waPhoneNumberId}
                onChange={(e) => updateAppSettings({ waPhoneNumberId: e.target.value })}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs font-mono text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-500"
              />
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">
                Default Test Phone Override
              </label>
              <input
                type="text"
                value={appSettings.testPhoneNumber}
                onChange={(e) => updateAppSettings({ testPhoneNumber: e.target.value })}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs font-mono text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-500"
              />
            </div>
          </div>
        </div>

        {/* Section 3: AI Reply Intent Classifier */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center space-x-2 font-bold text-slate-900 text-sm border-b border-slate-100 pb-3">
            <Sparkles className="w-4 h-4 text-teal-600" />
            <span>AI Natural Language Reply Classifier</span>
          </div>

          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200">
            <div>
              <div className="font-bold text-xs text-slate-800">
                Natural Language Classifier (English & Hinglish)
              </div>
              <div className="text-[11px] text-slate-500">
                Understands unformatted replies like "I was unwell", "swipe machine error", or "already mailed manager".
              </div>
            </div>
            <input
              type="checkbox"
              checked={appSettings.aiClassifierEnabled}
              onChange={(e) => updateAppSettings({ aiClassifierEnabled: e.target.checked })}
              className="w-4 h-4 text-teal-600 rounded focus:ring-teal-500"
            />
          </div>
        </div>

        {/* Section 4: Shift & Regularization Policy */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center space-x-2 font-bold text-slate-900 text-sm border-b border-slate-100 pb-3">
            <Shield className="w-4 h-4 text-teal-600" />
            <span>Shift & Attendance Regularization Policy</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div>
              <label className="font-bold text-slate-700 block mb-1">Standard Shift Start</label>
              <input
                type="time"
                value={policy.standardShiftStart}
                onChange={(e) => updatePolicy({ standardShiftStart: e.target.value })}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs font-mono text-slate-800"
              />
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">Standard Shift End</label>
              <input
                type="time"
                value={policy.standardShiftEnd}
                onChange={(e) => updatePolicy({ standardShiftEnd: e.target.value })}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs font-mono text-slate-800"
              />
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">Grace Period (Minutes)</label>
              <input
                type="number"
                value={policy.gracePeriodMinutes}
                onChange={(e) =>
                  updatePolicy({ gracePeriodMinutes: parseInt(e.target.value, 10) || 15 })
                }
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs font-mono text-slate-800"
              />
            </div>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex items-center justify-between pt-2">
          <button
            type="button"
            onClick={() => {
              if (window.confirm('Reset all cases and settings to demo state?')) {
                resetToDemoData();
              }
            }}
            className="flex items-center space-x-1.5 text-xs text-rose-600 hover:text-rose-700 font-bold px-3 py-2 rounded-lg hover:bg-rose-50 transition"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Restore Factory Demo Data</span>
          </button>

          <button
            type="submit"
            className="flex items-center space-x-2 bg-slate-900 hover:bg-slate-800 text-white px-6 py-2.5 rounded-xl text-xs font-bold shadow-md transition"
          >
            <Save className="w-4 h-4" />
            <span>Save Settings</span>
          </button>
        </div>
      </form>
    </div>
  );
};
