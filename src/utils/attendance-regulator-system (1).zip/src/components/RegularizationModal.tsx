import React, { useState, useEffect, useMemo } from 'react';
import { useAttendance } from '../context/AttendanceContext';
import { RegularizationReason } from '../types';
import {
  FileCheck2,
  Calendar,
  Clock,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  Link2,
  ShieldCheck,
  X,
  Info,
} from 'lucide-react';

interface RegularizationModalProps {
  isOpen: boolean;
  onClose: () => void;
  presetDate?: string;
  presetCalendarEventId?: string;
}

export const RegularizationModal: React.FC<RegularizationModalProps> = ({
  isOpen,
  onClose,
  presetDate,
  presetCalendarEventId,
}) => {
  const {
    currentEmployee,
    checkInRecords,
    calendarEvents,
    submitRegularization,
    currentTime,
    policy,
  } = useAttendance();

  const todayStr = currentTime.toISOString().split('T')[0];
  const [selectedDate, setSelectedDate] = useState<string>(presetDate || todayStr);

  useEffect(() => {
    if (presetDate) {
      setSelectedDate(presetDate);
    }
  }, [presetDate]);

  // Find record for selected date
  const targetRecord = useMemo(() => {
    return checkInRecords.find(
      (r) => r.employeeId === currentEmployee.id && r.date === selectedDate
    );
  }, [checkInRecords, currentEmployee.id, selectedDate]);

  // Available calendar events for this employee and date
  const availableCalendarEvents = useMemo(() => {
    return calendarEvents.filter(
      (ev) => ev.employeeId === currentEmployee.id && ev.date === selectedDate
    );
  }, [calendarEvents, currentEmployee.id, selectedDate]);

  const [requestedCheckIn, setRequestedCheckIn] = useState<string>('09:00');
  const [requestedCheckOut, setRequestedCheckOut] = useState<string>('18:00');
  const [reasonCategory, setReasonCategory] = useState<RegularizationReason>('client_meeting');
  const [linkedEventId, setLinkedEventId] = useState<string>('');
  const [explanation, setExplanation] = useState<string>('');
  const [submitFeedback, setSubmitFeedback] = useState<{
    type: 'success' | 'error';
    message: string;
    autoApproved?: boolean;
  } | null>(null);

  // Auto-fill from preset calendar event or detected event
  useEffect(() => {
    if (presetCalendarEventId) {
      setLinkedEventId(presetCalendarEventId);
      const ev = availableCalendarEvents.find((e) => e.id === presetCalendarEventId);
      if (ev) {
        setRequestedCheckIn(ev.startTime);
        setExplanation(
          `Was attending scheduled client meeting: "${ev.title}" from ${ev.startTime} to ${ev.endTime} at ${ev.location || 'Client Site'}.`
        );
        setReasonCategory('client_meeting');
      }
    } else if (availableCalendarEvents.length > 0 && !linkedEventId) {
      // Pick first external or morning event
      const best = availableCalendarEvents.find((e) => e.isExternal) || availableCalendarEvents[0];
      setLinkedEventId(best.id);
      setRequestedCheckIn('09:00');
      setExplanation(
        `Attended scheduled session: "${best.title}" (${best.startTime} - ${best.endTime}) which accounts for check-in timing.`
      );
    } else {
      setRequestedCheckIn('09:00');
    }
  }, [presetCalendarEventId, availableCalendarEvents, selectedDate]);

  const selectedEvent = useMemo(() => {
    return availableCalendarEvents.find((e) => e.id === linkedEventId) || null;
  }, [availableCalendarEvents, linkedEventId]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const result = submitRegularization({
      date: selectedDate,
      originalCheckIn: targetRecord?.checkInTime.slice(0, 5),
      originalCheckOut: targetRecord?.checkOutTime?.slice(0, 5),
      requestedCheckIn,
      requestedCheckOut,
      reasonCategory,
      explanation,
      linkedCalendarEventId: selectedEvent?.id,
      linkedCalendarEventTitle: selectedEvent?.title,
      calendarProofSnippet: selectedEvent
        ? `Calendar Event: "${selectedEvent.title}" (${selectedEvent.startTime} - ${selectedEvent.endTime}), Location: ${selectedEvent.location || 'Virtual'}, Attendees: ${selectedEvent.attendees?.join(', ') || 'N/A'}`
        : undefined,
    });

    if (result.success) {
      setSubmitFeedback({
        type: 'success',
        message: result.message,
        autoApproved: result.autoApproved,
      });
      setTimeout(() => {
        setSubmitFeedback(null);
        onClose();
      }, 1800);
    } else {
      setSubmitFeedback({
        type: 'error',
        message: result.message,
      });
    }
  };

  const isAutoApprovable =
    policy.autoApproveVerifiedCalendarMeetings &&
    Boolean(selectedEvent && reasonCategory === 'client_meeting');

  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-2xl border border-slate-200 relative max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center space-x-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-50 border border-indigo-200 flex items-center justify-center text-indigo-600">
              <FileCheck2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Attendance Regularization Request
              </h2>
              <p className="text-xs text-slate-500">
                Adjust punch discrepancy using verified calendar evidence
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg hover:bg-slate-100 flex items-center justify-center text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Feedback Alert */}
        {submitFeedback && (
          <div
            className={`mt-4 p-4 rounded-xl text-xs font-medium flex items-center space-x-3 ${
              submitFeedback.type === 'success'
                ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                : 'bg-red-50 text-red-800 border border-red-200'
            }`}
          >
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <div>
              <p className="font-bold">{submitFeedback.message}</p>
              {submitFeedback.autoApproved && (
                <p className="text-[11px] text-emerald-700 mt-0.5">
                  Verified with connected calendar meeting. Attendance record updated immediately.
                </p>
              )}
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-5 space-y-4 text-xs">
          {/* Date & Original Punch Info Box */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-2.5">
            <div className="flex items-center justify-between">
              <label className="font-semibold text-slate-700 flex items-center">
                <Calendar className="w-3.5 h-3.5 mr-1.5 text-indigo-600" />
                Target Discrepancy Date
              </label>
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="text-xs font-semibold text-slate-800 bg-white px-2 py-1 border border-slate-200 rounded-lg"
              />
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-200/80 text-[11px]">
              <div>
                <span className="text-slate-500 block">Original Check-In</span>
                <span className="font-bold font-mono-code text-slate-800">
                  {targetRecord ? targetRecord.checkInTime.slice(0, 5) : 'No Punch Recorded'}
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">Original Check-Out</span>
                <span className="font-bold font-mono-code text-slate-800">
                  {targetRecord?.checkOutTime ? targetRecord.checkOutTime.slice(0, 5) : 'In Progress / None'}
                </span>
              </div>
            </div>
          </div>

          {/* Requested Time Adjustments */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Requested Check-In
              </label>
              <input
                type="time"
                required
                value={requestedCheckIn}
                onChange={(e) => setRequestedCheckIn(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-xl font-mono-code font-bold text-slate-900 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Requested Check-Out
              </label>
              <input
                type="time"
                required
                value={requestedCheckOut}
                onChange={(e) => setRequestedCheckOut(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-xl font-mono-code font-bold text-slate-900 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
              />
            </div>
          </div>

          {/* Reason Category */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Discrepancy Category
            </label>
            <select
              value={reasonCategory}
              onChange={(e) => setReasonCategory(e.target.value as RegularizationReason)}
              className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 bg-white"
            >
              <option value="client_meeting">
                External Client Meeting / Field Visit (Eligible for Auto-Approval)
              </option>
              <option value="onsite_duty">
                On-Duty Assignment / Offsite Data Center
              </option>
              <option value="travel_delay">
                Transit / Flight / Commute Disruption
              </option>
              <option value="wfh_approved">
                Approved Remote / WFH Shift
              </option>
              <option value="biometric_issue">
                Biometric Terminal / Network Failure
              </option>
              <option value="personal_emergency">
                Personal Emergency / Doctor Appointment
              </option>
            </select>
          </div>

          {/* Calendar Evidence Selector */}
          <div className="bg-indigo-50/60 border border-indigo-200/80 rounded-xl p-3.5 space-y-2">
            <div className="flex items-center justify-between">
              <label className="font-semibold text-indigo-900 flex items-center">
                <Link2 className="w-3.5 h-3.5 mr-1.5 text-indigo-600" />
                Link Calendar Evidence (Google Calendar / Synced Feed)
              </label>
              {isAutoApprovable && (
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200 flex items-center">
                  <Sparkles className="w-3 h-3 mr-1" />
                  Auto-Approval Ready
                </span>
              )}
            </div>

            {availableCalendarEvents.length === 0 ? (
              <p className="text-[11px] text-indigo-700 italic">
                No calendar events detected for {selectedDate}. You can still submit with written remarks for manager review.
              </p>
            ) : (
              <select
                value={linkedEventId}
                onChange={(e) => {
                  setLinkedEventId(e.target.value);
                  const ev = availableCalendarEvents.find((evItem) => evItem.id === e.target.value);
                  if (ev) {
                    setExplanation(`Attended scheduled event: "${ev.title}" (${ev.startTime} - ${ev.endTime}).`);
                  }
                }}
                className="w-full px-3 py-2 border border-indigo-200 rounded-xl bg-white text-xs text-slate-800 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
              >
                <option value="">-- None / Select Calendar Event --</option>
                {availableCalendarEvents.map((ev) => (
                  <option key={ev.id} value={ev.id}>
                    {ev.startTime} - {ev.endTime} : {ev.title} ({ev.isExternal ? 'Client' : 'Internal'})
                  </option>
                ))}
              </select>
            )}

            {/* Display Selected Event Card */}
            {selectedEvent && (
              <div className="mt-2 p-2.5 bg-white border border-indigo-100 rounded-lg text-[11px] text-slate-700">
                <div className="flex justify-between font-bold text-slate-900">
                  <span>{selectedEvent.title}</span>
                  <span className="font-mono-code text-indigo-600">
                    {selectedEvent.startTime} – {selectedEvent.endTime}
                  </span>
                </div>
                <div className="text-slate-500 mt-0.5">
                  Location: {selectedEvent.location || 'Virtual'} • {selectedEvent.attendees?.length || 1} attendees
                </div>
              </div>
            )}
          </div>

          {/* Explanation / Remarks */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Detailed Justification / Notes for Approver
            </label>
            <textarea
              required
              rows={3}
              placeholder="State the reason for discrepancy and attach any notes..."
              value={explanation}
              onChange={(e) => setExplanation(e.target.value)}
              className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
            />
          </div>

          {/* Quota & Policy Notice */}
          <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1">
            <span className="flex items-center">
              <ShieldCheck className="w-3.5 h-3.5 mr-1 text-slate-400" />
              Monthly Quota: {currentEmployee.regularizationsUsedThisMonth} of {currentEmployee.regularizationQuota} used
            </span>
            <span className="text-indigo-600 font-medium">
              Review SLA: &lt; 24 hrs
            </span>
          </div>

          {/* Actions */}
          <div className="flex justify-end space-x-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-slate-200 text-slate-600 rounded-xl hover:bg-slate-50 cursor-pointer font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl shadow-xs transition-colors flex items-center cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 mr-1.5" />
              <span>{isAutoApprovable ? 'Auto-Regularize with Calendar' : 'Submit for Manager Review'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
