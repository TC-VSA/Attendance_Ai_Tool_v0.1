import React, { useState, useEffect, useCallback } from 'react';
import {
  PhoneCall,
  PhoneOff,
  Volume2,
  Clock,
  Sparkles,
  AlertTriangle,
  CheckCircle2,
  Play,
  RotateCcw,
  User,
  Calendar,
  Building,
  HelpCircle,
  FileCheck,
  AlertOctagon,
  Globe,
  Hash,
} from 'lucide-react';
import { useAttendance } from '../context/AttendanceContext';
import { WORKFLOW_TEMPLATES } from '../data/followUpData';
import { WHATSAPP_FLOW_TREES } from '../data/attendanceConversationFlows';
import {
  fetchElevenLabsVoices,
  playAttendanceVoice,
  stopAttendanceVoice,
  ElevenLabsVoice,
} from '../utils/elevenLabsClient';

// DTMF tone generator for telephone dial tones
function playDtmfTone(char: string) {
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const gain = ctx.createGain();

    const dtmfMap: Record<string, [number, number]> = {
      '1': [697, 1209], '2': [697, 1336], '3': [697, 1477],
      '4': [770, 1209], '5': [770, 1336], '6': [770, 1477],
      '7': [852, 1209], '8': [852, 1336], '9': [852, 1477],
      '*': [941, 1209], '0': [941, 1336], '#': [941, 1477],
    };

    const freqs = dtmfMap[char] || [941, 1477];
    osc1.frequency.value = freqs[0];
    osc2.frequency.value = freqs[1];
    gain.gain.value = 0.12;

    osc1.connect(gain);
    osc2.connect(gain);
    gain.connect(ctx.destination);

    osc1.start();
    osc2.start();
    setTimeout(() => {
      osc1.stop();
      osc2.stop();
      ctx.close();
    }, 200);
  } catch (e) {
    // Ignore audio context errors in non-interactive states
  }
}

export const CallCenterView: React.FC = () => {
  const {
    followUpCases,
    triggerCall,
    logCallOutcome,
    markCaseVerified,
    logEmployeeReply,
    appSettings,
  } = useAttendance();

  // Filter cases that need calling or have call logs
  const callingCases = followUpCases.filter(
    (c) =>
      c.status === 'call-required' ||
      c.status === 'call-logged' ||
      c.status === 'hr-escalated' ||
      c.stage === 'stage_3_call'
  );

  const [activeCallingCaseId, setActiveCallingCaseId] = useState<string | null>(
    callingCases[0]?.id || null
  );

  const [callActive, setCallActive] = useState(false);
  const [callDuration, setCallDuration] = useState(0);
  const [callNotes, setCallNotes] = useState('');
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [voiceSource, setVoiceSource] = useState<'elevenlabs' | 'browser-fallback' | null>(null);

  // Active IVR Dialogue Node state
  const [callNodeId, setCallNodeId] = useState<string>('INITIAL');

  // Call Language State (Defaults to Hindi as requested by user)
  const [callLanguage, setCallLanguage] = useState<'hindi' | 'english'>(
    appSettings.defaultCallLanguage || 'hindi'
  );
  const [dtmfFeedback, setDtmfFeedback] = useState<string | null>(null);

  // ElevenLabs Voice State (Defaults to Kabir - Hindi Male or Rohan - Indian English Male)
  const [elevenVoices, setElevenVoices] = useState<ElevenLabsVoice[]>([]);
  const [isElevenConfigured, setIsElevenConfigured] = useState(false);
  const [selectedVoiceId, setSelectedVoiceId] = useState(
    appSettings.defaultVoiceId || 'g5CIjZEefAph4nQFvHAz' // Kabir (Hindi Male)
  );

  const targetCase = followUpCases.find((c) => c.id === activeCallingCaseId) || callingCases[0];

  // Current active conversation node
  const currentNode = WHATSAPP_FLOW_TREES[callNodeId] || WHATSAPP_FLOW_TREES.INITIAL;

  // Format script text with employee details
  const getFormattedScript = useCallback(
    (nodeId: string, lang: 'hindi' | 'english') => {
      if (!targetCase) return '';
      const node = WHATSAPP_FLOW_TREES[nodeId] || WHATSAPP_FLOW_TREES.INITIAL;
      const textRaw = lang === 'hindi' ? node.voiceScriptHindi : node.voiceScriptEnglish;
      return textRaw
        .replace(/{name}/g, targetCase.employeeName.split(' ')[0])
        .replace(/{date}/g, targetCase.date)
        .replace(/{reportingManager}/g, targetCase.reportingManager);
    },
    [targetCase]
  );

  // Sync with AppSettings when updated
  useEffect(() => {
    if (appSettings.defaultCallLanguage) {
      setCallLanguage(appSettings.defaultCallLanguage);
    }
    if (appSettings.defaultVoiceId) {
      setSelectedVoiceId(appSettings.defaultVoiceId);
    }
  }, [appSettings.defaultCallLanguage, appSettings.defaultVoiceId]);

  // Reset node to INITIAL when switching cases
  useEffect(() => {
    setCallNodeId('INITIAL');
    setDtmfFeedback(null);
  }, [activeCallingCaseId]);

  // Load ElevenLabs voices and configuration status
  useEffect(() => {
    fetchElevenLabsVoices().then((res) => {
      setIsElevenConfigured(res.configured);
      if (res.voices && res.voices.length > 0) {
        setElevenVoices(res.voices);
      }
      if (appSettings.defaultVoiceId) {
        setSelectedVoiceId(appSettings.defaultVoiceId);
      } else if (res.defaultVoiceId) {
        setSelectedVoiceId(res.defaultVoiceId);
      }
    });
  }, [appSettings.defaultVoiceId]);

  // Call timer effect
  useEffect(() => {
    let timer: any;
    if (callActive) {
      timer = setInterval(() => {
        setCallDuration((prev) => prev + 1);
      }, 1000);
    } else {
      setCallDuration(0);
    }
    return () => clearInterval(timer);
  }, [callActive]);

  // Speak script helper for active conversation node
  const speakNodeScript = useCallback(
    async (nodeId: string, lang: 'hindi' | 'english', voiceIdToUse?: string) => {
      if (!targetCase) return;
      const scriptText = getFormattedScript(nodeId, lang);
      const voice =
        voiceIdToUse ||
        (lang === 'hindi'
          ? selectedVoiceId.includes('21m') || selectedVoiceId.includes('pNIn') || selectedVoiceId === 'JBFqnCBsd6RMkjVDRZzb'
            ? 'g5CIjZEefAph4nQFvHAz' // Kabir (Hindi Male)
            : selectedVoiceId
          : selectedVoiceId === 'g5CIjZEefAph4nQFvHAz' || selectedVoiceId.includes('hindi')
          ? 'JBFqnCBsd6RMkjVDRZzb' // Rohan (Indian English Male)
          : selectedVoiceId);

      const res = await playAttendanceVoice(
        scriptText,
        voice,
        () => setIsPlayingAudio(true),
        () => setIsPlayingAudio(false),
        () => setIsPlayingAudio(false)
      );
      setVoiceSource(res.source);
    },
    [targetCase, selectedVoiceId, getFormattedScript]
  );

  // Start Call handler (Defaults to Hindi voice and script with # prompt)
  const handleStartCall = async () => {
    if (!targetCase) return;
    setCallActive(true);
    setCallNodeId('INITIAL');
    triggerCall(targetCase.id);

    const initialLang = appSettings.defaultCallLanguage || 'hindi';
    setCallLanguage(initialLang);
    setDtmfFeedback('📞 Call connected. AI voice agent explaining options. Press keypad numbers to choose...');

    await speakNodeScript('INITIAL', initialLang);
  };

  // Switch to English when user presses # button (typical Indian male voice)
  const handlePressHashForEnglish = useCallback(async () => {
    playDtmfTone('#');
    stopAttendanceVoice();
    setDtmfFeedback('# pressed: Switching to Indian English male voice (Rohan - ElevenLabs)...');
    setCallLanguage('english');

    // Switch voice to typical Indian English male voice
    const indianEnglishVoice =
      elevenVoices.find((v) => v.id === 'JBFqnCBsd6RMkjVDRZzb')?.id ||
      elevenVoices.find(
        (v) =>
          v.accent?.toLowerCase().includes('indian') &&
          v.gender === 'male' &&
          v.language?.toLowerCase().includes('english')
      )?.id ||
      elevenVoices.find(
        (v) => v.accent?.toLowerCase().includes('indian') && v.gender === 'male'
      )?.id ||
      'JBFqnCBsd6RMkjVDRZzb';

    setSelectedVoiceId(indianEnglishVoice);

    await speakNodeScript(callNodeId, 'english', indianEnglishVoice);
  }, [elevenVoices, speakNodeScript, callNodeId]);

  // Switch to Hindi when user presses * button
  const handlePressStarForHindi = useCallback(async () => {
    playDtmfTone('*');
    stopAttendanceVoice();
    setDtmfFeedback('* pressed: Switching to Hindi male voice (Kabir - ElevenLabs)...');
    setCallLanguage('hindi');

    // Switch voice to Hindi Male
    const hindiVoice = 'g5CIjZEefAph4nQFvHAz'; // Kabir
    setSelectedVoiceId(hindiVoice);

    await speakNodeScript(callNodeId, 'hindi', hindiVoice);
  }, [speakNodeScript, callNodeId]);

  // Keypad press handler with interactive branching and autonomous action execution
  const handleDialpadPress = async (key: string) => {
    playDtmfTone(key);

    if (key === '#') {
      handlePressHashForEnglish();
      return;
    }
    if (key === '*') {
      handlePressStarForHindi();
      return;
    }

    const current = WHATSAPP_FLOW_TREES[callNodeId] || WHATSAPP_FLOW_TREES.INITIAL;
    const matchedOption = current.options.find((o) => o.dtmfKey === key);

    if (matchedOption && targetCase) {
      const nextNodeId = matchedOption.actionPayload;
      const nextNode = WHATSAPP_FLOW_TREES[nextNodeId];
      const optLabel = callLanguage === 'hindi' ? matchedOption.labelHindi : matchedOption.label;

      setDtmfFeedback(`Key [${key}] pressed: "${optLabel}"`);
      setCallNodeId(nextNodeId);

      // Play next step voice script
      await speakNodeScript(nextNodeId, callLanguage);

      // Check if this step executes an autonomous action
      if (nextNode?.isFinalResolution) {
        if (nextNode.resolutionType === 'leave_applied') {
          logEmployeeReply(targetCase.id, optLabel, 1);
          setCallNotes((prev) =>
            `${prev ? prev + ' | ' : ''}Voice IVR: Key [${key}] (${optLabel}) -> Autonomous Leave Applied in HRMS.`
          );
        } else if (nextNode.resolutionType === 'punch_regularized') {
          logEmployeeReply(targetCase.id, optLabel, 2);
          setCallNotes((prev) =>
            `${prev ? prev + ' | ' : ''}Voice IVR: Key [${key}] (${optLabel}) -> Attendance Regularized in HRMS.`
          );
        } else if (nextNode.resolutionType === 'manager_reminded') {
          logEmployeeReply(targetCase.id, '🔔 Send urgent reminder to Manager');
          setCallNotes((prev) =>
            `${prev ? prev + ' | ' : ''}Voice IVR: Key [${key}] -> Priority reminder sent to manager.`
          );
        } else if (nextNode.resolutionType === 'verified_resolved') {
          logEmployeeReply(targetCase.id, '✅ Manager has already approved');
          setCallNotes((prev) =>
            `${prev ? prev + ' | ' : ''}Voice IVR: Key [${key}] -> Verified & closed.`
          );
        }
      } else {
        setCallNotes((prev) => `${prev ? prev + ' -> ' : ''}Key [${key}] (${optLabel})`);
      }
    } else {
      setDtmfFeedback(`Key ${key} registered. (No option mapped for this number in current step)`);
    }
  };

  // Keyboard shortcut listener for active call
  useEffect(() => {
    if (!callActive) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '*', '#'].includes(e.key)) {
        handleDialpadPress(e.key);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [callActive, callNodeId, callLanguage, targetCase]);

  const handlePreviewVoice = async () => {
    if (!targetCase) return;
    const previewText =
      callLanguage === 'hindi'
        ? `नमस्ते, यह टैलेंट कैरिज की ओर से ऑटोमेटेड अटेंडेंस डेस्क है। अंग्रेजी में सुनने के लिए # बटन दबाएं। For listening in English, press the # button.`
        : `Hello ${targetCase.employeeName.split(' ')[0]}, this is Rohan from the Talent Carriage attendance desk. Your attendance verification for ${targetCase.date} is pending. Please complete your leave or regularization application.`;

    const res = await playAttendanceVoice(
      previewText,
      selectedVoiceId,
      () => setIsPlayingAudio(true),
      () => setIsPlayingAudio(false),
      () => setIsPlayingAudio(false)
    );

    setVoiceSource(res.source);
  };

  const handleEndCall = () => {
    setCallActive(false);
    stopAttendanceVoice();
    setIsPlayingAudio(false);
    setDtmfFeedback(null);
  };

  const handleRecordOutcome = (
    outcome: 'completed' | 'not_completed' | 'needs_help' | 'no_answer'
  ) => {
    if (!targetCase) return;
    handleEndCall();
    logCallOutcome(targetCase.id, outcome, callNotes);
    setCallNotes('');
  };

  const formatDuration = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const s = sec % 60;
    return `${String(mins).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  const selectedVoiceObj = elevenVoices.find((v) => v.id === selectedVoiceId) || elevenVoices[0];

  return (
    <div className="space-y-6">
      {/* Call Center Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-rose-100 text-rose-800 border border-rose-200 flex items-center gap-1.5">
              <PhoneCall className="w-3.5 h-3.5" />
              Day 3 Voice Escalation Desk
            </span>

            {/* 11labs Voice Badge */}
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-purple-100 text-purple-800 border border-purple-200 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-purple-600" />
              ElevenLabs Hindi & English Voice Engine
            </span>

            <span className="text-xs text-slate-500 font-medium">Stage 3 Automation</span>
          </div>
          <h2 className="text-2xl font-black text-slate-900 mt-1">
            Automated Phone Escalation Center
          </h2>
          <p className="text-xs text-slate-600 max-w-2xl">
            When employee attendance remains unresolved after the 2-day reminder, the system triggers this voice call. By default, it greets in a <strong>Hindi male voice</strong> and concludes with <em>"For listening in English, press # sign button"</em>.
          </p>
        </div>

        <div className="flex items-center space-x-3 bg-slate-50 p-3 rounded-xl border border-slate-200 shrink-0">
          <div className="text-right">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Queue Status</span>
            <span className="text-sm font-black text-rose-600">
              {callingCases.length} Pending Call Escalations
            </span>
          </div>
        </div>
      </div>

      {/* Voice Selection & Engine Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-4 rounded-2xl border border-indigo-900 shadow-sm flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-purple-600/30 border border-purple-400/40 flex items-center justify-center text-purple-300 shrink-0">
            <Volume2 className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-xs font-bold text-purple-300 uppercase tracking-wider">
                ElevenLabs Neural Voice Model
              </span>
              <span
                className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  isElevenConfigured
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/30'
                    : 'bg-amber-500/20 text-amber-300 border border-amber-400/30'
                }`}
              >
                {isElevenConfigured ? 'API Connected' : 'Ready (Ready for API Key / Fallback)'}
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-0.5">
              Current Voice:{' '}
              <strong className="text-white font-bold">{selectedVoiceObj?.name || 'Kabir'}</strong>{' '}
              — {selectedVoiceObj?.description || 'Deep, polite Hindi male voice'} [{selectedVoiceObj?.accent}]
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {/* Active Voice Language Pill */}
          <span className="bg-slate-800 border border-purple-500/50 text-purple-200 text-xs font-bold px-3 py-1.5 rounded-xl flex items-center gap-1.5">
            <Globe className="w-3.5 h-3.5 text-purple-400" />
            <span>Mode: {callLanguage === 'hindi' ? 'हिन्दी (Hindi Default)' : 'English'}</span>
          </span>

          <select
            id="elevenlabs-voice-picker"
            value={selectedVoiceId}
            onChange={(e) => {
              setSelectedVoiceId(e.target.value);
            }}
            className="bg-slate-800 border border-indigo-700/60 rounded-xl px-3 py-2 text-xs font-bold text-purple-200 focus:outline-none focus:ring-2 focus:ring-purple-400"
          >
            {elevenVoices.map((v) => (
              <option key={v.id} value={v.id} className="bg-slate-900 text-white">
                {v.name} ({v.gender}, {v.accent})
              </option>
            ))}
          </select>

          <button
            id="preview-elevenlabs-voice-btn"
            onClick={handlePreviewVoice}
            disabled={isPlayingAudio}
            className="flex items-center space-x-1.5 bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white px-3.5 py-2 rounded-xl text-xs font-bold transition shadow-xs"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>Preview Voice</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left 5 cols: Call Escalation Queue */}
        <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
            <h3 className="font-bold text-sm text-slate-800">
              Escalation Queue ({callingCases.length})
            </h3>
            <span className="text-xs text-slate-500">Day 3 Unresolved</span>
          </div>

          <div className="divide-y divide-slate-100 max-h-[580px] overflow-y-auto">
            {callingCases.length === 0 ? (
              <div className="p-8 text-center text-slate-400 text-xs">
                No cases currently require calling escalation. All follow-ups are on track!
              </div>
            ) : (
              callingCases.map((c) => {
                const isSelected = c.id === targetCase?.id;
                return (
                  <div
                    key={c.id}
                    onClick={() => {
                      if (!callActive) setActiveCallingCaseId(c.id);
                    }}
                    className={`p-4 cursor-pointer transition ${
                      isSelected
                        ? 'bg-teal-50/80 border-l-4 border-teal-600'
                        : 'hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="text-sm font-bold text-slate-900">{c.employeeName}</div>
                        <div className="text-xs text-slate-500">
                          {c.department} · Mgr: {c.reportingManager}
                        </div>
                      </div>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-rose-100 text-rose-700 font-bold">
                        {c.code}
                      </span>
                    </div>

                    <div className="mt-2 flex items-center justify-between text-xs">
                      <span className="text-slate-600 font-mono text-[11px]">
                        Absent: {c.date}
                      </span>
                      <span
                        className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                          c.status === 'call-required'
                            ? 'bg-rose-100 text-rose-800'
                            : c.status === 'call-logged'
                            ? 'bg-purple-100 text-purple-800'
                            : 'bg-teal-100 text-teal-800'
                        }`}
                      >
                        {c.status.replace('-', ' ')}
                      </span>
                    </div>

                    {c.callOutcome && (
                      <div className="mt-2 text-[11px] bg-slate-100 p-1.5 rounded text-slate-700 font-medium">
                        Last outcome: <span className="capitalize font-bold">{c.callOutcome.replace('_', ' ')}</span>
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right 7 cols: Interactive Call Simulation & Script Deck */}
        <div className="lg:col-span-7 space-y-6">
          {targetCase ? (
            <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
              {/* Call Terminal Header */}
              <div className="p-6 bg-gradient-to-r from-slate-900 via-[#073B5C] to-slate-900 text-white flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div>
                  <div className="text-xs uppercase font-bold text-cyan-300 tracking-wider">
                    Interactive Calling Desk
                  </div>
                  <h3 className="text-xl font-black mt-0.5">{targetCase.employeeName}</h3>
                  <div className="text-xs text-slate-300 font-mono">
                    +{targetCase.mobileNumber} · Absent on {targetCase.date} ({targetCase.code})
                  </div>
                </div>

                {callActive ? (
                  <div className="flex items-center space-x-3 bg-rose-950/80 border border-rose-500 px-4 py-2 rounded-xl">
                    <div className="w-3 h-3 rounded-full bg-rose-500 animate-ping" />
                    <span className="font-mono text-base font-bold text-rose-200">
                      {formatDuration(callDuration)}
                    </span>
                    <button
                      id="hangup-call-btn"
                      onClick={handleEndCall}
                      className="bg-rose-600 hover:bg-rose-700 text-white p-2 rounded-full transition ml-2"
                      title="End Call"
                    >
                      <PhoneOff className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <button
                    id="start-call-btn"
                    onClick={handleStartCall}
                    className="flex items-center space-x-2 bg-emerald-600 hover:bg-emerald-500 text-white px-5 py-2.5 rounded-xl text-xs font-black shadow-md transition transform active:scale-95"
                  >
                    <PhoneCall className="w-4 h-4" />
                    <span>Trigger ElevenLabs Call</span>
                  </button>
                )}
              </div>

              {/* Call Waveform & State Visualizer */}
              {isPlayingAudio && (
                <div className="p-4 bg-slate-900 border-b border-slate-800 text-center">
                  <div className="flex items-center justify-center space-x-1.5 h-12">
                    {[16, 28, 44, 20, 36, 48, 24, 18, 32, 46, 22, 38, 26, 42, 14, 34].map((h, i) => (
                      <div
                        key={i}
                        className="w-1.5 bg-gradient-to-t from-purple-500 to-cyan-400 rounded-full animate-pulse"
                        style={{
                          height: `${h}px`,
                          animationDelay: `${i * 0.08}s`,
                        }}
                      />
                    ))}
                  </div>
                  <div className="text-xs text-purple-300 font-mono mt-1 flex items-center justify-center gap-2">
                    <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                    <span>
                      Speaking in {callLanguage === 'hindi' ? 'Hindi (Male Voice: Kabir)' : 'Indian English (Male Voice: Rohan)'}{' '}
                      via ElevenLabs
                    </span>
                  </div>
                </div>
              )}

              {/* Interactive # Sign Button Banner (Mandated User Requirement) */}
              <div className="bg-gradient-to-r from-amber-500/10 via-amber-500/20 to-amber-500/10 border-y border-amber-300/60 p-3.5 flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="flex items-center space-x-2.5">
                  <div className="w-8 h-8 rounded-lg bg-amber-500 text-white font-black text-lg flex items-center justify-center shadow-xs">
                    #
                  </div>
                  <div>
                    <div className="text-xs font-bold text-amber-950">
                      "For listening in English, press the # sign button"
                    </div>
                    <div className="text-[11px] text-amber-800">
                      Active: <strong className="uppercase font-bold">{callLanguage === 'english' ? 'English (Indian Male Voice)' : 'Hindi'}</strong> · Click button below or dialpad key # anytime during the call
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    id="press-hash-for-english-btn"
                    onClick={handlePressHashForEnglish}
                    className="bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs px-3.5 py-1.5 rounded-lg shadow-xs flex items-center gap-1.5 transition active:scale-95"
                    title="Press # to listen in typical Indian English male voice"
                  >
                    <Hash className="w-3.5 h-3.5" />
                    <span>Press # for English (Indian Voice)</span>
                  </button>

                  <button
                    id="press-star-for-hindi-btn"
                    onClick={handlePressStarForHindi}
                    className="bg-slate-700 hover:bg-slate-600 text-white font-bold text-xs px-3 py-1.5 rounded-lg shadow-xs flex items-center gap-1 transition active:scale-95"
                    title="Press * to listen in Hindi"
                  >
                    <span>*</span>
                    <span>हिन्दी (*)</span>
                  </button>
                </div>
              </div>

              {dtmfFeedback && (
                <div className="bg-cyan-50 border-b border-cyan-200 px-4 py-2 text-xs font-mono text-cyan-800 flex items-center justify-between">
                  <span>{dtmfFeedback}</span>
                  <span className="text-[10px] text-cyan-600">DTMF Active</span>
                </div>
              )}

              {/* Automated Script Text & Interactive Dialogue Node */}
              <div className="p-6 space-y-4">
                <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl">
                  <div className="flex flex-wrap items-center justify-between text-xs font-bold text-slate-500 mb-2 gap-2">
                    <span className="flex items-center gap-1.5 text-purple-700">
                      <Volume2 className="w-4 h-4 text-purple-600" />
                      AI Voice Dialogue Step: <span className="font-mono text-purple-900 bg-purple-100 px-1.5 py-0.5 rounded">{callNodeId}</span>
                    </span>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => speakNodeScript(callNodeId, callLanguage)}
                        className="text-[11px] bg-purple-50 hover:bg-purple-100 text-purple-700 border border-purple-200 px-2 py-0.5 rounded flex items-center gap-1 transition"
                        title="Replay Voice Audio"
                      >
                        <Volume2 className="w-3 h-3" />
                        <span>Replay Audio (दोबारा सुनें)</span>
                      </button>
                      <button
                        onClick={() => {
                          setCallNodeId('INITIAL');
                          speakNodeScript('INITIAL', callLanguage);
                        }}
                        className="text-[11px] bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 px-2 py-0.5 rounded flex items-center gap-1 transition"
                        title="Restart Dialogue from Root"
                      >
                        <RotateCcw className="w-3 h-3" />
                        <span>Restart Flow</span>
                      </button>
                    </div>
                  </div>

                  <p className="text-xs font-medium text-slate-800 whitespace-pre-line leading-relaxed italic bg-white p-3 rounded-lg border border-slate-200 shadow-2xs">
                    "{getFormattedScript(callNodeId, callLanguage)}"
                  </p>

                  {/* Resolution Notification Banner */}
                  {currentNode.isFinalResolution && (
                    <div className="mt-3 p-2.5 bg-emerald-50 border border-emerald-300 rounded-lg flex items-center justify-between">
                      <div className="flex items-center gap-2 text-xs font-bold text-emerald-800">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        <span>Resolution Complete! Autonomous Action logged in HRMS.</span>
                      </div>
                      <span className="text-[10px] bg-emerald-200 text-emerald-900 px-2 py-0.5 rounded font-mono">
                        {currentNode.resolutionType}
                      </span>
                    </div>
                  )}
                </div>

                {/* Available Options for Current Step (Clickable or Dialpad) */}
                {currentNode.options.length > 0 && (
                  <div className="bg-cyan-950/20 border border-cyan-500/30 p-3.5 rounded-xl space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-cyan-900 flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-cyan-600" />
                        Active Option Choices (Press Number Button on Dialpad):
                      </span>
                      <span className="text-[10px] text-cyan-700 font-mono">
                        Voice agent asks for number input
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {currentNode.options.map((opt) => (
                        <button
                          key={opt.id}
                          onClick={() => opt.dtmfKey && handleDialpadPress(opt.dtmfKey)}
                          className="flex items-center justify-between p-2 rounded-lg bg-white border border-cyan-200 hover:border-cyan-400 hover:bg-cyan-50 text-left transition shadow-2xs group"
                        >
                          <div className="flex items-center gap-2">
                            <span className="w-6 h-6 rounded-md bg-cyan-700 text-white font-bold text-xs flex items-center justify-center shrink-0">
                              {opt.dtmfKey || '#'}
                            </span>
                            <span className="text-xs font-semibold text-slate-800">
                              {callLanguage === 'hindi' ? opt.labelHindi : opt.label}
                            </span>
                          </div>
                          <span className="text-[10px] text-cyan-600 group-hover:underline shrink-0">
                            Press {opt.dtmfKey}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Telephone Keypad Simulation for Interactive DTMF */}
                <div className="bg-slate-900 text-white p-4 rounded-xl space-y-3">
                  <div className="flex items-center justify-between text-xs text-slate-300 font-mono">
                    <span>Interactive DTMF Telephone Dialpad</span>
                    <span className="text-[10px] text-cyan-400">Press '#' for English · '*' for Hindi</span>
                  </div>

                  <div className="grid grid-cols-3 gap-2.5 max-w-sm mx-auto">
                    {['1', '2', '3', '4', '5', '6', '7', '8', '9', '*', '0', '#'].map((k) => {
                      const isHash = k === '#';
                      const isStar = k === '*';
                      const activeOpt = currentNode.options.find((o) => o.dtmfKey === k);

                      return (
                        <button
                          key={k}
                          onClick={() => handleDialpadPress(k)}
                          className={`py-2 px-1.5 rounded-xl font-bold transition active:scale-95 flex flex-col items-center justify-center min-h-[58px] ${
                            activeOpt
                              ? 'bg-emerald-600 hover:bg-emerald-500 text-white ring-2 ring-emerald-300 shadow-md'
                              : isHash
                              ? 'bg-amber-600 hover:bg-amber-500 text-white shadow-md'
                              : isStar
                              ? 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-md'
                              : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                          }`}
                        >
                          <span className="text-base leading-none">{k}</span>
                          {activeOpt ? (
                            <span className="text-[9px] font-medium text-emerald-100 truncate max-w-[90px] mt-0.5">
                              {callLanguage === 'hindi' ? activeOpt.labelHindi.replace(/^[0-9️⃣\s\W]+/, '') : activeOpt.label.replace(/^[0-9️⃣\s\W]+/, '')}
                            </span>
                          ) : isHash ? (
                            <span className="text-[8px] font-normal text-amber-100 mt-0.5">English</span>
                          ) : isStar ? (
                            <span className="text-[8px] font-normal text-indigo-100 mt-0.5">हिन्दी</span>
                          ) : null}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Call Notes */}
                <div>
                  <label className="text-xs font-bold uppercase tracking-wider text-slate-500 block mb-1">
                    Call Notes & Employee Response
                  </label>
                  <textarea
                    id="call-notes-textarea"
                    rows={2}
                    placeholder="Enter notes (e.g. Employee pressed # for English, confirmed applied for leave on portal)..."
                    value={callNotes}
                    onChange={(e) => setCallNotes(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500"
                  />
                </div>

                {/* Outcome Action Buttons */}
                <div>
                  <label className="text-xs font-bold uppercase tracking-wider text-slate-500 block mb-2">
                    Select Call Outcome & Execute Automation Branch
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {/* Outcome 1: Completed */}
                    <button
                      id="outcome-completed-btn"
                      onClick={() => handleRecordOutcome('completed')}
                      className="flex items-start space-x-3 p-3 rounded-xl border border-emerald-200 bg-emerald-50/70 hover:bg-emerald-100 text-left transition group"
                    >
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                      <div>
                        <div className="text-xs font-bold text-emerald-900">
                          Employee Says Completed
                        </div>
                        <div className="text-[11px] text-emerald-700 mt-0.5">
                          Marks case Verified & Closed.
                        </div>
                      </div>
                    </button>

                    {/* Outcome 2: Not Completed */}
                    <button
                      id="outcome-not-completed-btn"
                      onClick={() => handleRecordOutcome('not_completed')}
                      className="flex items-start space-x-3 p-3 rounded-xl border border-rose-200 bg-rose-50/70 hover:bg-rose-100 text-left transition group"
                    >
                      <AlertOctagon className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                      <div>
                        <div className="text-xs font-bold text-rose-900">
                          Employee Says Not Completed
                        </div>
                        <div className="text-[11px] text-rose-700 mt-0.5">
                          Triggers immediate HR Escalation.
                        </div>
                      </div>
                    </button>

                    {/* Outcome 3: Needs Help */}
                    <button
                      id="outcome-needs-help-btn"
                      onClick={() => handleRecordOutcome('needs_help')}
                      className="flex items-start space-x-3 p-3 rounded-xl border border-amber-200 bg-amber-50/70 hover:bg-amber-100 text-left transition group"
                    >
                      <HelpCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                      <div>
                        <div className="text-xs font-bold text-amber-900">
                          Employee Needs Help / Portal Issue
                        </div>
                        <div className="text-[11px] text-amber-700 mt-0.5">
                          Alerts HR desk for personalized guidance.
                        </div>
                      </div>
                    </button>

                    {/* Outcome 4: No Answer */}
                    <button
                      id="outcome-no-answer-btn"
                      onClick={() => handleRecordOutcome('no_answer')}
                      className="flex items-start space-x-3 p-3 rounded-xl border border-slate-300 bg-slate-50 hover:bg-slate-100 text-left transition group"
                    >
                      <RotateCcw className="w-5 h-5 text-slate-600 shrink-0 mt-0.5" />
                      <div>
                        <div className="text-xs font-bold text-slate-900">
                          No Answer / Line Busy
                        </div>
                        <div className="text-[11px] text-slate-600 mt-0.5">
                          Logs attempt & keeps in pending call queue.
                        </div>
                      </div>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white p-12 rounded-2xl border border-slate-200 text-center text-slate-500">
              Select an employee from the escalation queue to initiate an automated call.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

