import React, { useState } from 'react';
import {
  Users,
  Clock,
  CalendarCheck,
  FileCheck2,
  PhoneCall,
  Play,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
} from 'lucide-react';
import { useAttendance } from '../context/AttendanceContext';

interface SummaryBannerProps {
  onOpenCheckModal?: () => void;
}

export const SummaryBanner: React.FC<SummaryBannerProps> = ({ onOpenCheckModal }) => {
  const { followUpCases, appSettings, runDailyCheckForDate } = useAttendance();

  const [selectedDate, setSelectedDate] = useState('2026-08-01');
  const [notification, setNotification] = useState<string | null>(null);

  // Stats calculation
  const total = followUpCases.length;
  const waitingReply = followUpCases.filter(
    (c) => c.status === 'waiting' || c.status === 'sent'
  ).length;
  const leaveNeeded = followUpCases.filter((c) => c.status === 'pending-leave').length;
  const regularization = followUpCases.filter((c) => c.status === 'pending-regularization').length;
  const callRequired = followUpCases.filter(
    (c) => c.status === 'call-required' || c.status === 'hr-escalated' || c.stage === 'stage_3_call'
  ).length;
  const openFollowUps = followUpCases.filter((c) => c.status !== 'verified').length;

  const handleRunCheck = () => {
    // Convert YYYY-MM-DD to DD-MMM-YYYY
    const [y, m, d] = selectedDate.split('-');
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const formatted = `${d}-${months[parseInt(m, 10) - 1]}-${y}`;

    const res = runDailyCheckForDate(formatted);
    setNotification(res.message);
    setTimeout(() => setNotification(null), 4000);
  };

  return (
    <div
      id="summary-banner"
      className="bg-gradient-to-r from-[#1E5A78] via-[#124B66] to-[#073B52] text-white p-6 shadow-md border-b border-[#0E4968]"
    >
      <div className="space-y-4">
        {/* Top: Title & Live Indicators */}
        <div className="space-y-2">
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-cyan-400/20 text-cyan-200 border border-cyan-400/30 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-cyan-300 animate-pulse" />
              TALENT CARRIAGE FOLLOW-UP DESK
            </span>

            <span className="px-2.5 py-0.5 rounded-full text-xs font-medium bg-white/10 text-slate-200">
              DPOD Lifestyle Workspace
            </span>

            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-emerald-300" />
              AI Classifier: Ready
            </span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white flex items-center gap-2">
            Attendance Follow-up Command Center
          </h1>
          <p className="text-xs sm:text-sm text-cyan-100/80 max-w-3xl leading-relaxed">
            Automated WhatsApp check-ins, 2-day reminder escalation, voice call desk, and calendar discrepancy regularization.
          </p>
        </div>

        {/* Date Selection Box - Spanning below subtitle, matching screenshot */}
        <div className="bg-[#08344B]/80 p-4 rounded-2xl border border-[#175C7E] flex flex-wrap items-end gap-3 shadow-inner">
          <div className="flex flex-col">
            <label className="text-[10px] font-bold uppercase tracking-wider text-cyan-200 mb-1.5">
              SELECT ATTENDANCE DATE
            </label>
            <input
              id="banner-date-input"
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="bg-[#052637] border border-[#175C7E] rounded-lg px-3 py-2 text-sm font-semibold text-white font-mono focus:outline-none focus:border-cyan-400 [color-scheme:dark] h-10 shadow-xs leading-normal"
            />
          </div>

          <button
            id="banner-run-check-btn"
            onClick={handleRunCheck}
            className="h-10 flex items-center space-x-2 bg-gradient-to-r from-[#0C737E] to-[#0A8D9B] hover:from-[#095F68] hover:to-[#087784] text-white px-5 py-2 rounded-lg text-xs font-bold shadow-md transition transform active:scale-95 border border-cyan-300/30"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>Run Daily Check</span>
          </button>
        </div>
      </div>

      {/* Notification toast if check was run */}
      {notification && (
        <div className="mt-4 p-2.5 bg-emerald-900/60 border border-emerald-400/40 rounded-lg text-xs text-emerald-200 flex items-center space-x-2 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-300 shrink-0" />
          <span>{notification}</span>
        </div>
      )}

      {/* KPI Cards Strip matching Screenshot 1 */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mt-6 pt-5 border-t border-white/10">
        {/* Total Cases */}
        <div className="bg-white/5 hover:bg-white/10 transition rounded-xl p-3 border border-white/10">
          <div className="flex items-center justify-between text-xs text-cyan-100/70 mb-1">
            <span>Total Cases</span>
            <Users className="w-3.5 h-3.5 text-cyan-300" />
          </div>
          <div className="text-2xl font-black text-white">{total}</div>
          <div className="text-[10px] text-cyan-200/60 mt-0.5">Aug 2026 register</div>
        </div>

        {/* Waiting Reply */}
        <div className="bg-white/5 hover:bg-white/10 transition rounded-xl p-3 border border-white/10">
          <div className="flex items-center justify-between text-xs text-amber-200/80 mb-1">
            <span>Waiting Reply</span>
            <Clock className="w-3.5 h-3.5 text-amber-300" />
          </div>
          <div className="text-2xl font-black text-[#FBBF24]">{waitingReply}</div>
          <div className="text-[10px] text-amber-200/60 mt-0.5">First WhatsApp sent</div>
        </div>

        {/* Leave Needed */}
        <div className="bg-white/5 hover:bg-white/10 transition rounded-xl p-3 border border-white/10">
          <div className="flex items-center justify-between text-xs text-cyan-100/70 mb-1">
            <span>Leave Needed</span>
            <CalendarCheck className="w-3.5 h-3.5 text-cyan-300" />
          </div>
          <div className="text-2xl font-black text-white">{leaveNeeded}</div>
          <div className="text-[10px] text-cyan-200/60 mt-0.5">Option 1 · Confirmed absent</div>
        </div>

        {/* Regularization */}
        <div className="bg-white/5 hover:bg-white/10 transition rounded-xl p-3 border border-white/10">
          <div className="flex items-center justify-between text-xs text-cyan-100/70 mb-1">
            <span>Regularization</span>
            <FileCheck2 className="w-3.5 h-3.5 text-cyan-300" />
          </div>
          <div className="text-2xl font-black text-white">{regularization}</div>
          <div className="text-[10px] text-cyan-200/60 mt-0.5">Option 2 / 4 · Working</div>
        </div>

        {/* Call Required */}
        <div className="bg-rose-500/10 hover:bg-rose-500/15 transition rounded-xl p-3 border border-rose-500/30">
          <div className="flex items-center justify-between text-xs text-rose-200 mb-1">
            <span>Call Required</span>
            <PhoneCall className="w-3.5 h-3.5 text-rose-400 animate-pulse" />
          </div>
          <div className="text-2xl font-black text-[#FB7185]">{callRequired}</div>
          <div className="text-[10px] text-rose-200/70 mt-0.5">Day 3 / No reply</div>
        </div>

        {/* Hero: Open Follow-ups */}
        <div className="bg-gradient-to-br from-cyan-500/25 to-blue-600/25 rounded-xl p-3 border border-cyan-400/60 shadow-inner">
          <div className="flex items-center justify-between text-xs text-cyan-200 font-bold mb-1">
            <span>Open Follow-ups</span>
            <AlertTriangle className="w-3.5 h-3.5 text-cyan-300" />
          </div>
          <div className="text-2xl font-black text-[#67E8F9]">{openFollowUps}</div>
          <div className="text-[10px] text-cyan-200/70 mt-0.5">Active cases in pipeline</div>
        </div>
      </div>
    </div>
  );
};
