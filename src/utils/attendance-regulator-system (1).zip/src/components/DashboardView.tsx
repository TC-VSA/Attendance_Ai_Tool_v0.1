import React from 'react';
import {
  MessageSquare,
  Clock,
  PhoneCall,
  CheckCircle2,
  AlertTriangle,
  Play,
  ArrowRight,
  Sparkles,
  ChevronRight,
  Building2,
  FileSpreadsheet,
} from 'lucide-react';
import { useAttendance } from '../context/AttendanceContext';
import { CasesTableView } from './CasesTableView';
import { NavTab } from './Sidebar';

interface DashboardViewProps {
  setActiveTab: (tab: NavTab) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ setActiveTab }) => {
  const { followUpCases, setSelectedCaseId } = useAttendance();

  const handleOpenWhatsApp = (caseId: string) => {
    setSelectedCaseId(caseId);
    setActiveTab('whatsapp');
  };

  const handleOpenCallCenter = (caseId: string) => {
    setSelectedCaseId(caseId);
    setActiveTab('callcenter');
  };

  const pendingCount = followUpCases.filter((c) => c.status !== 'verified').length;
  const urgentCalls = followUpCases.filter(
    (c) => c.status === 'call-required' || c.status === 'hr-escalated'
  );

  return (
    <div className="space-y-6">
      {/* Alert banner if calls are urgent matching screenshot 1 */}
      {urgentCalls.length > 0 && (
        <div className="p-4 bg-[#FFF1F2] border border-[#FECDD3] rounded-2xl flex items-center justify-between shadow-xs">
          <div className="flex items-center space-x-3.5">
            <div className="w-10 h-10 rounded-2xl bg-[#FFE4E6] text-[#E11D48] flex items-center justify-center shrink-0">
              <PhoneCall className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-black text-[#9F1239] uppercase tracking-wider">
                ACTION REQUIRED: {urgentCalls.length} {urgentCalls.length === 1 ? 'ESCALATIONS' : 'ESCALATIONS'} PENDING AUTOMATED VOICE CALL
              </h4>
              <p className="text-xs text-[#BE123C] mt-0.5">
                Employees have either exceeded the 2-day reminder window without resolution or explicitly requested assistance.
              </p>
            </div>
          </div>

          <button
            id="dashboard-open-call-center-btn"
            onClick={() => setActiveTab('callcenter')}
            className="flex items-center space-x-1.5 bg-[#E11D48] hover:bg-[#BE123C] text-white px-5 py-2.5 rounded-2xl text-xs font-bold transition shadow-sm shrink-0"
          >
            <span>Open Call Desk</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Main Cases Table Section */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-base font-black text-slate-900">
              Active Follow-up Pipeline
            </h3>
            <p className="text-xs text-slate-500">
              Real-time attendance cases, employee responses, and next workflow steps.
            </p>
          </div>

          <div className="flex items-center space-x-2">
            <button
              id="upload-shortcut-btn"
              onClick={() => setActiveTab('upload')}
              className="flex items-center space-x-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 py-1.5 rounded-lg text-xs font-bold transition"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-teal-600" />
              <span>Import .xlsx</span>
            </button>
            <button
              id="workflow-map-shortcut-btn"
              onClick={() => setActiveTab('workflow')}
              className="flex items-center space-x-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 py-1.5 rounded-lg text-xs font-bold transition"
            >
              <Sparkles className="w-3.5 h-3.5 text-cyan-600" />
              <span>View Workflow Map</span>
            </button>
          </div>
        </div>

        <CasesTableView
          onOpenWhatsApp={handleOpenWhatsApp}
          onOpenCallCenter={handleOpenCallCenter}
        />
      </div>
    </div>
  );
};
