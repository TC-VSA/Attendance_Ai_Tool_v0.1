import React, { useState } from 'react';
import { useAttendance } from '../context/AttendanceContext';
import {
  Users,
  Building,
  Laptop,
  Briefcase,
  Coffee,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Play,
  Radio,
  MapPin,
  Calendar,
  Sparkles,
} from 'lucide-react';

export const LiveTeamRadar: React.FC = () => {
  const {
    employees,
    checkInRecords,
    calendarEvents,
    liveActivities,
    currentTime,
    checkIn,
    startBreak,
    endBreak,
    checkOut,
  } = useAttendance();

  const todayStr = currentTime.toISOString().split('T')[0];
  const [filterMode, setFilterMode] = useState<'all' | 'office' | 'remote' | 'breaks' | 'irregular'>('all');

  // Compute live presence for each employee
  const employeeStatusList = employees.map((emp) => {
    const record = checkInRecords.find((r) => r.employeeId === emp.id && r.date === todayStr);
    const activeBreak = record?.breaks.find((b) => !b.endTime);

    // Check if employee has an active calendar meeting right now
    const nowMinutes = currentTime.getHours() * 60 + currentTime.getMinutes();
    const activeMeeting = calendarEvents.find((ev) => {
      if (ev.employeeId !== emp.id || ev.date !== todayStr) return false;
      const [sH, sM] = ev.startTime.split(':').map(Number);
      const [eH, eM] = ev.endTime.split(':').map(Number);
      const sMin = sH * 60 + sM;
      const eMin = eH * 60 + eM;
      return nowMinutes >= sMin && nowMinutes <= eMin;
    });

    let statusType: 'in_office' | 'remote' | 'client_site' | 'on_break' | 'checked_out' | 'absent' = 'absent';

    if (record) {
      if (record.checkOutTime) {
        statusType = 'checked_out';
      } else if (activeBreak) {
        statusType = 'on_break';
      } else if (record.workMode === 'remote') {
        statusType = 'remote';
      } else if (record.workMode === 'client_site' || record.workMode === 'business_trip') {
        statusType = 'client_site';
      } else {
        statusType = 'in_office';
      }
    }

    return {
      employee: emp,
      record,
      activeBreak,
      activeMeeting,
      statusType,
    };
  });

  // KPI counters
  const totalEmployees = employees.length;
  const inOfficeCount = employeeStatusList.filter((e) => e.statusType === 'in_office').length;
  const remoteCount = employeeStatusList.filter((e) => e.statusType === 'remote').length;
  const clientSiteCount = employeeStatusList.filter((e) => e.statusType === 'client_site').length;
  const onBreakCount = employeeStatusList.filter((e) => e.statusType === 'on_break').length;
  const irregularCount = employeeStatusList.filter(
    (e) => e.record && e.record.regularityStatus === 'irregular'
  ).length;

  const filteredEmployees = employeeStatusList.filter((item) => {
    if (filterMode === 'all') return true;
    if (filterMode === 'office') return item.statusType === 'in_office';
    if (filterMode === 'remote') return item.statusType === 'remote';
    if (filterMode === 'breaks') return item.statusType === 'on_break';
    if (filterMode === 'irregular') return item.record?.regularityStatus === 'irregular';
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Top Presence Metrics Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
            🏢 In-Office
          </span>
          <div className="flex items-baseline space-x-2 mt-1">
            <span className="text-2xl font-extrabold text-slate-900">{inOfficeCount}</span>
            <span className="text-xs text-slate-500 font-medium">employees</span>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
            💻 Remote / WFH
          </span>
          <div className="flex items-baseline space-x-2 mt-1">
            <span className="text-2xl font-extrabold text-indigo-600">{remoteCount}</span>
            <span className="text-xs text-slate-500 font-medium">active</span>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
            🚗 Client Site
          </span>
          <div className="flex items-baseline space-x-2 mt-1">
            <span className="text-2xl font-extrabold text-blue-600">{clientSiteCount}</span>
            <span className="text-xs text-slate-500 font-medium">on duty</span>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
            ☕ On Break
          </span>
          <div className="flex items-baseline space-x-2 mt-1">
            <span className="text-2xl font-extrabold text-amber-600">{onBreakCount}</span>
            <span className="text-xs text-slate-500 font-medium">paused</span>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
            ⚠️ Irregularities
          </span>
          <div className="flex items-baseline space-x-2 mt-1">
            <span className="text-2xl font-extrabold text-amber-600">{irregularCount}</span>
            <span className="text-xs text-slate-500 font-medium">flagged</span>
          </div>
        </div>
      </div>

      {/* Main Grid: Live Presence Roster + Live Activity Stream */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Employee Roster */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 gap-3">
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-base font-bold text-slate-900">
                  Real-Time Team Presence Radar
                </h2>
                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mr-1.5 animate-pulse" />
                  Live Sync
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Live attendance status, current calendar engagements, and physical locations
              </p>
            </div>

            {/* Filter Buttons */}
            <div className="flex flex-wrap items-center gap-1.5 bg-slate-100 p-1 rounded-xl text-xs font-medium">
              <button
                onClick={() => setFilterMode('all')}
                className={`px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${
                  filterMode === 'all' ? 'bg-white text-slate-900 shadow-2xs font-semibold' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                All
              </button>
              <button
                onClick={() => setFilterMode('office')}
                className={`px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${
                  filterMode === 'office' ? 'bg-white text-slate-900 shadow-2xs font-semibold' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                In-Office
              </button>
              <button
                onClick={() => setFilterMode('remote')}
                className={`px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${
                  filterMode === 'remote' ? 'bg-white text-slate-900 shadow-2xs font-semibold' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Remote
              </button>
              <button
                onClick={() => setFilterMode('breaks')}
                className={`px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${
                  filterMode === 'breaks' ? 'bg-white text-slate-900 shadow-2xs font-semibold' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Breaks
              </button>
              <button
                onClick={() => setFilterMode('irregular')}
                className={`px-2.5 py-1 rounded-lg transition-colors cursor-pointer ${
                  filterMode === 'irregular' ? 'bg-white text-slate-900 shadow-2xs font-semibold' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Irregular
              </button>
            </div>
          </div>

          {/* Employee Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {filteredEmployees.map(({ employee, record, activeBreak, activeMeeting, statusType }) => (
              <div
                key={employee.id}
                className="border border-slate-200 rounded-xl p-4 hover:border-slate-300 transition-all bg-white shadow-2xs space-y-3"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="relative">
                      <img
                        src={employee.avatar}
                        alt={employee.name}
                        className="w-10 h-10 rounded-full object-cover ring-2 ring-slate-100"
                      />
                      <span
                        className={`absolute bottom-0 right-0 w-3 h-3 rounded-full ring-2 ring-white ${
                          statusType === 'in_office'
                            ? 'bg-emerald-500'
                            : statusType === 'remote'
                            ? 'bg-indigo-500'
                            : statusType === 'client_site'
                            ? 'bg-blue-500'
                            : statusType === 'on_break'
                            ? 'bg-amber-500'
                            : 'bg-slate-300'
                        }`}
                      />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-slate-900">
                        {employee.name}
                      </h4>
                      <p className="text-[11px] text-slate-500">
                        {employee.department}
                      </p>
                    </div>
                  </div>

                  {/* Status Tag */}
                  <div>
                    {statusType === 'in_office' ? (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center">
                        <Building className="w-3 h-3 mr-1" />
                        Office
                      </span>
                    ) : statusType === 'remote' ? (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200 flex items-center">
                        <Laptop className="w-3 h-3 mr-1" />
                        Remote
                      </span>
                    ) : statusType === 'client_site' ? (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-blue-50 text-blue-700 border border-blue-200 flex items-center">
                        <Briefcase className="w-3 h-3 mr-1" />
                        Client Site
                      </span>
                    ) : statusType === 'on_break' ? (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-50 text-amber-700 border border-amber-200 flex items-center animate-pulse">
                        <Coffee className="w-3 h-3 mr-1" />
                        On Break
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 text-slate-600">
                        Not In
                      </span>
                    )}
                  </div>
                </div>

                {/* Punch Details */}
                <div className="bg-slate-50 rounded-lg p-2.5 text-[11px] space-y-1">
                  <div className="flex justify-between text-slate-600">
                    <span>Check-In Time:</span>
                    <span className="font-mono-code font-bold text-slate-800">
                      {record ? record.checkInTime.slice(0, 5) : '—'}
                    </span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span>Location Tag:</span>
                    <span className="truncate max-w-[140px] text-slate-800 text-right">
                      {record?.locationName || 'N/A'}
                    </span>
                  </div>
                </div>

                {/* Calendar Conflict / Meeting Banner */}
                {activeMeeting ? (
                  <div className="p-2 bg-indigo-50/80 border border-indigo-200 rounded-lg text-[11px] text-indigo-900 flex items-center space-x-1.5">
                    <Calendar className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                    <span className="truncate">
                      In Meeting: &ldquo;{activeMeeting.title}&rdquo; ({activeMeeting.startTime} - {activeMeeting.endTime})
                    </span>
                  </div>
                ) : record?.regularityStatus === 'irregular' ? (
                  <div className="p-2 bg-amber-50/80 border border-amber-200 rounded-lg text-[11px] text-amber-900 flex items-center space-x-1.5">
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                    <span className="truncate">
                      {record.flags[0] || 'Late check-in recorded'}
                    </span>
                  </div>
                ) : null}
              </div>
            ))}
          </div>
        </div>

        {/* Right Col: Live Real-Time Check-In Stream */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-4">
              <h3 className="text-sm font-bold text-slate-900 flex items-center">
                <Radio className="w-4 h-4 mr-1.5 text-indigo-600 animate-pulse" />
                Live Punch Stream
              </h3>
              <span className="text-[10px] text-slate-400 font-mono-code">
                Real-Time Socket Feed
              </span>
            </div>

            {/* Scrollable feed items */}
            <div className="space-y-3.5 max-h-[500px] overflow-y-auto pr-1">
              {liveActivities.map((act) => (
                <div
                  key={act.id}
                  className="flex items-start space-x-3 text-xs pb-3 border-b border-slate-50 last:border-0"
                >
                  <img
                    src={act.employeeAvatar}
                    alt={act.employeeName}
                    className="w-7 h-7 rounded-full object-cover shrink-0 mt-0.5"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-900 truncate">
                        {act.employeeName}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono-code shrink-0 ml-1">
                        {act.timestamp}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-600 mt-0.5 leading-relaxed">
                      {act.details || `Performed ${act.action.replace('_', ' ')}`}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Live Punch Test Simulator */}
          <div className="mt-6 pt-4 border-t border-slate-100">
            <p className="text-[11px] font-semibold text-slate-500 mb-2 uppercase tracking-wide">
              Test Real-Time Event Stream
            </p>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() =>
                  checkIn(
                    'office',
                    'HQ San Francisco - Floor 7',
                    'Simulated automated card swipe terminal'
                  )
                }
                className="py-1.5 px-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-medium rounded-lg transition-colors cursor-pointer truncate"
              >
                + Simulate Punch In
              </button>
              <button
                onClick={() => checkOut('Simulated turnstile tap out')}
                className="py-1.5 px-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-medium rounded-lg transition-colors cursor-pointer truncate"
              >
                + Simulate Punch Out
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
