import React, { useState } from 'react';
import {
  UploadCloud,
  FileSpreadsheet,
  CheckCircle2,
  AlertCircle,
  Play,
  ArrowRight,
  RefreshCw,
  Sparkles,
} from 'lucide-react';
import { useAttendance } from '../context/AttendanceContext';
import { parseTimeOfficeWorkbook, ParseExcelResult } from '../utils/excelParser';
import { FollowUpCase } from '../types';

interface UploadViewProps {
  onSuccessNavigate?: () => void;
}

export const UploadView: React.FC<UploadViewProps> = ({ onSuccessNavigate }) => {
  const { importParsedCases, appSettings, updateAppSettings } = useAttendance();

  const [isDragging, setIsDragging] = useState(false);
  const [loading, setLoading] = useState(false);
  const [parsedResult, setParsedResult] = useState<ParseExcelResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [testPhoneOverride, setTestPhoneOverride] = useState(appSettings.testPhoneNumber || '919876543210');

  const handleFileUpload = async (file: File) => {
    try {
      setLoading(true);
      setError(null);
      const res = await parseTimeOfficeWorkbook(file, testPhoneOverride);
      setParsedResult(res);
    } catch (err: any) {
      setError(err?.message || 'Failed to parse Excel file. Please ensure valid TimeOffice format.');
    } finally {
      setLoading(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileUpload(e.dataTransfer.files[0]);
    }
  };

  const handleLoadDemoRegister = () => {
    // Generate sample TimeOffice parsed dataset
    const demoParsedCases: FollowUpCase[] = [
      {
        id: `demo-import-1-${Date.now()}`,
        employeeName: 'Deepak Gajjar',
        employeeCode: 'DPOD-003',
        department: 'Operations & Procurement',
        reportingManager: 'Mayank Talpada',
        mobileNumber: testPhoneOverride || '919876543210',
        date: '02-Aug-2026',
        code: 'A|A',
        reply: 'Waiting',
        action: 'Pending response',
        status: 'waiting',
        stage: 'stage_1_initial',
        firstMessageSentAt: '02-Aug-2026 10:00',
        messages: [
          {
            id: `msg-demo-1`,
            sender: 'system',
            text: 'Hi Deepak, our attendance record shows you are marked absent on 02-Aug-2026. Please confirm the reason by choosing one option below.',
            timestamp: '10:00 AM',
            status: 'delivered',
            isTemplate: true,
            buttons: [
              '1. Yes, I was absent',
              '2. No, I was working',
              '3. I have already applied leave',
              '4. I have already sent regularization request',
            ],
          },
        ],
      },
      {
        id: `demo-import-2-${Date.now()}`,
        employeeName: 'Aelin Gajjar',
        employeeCode: 'DPOD-012',
        department: 'Interior & Architectural Design',
        reportingManager: 'Mayank Talpada',
        mobileNumber: testPhoneOverride || '919876543210',
        date: '03-Aug-2026',
        code: 'P|A',
        reply: 'Waiting',
        action: 'Pending response',
        status: 'waiting',
        stage: 'stage_1_initial',
        firstMessageSentAt: '03-Aug-2026 10:00',
        messages: [
          {
            id: `msg-demo-2`,
            sender: 'system',
            text: 'Hi Aelin, our attendance record shows you are marked absent on 03-Aug-2026 (second half). Please confirm the reason by choosing one option below.',
            timestamp: '10:00 AM',
            status: 'delivered',
            isTemplate: true,
            buttons: [
              '1. Yes, I was absent',
              '2. No, I was working',
              '3. I have already applied leave',
              '4. I have already sent regularization request',
            ],
          },
        ],
      },
      {
        id: `demo-import-3-${Date.now()}`,
        employeeName: 'Kavita Mehta',
        employeeCode: 'DPOD-082',
        department: 'Human Resources & Talent',
        reportingManager: 'Priya Sharma',
        mobileNumber: testPhoneOverride || '919876543210',
        date: '04-Aug-2026',
        code: 'A|P',
        reply: 'Waiting',
        action: 'Pending response',
        status: 'waiting',
        stage: 'stage_1_initial',
        firstMessageSentAt: '04-Aug-2026 10:00',
        messages: [
          {
            id: `msg-demo-3`,
            sender: 'system',
            text: 'Hi Kavita, our attendance record shows you are marked absent on 04-Aug-2026 (first half). Please confirm the reason by choosing one option below.',
            timestamp: '10:00 AM',
            status: 'delivered',
            isTemplate: true,
            buttons: [
              '1. Yes, I was absent',
              '2. No, I was working',
              '3. I have already applied leave',
              '4. I have already sent regularization request',
            ],
          },
        ],
      },
    ];

    setParsedResult({
      cases: demoParsedCases,
      totalRows: 124,
      totalAbsentsFound: 3,
      sheetName: 'Attendance',
      yearDetected: 2026,
    });
  };

  const handleConfirmImport = () => {
    if (!parsedResult || parsedResult.cases.length === 0) return;
    importParsedCases(parsedResult.cases);
    updateAppSettings({ testPhoneNumber: testPhoneOverride });
    if (onSuccessNavigate) {
      onSuccessNavigate();
    }
  };

  return (
    <div className="space-y-6">
      {/* Upload Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-cyan-100 text-cyan-800 border border-cyan-200 flex items-center gap-1.5">
              <UploadCloud className="w-3.5 h-3.5" />
              TimeOffice Register Ingestion
            </span>
            <span className="text-xs text-slate-500 font-medium">Auto-Parsing Engine</span>
          </div>
          <h2 className="text-2xl font-black text-slate-900 mt-1">
            Import Attendance Register (.xlsx)
          </h2>
          <p className="text-xs text-slate-600 max-w-2xl">
            Upload exported monthly TimeOffice sheets. The system automatically inspects attendance codes (`A|A`, `P|A`, `A|P`), links employee contact details, and enqueues follow-up cases.
          </p>
        </div>

        {/* Demo Register Quick Loader */}
        <button
          id="load-demo-register-btn"
          onClick={handleLoadDemoRegister}
          className="flex items-center space-x-2 bg-slate-900 hover:bg-slate-800 text-white px-4 py-2.5 rounded-xl text-xs font-bold shadow-sm transition shrink-0"
        >
          <Sparkles className="w-4 h-4 text-cyan-300" />
          <span>Load August 2026 Sample Register</span>
        </button>
      </div>

      {/* Test Phone Number Override Configuration */}
      <div className="bg-amber-50 border border-amber-200 p-4 rounded-xl flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <div className="text-xs font-bold text-amber-900">
            Testing Override (Recipient Phone Number)
          </div>
          <div className="text-[11px] text-amber-700">
            For safe testing in dry-run mode, all parsed records can route WhatsApp notifications to this phone number.
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <input
            id="test-phone-override-input"
            type="text"
            value={testPhoneOverride}
            onChange={(e) => setTestPhoneOverride(e.target.value)}
            placeholder="e.g. 919876543210"
            className="bg-white border border-amber-300 rounded px-3 py-1.5 text-xs font-mono font-bold text-slate-800 focus:outline-none focus:ring-1 focus:ring-amber-500"
          />
        </div>
      </div>

      {/* Drag & Drop File Zone */}
      <div
        id="excel-drop-zone"
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
        className={`border-2 border-dashed rounded-2xl p-8 text-center transition ${
          isDragging
            ? 'border-teal-500 bg-teal-50/50'
            : 'border-slate-300 hover:border-teal-400 bg-white'
        }`}
      >
        <div className="max-w-md mx-auto space-y-3">
          <div className="w-14 h-14 rounded-2xl bg-teal-50 text-teal-600 flex items-center justify-center mx-auto shadow-inner">
            <FileSpreadsheet className="w-7 h-7" />
          </div>

          <h3 className="text-base font-black text-slate-900">
            Drag and drop your TimeOffice Attendance Excel (.xlsx) file
          </h3>
          <p className="text-xs text-slate-500">
            Supports standard exported TimeOffice format with day columns (e.g. 1/8 | Sat) and employee codes.
          </p>

          <div className="pt-2">
            <label
              htmlFor="excel-file-input"
              className="inline-flex items-center space-x-2 bg-teal-700 hover:bg-teal-600 text-white px-5 py-2.5 rounded-xl text-xs font-bold cursor-pointer transition shadow-sm"
            >
              <UploadCloud className="w-4 h-4" />
              <span>Browse Computer</span>
            </label>
            <input
              id="excel-file-input"
              type="file"
              accept=".xlsx,.xls"
              onChange={(e) => {
                if (e.target.files && e.target.files[0]) {
                  handleFileUpload(e.target.files[0]);
                }
              }}
              className="hidden"
            />
          </div>
        </div>
      </div>

      {/* Loading state */}
      {loading && (
        <div className="p-8 text-center bg-white rounded-2xl border border-slate-200 text-teal-700 font-bold text-xs flex items-center justify-center space-x-2">
          <RefreshCw className="w-4 h-4 animate-spin" />
          <span>Parsing TimeOffice register structure and identifying absentee flags...</span>
        </div>
      )}

      {/* Error state */}
      {error && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-center space-x-2">
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Parsed Result Preview */}
      {parsedResult && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden space-y-4 p-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pb-4 border-b border-slate-200 gap-3">
            <div>
              <div className="text-xs font-bold text-teal-700 uppercase tracking-wider">
                Parse Summary
              </div>
              <h3 className="text-lg font-black text-slate-900 mt-0.5">
                Found {parsedResult.totalAbsentsFound} Absentee Cases across {parsedResult.totalRows} Employees
              </h3>
              <div className="text-xs text-slate-500">
                Sheet: <span className="font-semibold">{parsedResult.sheetName}</span> · Year: {parsedResult.yearDetected}
              </div>
            </div>

            <button
              id="confirm-import-btn"
              onClick={handleConfirmImport}
              className="flex items-center space-x-2 bg-emerald-600 hover:bg-emerald-500 text-white px-5 py-2.5 rounded-xl text-xs font-bold transition shadow-md shrink-0"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Import to Active Follow-up Cases</span>
              <ArrowRight className="w-3.5 h-3.5 ml-1" />
            </button>
          </div>

          {/* Preview Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 uppercase font-bold text-[10px] tracking-wider border-b border-slate-200">
                <tr>
                  <th className="py-2.5 px-3">Employee</th>
                  <th className="py-2.5 px-3">Dept & Manager</th>
                  <th className="py-2.5 px-3">Absent Date</th>
                  <th className="py-2.5 px-3">Session Code</th>
                  <th className="py-2.5 px-3">Mobile</th>
                  <th className="py-2.5 px-3">Next Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {parsedResult.cases.map((c) => (
                  <tr key={c.id} className="hover:bg-slate-50/80">
                    <td className="py-2.5 px-3 font-bold text-slate-900">
                      {c.employeeName}
                      <span className="block text-[10px] text-slate-400 font-mono">
                        {c.employeeCode}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-slate-600">
                      {c.department}
                      <span className="block text-[10px] text-slate-400 font-medium">
                        Mgr: {c.reportingManager}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 font-mono font-semibold text-slate-800">
                      {c.date}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded bg-rose-100 text-rose-800 font-mono font-bold text-[11px]">
                        {c.code}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 font-mono text-slate-600">
                      +{c.mobileNumber}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="text-[11px] text-teal-700 font-semibold">
                        Ready to send First WhatsApp
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
