import React, { useState } from 'react';
import { useAttendance } from '../context/AttendanceContext';
import {
  Clock,
  Calendar,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Sparkles,
  ChevronDown,
  Building2,
  FileCheck2,
  Users2,
  BarChart3,
  CalendarClock,
} from 'lucide-react';

interface HeaderProps {
  activeTab: 'terminal' | 'approvals' | 'radar' | 'analytics';
  setActiveTab: (tab: 'terminal' | 'approvals' | 'radar' | 'analytics') => void;
  onOpenRegularizationModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onOpenRegularizationModal,
}) => {
  const {
    employees,
    currentEmployee,
    setCurrentEmployeeId,
    regularizationRequests,
    currentTime,
    resetToDemoData,
    checkInRecords,
  } = useAttendance();

  const [employeeDropdownOpen, setEmployeeDropdownOpen] = useState(false);

  // Count pending regularizations
  const pendingRequestsCount = regularizationRequests.filter(
    (r) => r.status === 'pending'
  ).length;

  // Count irregular records today
  const todayStr = currentTime.toISOString().split('T')[0];
  const irregularCount = checkInRecords.filter(
    (r) => r.date === todayStr && r.regularityStatus === 'irregular'
  ).length;

  // Format real-time clock
  const timeFormatted = currentTime.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true,
  });

  const dateFormatted = currentTime.toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-xs">
      {/* Top Banner with Clock & User Switcher */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand & Live System Status */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center text-white shadow-sm shadow-indigo-200">
              <CalendarClock className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-slate-900 text-lg tracking-tight">
                  Attendance Regulator
                </span>
                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-emerald-50 text-emerald-700 border border-emerald-200">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mr-1.5 animate-pulse" />
                  Live Sync
                </span>
              </div>
              <p className="text-xs text-slate-500 hidden sm:block">
                Calendar Schedule Cross-Check & Real-Time Presence
              </p>
            </div>
          </div>

          {/* Center: Live Digital Clock */}
          <div className="hidden md:flex items-center space-x-3 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg">
            <Clock className="w-4 h-4 text-indigo-600" />
            <div className="text-left font-mono-code">
              <span className="text-sm font-semibold text-slate-900">
                {timeFormatted}
              </span>
              <span className="text-xs text-slate-500 ml-2">
                {dateFormatted}
              </span>
            </div>
          </div>

          {/* Right: Persona Switcher & Fast Actions */}
          <div className="flex items-center space-x-3">
            {/* Quick Regularize Button */}
            <button
              onClick={onOpenRegularizationModal}
              className="inline-flex items-center px-3 py-1.5 text-xs font-semibold text-indigo-700 bg-indigo-50 border border-indigo-200 rounded-lg hover:bg-indigo-100 transition-colors shadow-2xs cursor-pointer"
              title="Submit or view attendance regularization request"
            >
              <FileCheck2 className="w-3.5 h-3.5 mr-1.5" />
              Regularize
            </button>

            {/* Persona Switcher Dropdown */}
            <div className="relative">
              <button
                onClick={() => setEmployeeDropdownOpen(!employeeDropdownOpen)}
                className="flex items-center space-x-2.5 p-1.5 pl-2 rounded-xl border border-slate-200 hover:border-slate-300 hover:bg-slate-50 transition-colors text-left cursor-pointer"
              >
                <img
                  src={currentEmployee.avatar}
                  alt={currentEmployee.name}
                  className="w-8 h-8 rounded-full object-cover ring-2 ring-indigo-500/20"
                />
                <div className="hidden sm:block text-left">
                  <div className="text-xs font-semibold text-slate-900 leading-tight flex items-center">
                    {currentEmployee.name}
                    {currentEmployee.isManager && (
                      <span className="ml-1.5 px-1 py-0.2 text-[10px] font-bold bg-amber-100 text-amber-800 rounded">
                        HR / Mgr
                      </span>
                    )}
                  </div>
                  <div className="text-[11px] text-slate-500 leading-tight">
                    {currentEmployee.role}
                  </div>
                </div>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </button>

              {employeeDropdownOpen && (
                <div className="absolute right-0 mt-2 w-72 bg-white rounded-xl shadow-xl border border-slate-200 py-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                  <div className="px-3 py-1.5 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                    Switch Test Employee Persona
                  </div>
                  <div className="divide-y divide-slate-100 max-h-80 overflow-y-auto">
                    {employees.map((emp) => (
                      <button
                        key={emp.id}
                        onClick={() => {
                          setCurrentEmployeeId(emp.id);
                          setEmployeeDropdownOpen(false);
                        }}
                        className={`w-full px-3 py-2.5 flex items-center space-x-3 text-left hover:bg-slate-50 transition-colors ${
                          emp.id === currentEmployee.id ? 'bg-indigo-50/60' : ''
                        }`}
                      >
                        <img
                          src={emp.avatar}
                          alt={emp.name}
                          className="w-8 h-8 rounded-full object-cover"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="text-xs font-semibold text-slate-900 truncate flex items-center justify-between">
                            <span>{emp.name}</span>
                            {emp.id === 'emp-2' && (
                              <span className="text-[10px] bg-amber-50 text-amber-700 px-1.5 py-0.5 rounded border border-amber-200">
                                Discrepancy
                              </span>
                            )}
                            {emp.isManager && (
                              <span className="text-[10px] bg-purple-50 text-purple-700 px-1.5 py-0.5 rounded border border-purple-200">
                                Approver
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-slate-500 truncate">
                            {emp.department} • {emp.role}
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>

                  <div className="pt-2 mt-1 border-t border-slate-100 px-3">
                    <button
                      onClick={() => {
                        resetToDemoData();
                        setEmployeeDropdownOpen(false);
                      }}
                      className="w-full flex items-center justify-center space-x-1.5 py-1.5 text-xs text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Reset Demo Data</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex space-x-1 sm:space-x-4 border-t border-slate-100 pt-2 pb-2 overflow-x-auto scrollbar-none">
          <button
            onClick={() => setActiveTab('terminal')}
            className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg text-xs sm:text-sm font-medium transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'terminal'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>My Punch & Calendar</span>
            {irregularCount > 0 && (
              <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                activeTab === 'terminal' ? 'bg-indigo-800 text-indigo-100' : 'bg-amber-100 text-amber-800'
              }`}>
                {irregularCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('approvals')}
            className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg text-xs sm:text-sm font-medium transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'approvals'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <FileCheck2 className="w-4 h-4" />
            <span>Regularization Desk</span>
            {pendingRequestsCount > 0 && (
              <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                activeTab === 'approvals' ? 'bg-indigo-800 text-indigo-100' : 'bg-red-500 text-white'
              }`}>
                {pendingRequestsCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('radar')}
            className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg text-xs sm:text-sm font-medium transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'radar'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Users2 className="w-4 h-4" />
            <span>Live Team Radar</span>
          </button>

          <button
            onClick={() => setActiveTab('analytics')}
            className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg text-xs sm:text-sm font-medium transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'analytics'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            <span>Policies & Analytics</span>
          </button>
        </div>
      </div>
    </header>
  );
};
