import React, { useState } from 'react';
import {
  GitFork,
  MessageSquare,
  Clock,
  PhoneCall,
  CheckCircle,
  AlertTriangle,
  Users,
  ChevronRight,
  ShieldAlert,
  HelpCircle,
  Sparkles,
  Zap,
  Play,
  RotateCw,
  CheckCircle2,
  PhoneOutgoing,
  UserCheck,
  Trash2,
  Activity,
} from 'lucide-react';
import { useAttendance } from '../context/AttendanceContext';

export const WorkflowVisualizer: React.FC = () => {
  const {
    followUpCases,
    selectedCaseId,
    setSelectedCaseId,
    appSettings,
    updateAppSettings,
    runWorkflowAutoTrigger,
    autoTriggerLogs,
    clearAutoTriggerLogs,
  } = useAttendance();

  const [filterCaseId, setFilterCaseId] = useState<string>(selectedCaseId || followUpCases[0]?.id || '');
  const [isRunningTrigger, setIsRunningTrigger] = useState(false);
  const [lastTriggerSummary, setLastTriggerSummary] = useState<{
    message: string;
    stage1Count: number;
    stage2Count: number;
    stage3Count: number;
    managerNotifiedCount: number;
  } | null>(null);

  const activeCase = followUpCases.find((c) => c.id === filterCaseId);

  // Group case counts by stage
  const stage1Cases = followUpCases.filter((c) => c.stage === 'stage_1_initial');
  const stage2Cases = followUpCases.filter((c) => c.stage === 'stage_2_followup');
  const stage3Cases = followUpCases.filter((c) => c.stage === 'stage_3_call');
  const resolvedCases = followUpCases.filter((c) => c.stage === 'resolved');
  const managerPendingCases = followUpCases.filter(
    (c) => c.status === 'verification' || c.managerApprovalStatus === 'pending'
  );

  const handleManualAutoTrigger = async () => {
    setIsRunningTrigger(true);
    // Give a brief visual feedback
    await new Promise((resolve) => setTimeout(resolve, 400));
    const result = runWorkflowAutoTrigger();
    setLastTriggerSummary(result);
    setIsRunningTrigger(false);
  };

  return (
    <div className="space-y-6">
      {/* Visualizer Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-teal-100 text-teal-800 border border-teal-200 flex items-center gap-1.5">
              <GitFork className="w-3.5 h-3.5" />
              Interactive Workflow Map & Automation Engine
            </span>
            <span className="text-xs text-slate-500 font-medium">Auto-Trigger & Plivo Telephony</span>
          </div>
          <h2 className="text-2xl font-black text-slate-900 mt-1">
            4-Stage Attendance Automation Architecture
          </h2>
          <p className="text-xs text-slate-600 max-w-2xl">
            Live lifecycle automation: Initial attendance detection, WhatsApp template options, 2-day reminder follow-up, automated Plivo phone calls, and Manager Escalation with dual WhatsApp & IVR voice approval.
          </p>
        </div>

        {/* Highlight Specific Case */}
        <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 flex items-center space-x-3">
          <div>
            <label className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">
              Highlight Employee Path
            </label>
            <select
              id="workflow-case-picker"
              value={filterCaseId}
              onChange={(e) => {
                setFilterCaseId(e.target.value);
                setSelectedCaseId(e.target.value);
              }}
              className="bg-white border border-slate-200 rounded px-2.5 py-1 text-xs font-bold text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-500"
            >
              {followUpCases.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.employeeName} ({c.code} · {c.status})
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Interactive Workflow Reminder Auto-Trigger Console (User Requested) */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-6 rounded-2xl border border-indigo-800/40 shadow-lg">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 pb-4 border-b border-slate-800">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                Auto-Trigger Engine Active
              </span>
              <span className="text-xs text-slate-400 font-mono">
                Caller ID: {appSettings.plivoPhoneNumber || '+919876543210'} (Plivo Telephony)
              </span>
            </div>
            <h3 className="text-lg font-black text-white flex items-center gap-2">
              <Zap className="w-5 h-5 text-amber-400" />
              Automated Workflow Reminder & Escalation Scheduler
            </h3>
            <p className="text-xs text-slate-300 max-w-2xl">
              Continuously monitors absentee follow-up cases. Automatically dispatches Stage 1 WhatsApp messages, sends 48-hr Stage 2 reminders, initiates outbound Plivo phone calls, and notifies Reporting Managers for approval.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center space-x-2 bg-slate-800/80 px-3 py-1.5 rounded-xl border border-slate-700">
              <label className="text-[11px] text-slate-300 font-medium">Scheduler:</label>
              <button
                onClick={() => updateAppSettings({ autoTriggerEnabled: !appSettings.autoTriggerEnabled })}
                className={`px-2.5 py-1 rounded-lg text-xs font-black transition ${
                  appSettings.autoTriggerEnabled
                    ? 'bg-emerald-500 text-slate-950 shadow-sm'
                    : 'bg-slate-700 text-slate-400'
                }`}
              >
                {appSettings.autoTriggerEnabled ? 'ENABLED' : 'PAUSED'}
              </button>
            </div>

            <button
              id="run-auto-trigger-sweep-btn"
              onClick={handleManualAutoTrigger}
              disabled={isRunningTrigger}
              className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs px-4 py-2.5 rounded-xl shadow-md flex items-center gap-2 transition transform active:scale-95 disabled:opacity-50"
            >
              <RotateCw className={`w-4 h-4 ${isRunningTrigger ? 'animate-spin' : ''}`} />
              <span>Run Auto-Trigger Sweep Now</span>
            </button>
          </div>
        </div>

        {/* Trigger Summary Result Toast / Banner */}
        {lastTriggerSummary && (
          <div className="mt-4 p-3.5 bg-emerald-950/80 border border-emerald-500/40 rounded-xl flex items-center justify-between gap-3 text-xs text-emerald-200">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{lastTriggerSummary.message}</span>
            </div>
            <div className="flex items-center gap-3 text-[11px] font-mono shrink-0">
              <span className="bg-emerald-900/60 px-2 py-0.5 rounded text-emerald-300">
                S1 WhatsApp: {lastTriggerSummary.stage1Count}
              </span>
              <span className="bg-emerald-900/60 px-2 py-0.5 rounded text-emerald-300">
                S2 Reminder: {lastTriggerSummary.stage2Count}
              </span>
              <span className="bg-emerald-900/60 px-2 py-0.5 rounded text-emerald-300">
                S3 Calls: {lastTriggerSummary.stage3Count}
              </span>
              <span className="bg-emerald-900/60 px-2 py-0.5 rounded text-emerald-300">
                Mgr Alerts: {lastTriggerSummary.managerNotifiedCount}
              </span>
            </div>
          </div>
        )}

        {/* Live Auto-Trigger Logs Feed */}
        <div className="mt-4 pt-4 border-t border-slate-800">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-300">
              <Activity className="w-4 h-4 text-indigo-400" />
              <span>Recent Auto-Trigger Execution Logs ({autoTriggerLogs.length})</span>
            </div>
            {autoTriggerLogs.length > 0 && (
              <button
                onClick={clearAutoTriggerLogs}
                className="text-[11px] text-slate-400 hover:text-rose-400 flex items-center gap-1 transition"
              >
                <Trash2 className="w-3 h-3" />
                <span>Clear Logs</span>
              </button>
            )}
          </div>

          <div className="max-h-44 overflow-y-auto space-y-1.5 pr-1 text-xs font-mono">
            {autoTriggerLogs.length === 0 ? (
              <div className="text-slate-500 text-[11px] py-2">No trigger logs recorded yet. Click "Run Auto-Trigger Sweep Now" above.</div>
            ) : (
              autoTriggerLogs.map((log) => {
                const badgeColor =
                  log.triggerType === 'stage_1_whatsapp'
                    ? 'bg-teal-900/60 text-teal-300 border-teal-700/50'
                    : log.triggerType === 'stage_2_reminder'
                    ? 'bg-cyan-900/60 text-cyan-300 border-cyan-700/50'
                    : log.triggerType === 'stage_3_plivo_call'
                    ? 'bg-rose-900/60 text-rose-300 border-rose-700/50'
                    : log.triggerType === 'manager_notification'
                    ? 'bg-purple-900/60 text-purple-300 border-purple-700/50'
                    : 'bg-slate-800 text-slate-300 border-slate-700';

                return (
                  <div
                    key={log.id}
                    className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-2 rounded-lg bg-slate-800/50 border border-slate-700/50 text-[11px]"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <span className={`px-2 py-0.5 rounded border text-[10px] font-bold uppercase shrink-0 ${badgeColor}`}>
                        {log.triggerType.replace(/_/g, ' ')}
                      </span>
                      <span className="text-slate-200 font-semibold truncate">{log.employeeName}:</span>
                      <span className="text-slate-400 truncate">{log.details}</span>
                    </div>
                    <span className="text-slate-500 text-[10px] shrink-0">{log.timestamp}</span>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>

      {/* Stage Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
        {/* Stage 1 */}
        <div
          className={`p-4 rounded-xl border transition ${
            activeCase?.stage === 'stage_1_initial'
              ? 'bg-teal-50 border-teal-500 shadow-md ring-2 ring-teal-400'
              : 'bg-white border-slate-200'
          }`}
        >
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 mb-1">
            <span>STAGE 1</span>
            <span className="bg-teal-100 text-teal-800 text-[10px] px-2 py-0.5 rounded-full font-bold">
              {stage1Cases.length} cases
            </span>
          </div>
          <div className="font-extrabold text-sm text-slate-900 flex items-center gap-1.5">
            <MessageSquare className="w-4 h-4 text-teal-600" />
            First WhatsApp Check
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            Sends 4-button template and processes initial reason.
          </p>
        </div>

        {/* Stage 2 */}
        <div
          className={`p-4 rounded-xl border transition ${
            activeCase?.stage === 'stage_2_followup'
              ? 'bg-cyan-50 border-cyan-500 shadow-md ring-2 ring-cyan-400'
              : 'bg-white border-slate-200'
          }`}
        >
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 mb-1">
            <span>STAGE 2</span>
            <span className="bg-cyan-100 text-cyan-800 text-[10px] px-2 py-0.5 rounded-full font-bold">
              {stage2Cases.length} cases
            </span>
          </div>
          <div className="font-extrabold text-sm text-slate-900 flex items-center gap-1.5">
            <Clock className="w-4 h-4 text-cyan-600" />
            2-Day Reminder Follow-up
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            Checks if manager approval / leave is completed.
          </p>
        </div>

        {/* Stage 3 */}
        <div
          className={`p-4 rounded-xl border transition ${
            activeCase?.stage === 'stage_3_call'
              ? 'bg-rose-50 border-rose-500 shadow-md ring-2 ring-rose-400'
              : 'bg-white border-slate-200'
          }`}
        >
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 mb-1">
            <span>STAGE 3</span>
            <span className="bg-rose-100 text-rose-800 text-[10px] px-2 py-0.5 rounded-full font-bold">
              {stage3Cases.length} cases
            </span>
          </div>
          <div className="font-extrabold text-sm text-slate-900 flex items-center gap-1.5">
            <PhoneCall className="w-4 h-4 text-rose-600" />
            Plivo Phone Call Escalation
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            Automated Indian voice call from Plivo virtual line.
          </p>
        </div>

        {/* Stage 4: Manager Escalation */}
        <div
          className={`p-4 rounded-xl border transition ${
            managerPendingCases.some((c) => c.id === filterCaseId)
              ? 'bg-purple-50 border-purple-500 shadow-md ring-2 ring-purple-400'
              : 'bg-white border-slate-200'
          }`}
        >
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 mb-1">
            <span>STAGE 4</span>
            <span className="bg-purple-100 text-purple-800 text-[10px] px-2 py-0.5 rounded-full font-bold">
              {managerPendingCases.length} pending
            </span>
          </div>
          <div className="font-extrabold text-sm text-slate-900 flex items-center gap-1.5">
            <UserCheck className="w-4 h-4 text-purple-600" />
            Manager Approvals
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            Automated WhatsApp + Plivo IVR call to manager.
          </p>
        </div>

        {/* Resolved */}
        <div
          className={`p-4 rounded-xl border transition ${
            activeCase?.stage === 'resolved'
              ? 'bg-emerald-50 border-emerald-500 shadow-md ring-2 ring-emerald-400'
              : 'bg-white border-slate-200'
          }`}
        >
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 mb-1">
            <span>RESOLVED</span>
            <span className="bg-emerald-100 text-emerald-800 text-[10px] px-2 py-0.5 rounded-full font-bold">
              {resolvedCases.length} cases
            </span>
          </div>
          <div className="font-extrabold text-sm text-slate-900 flex items-center gap-1.5">
            <CheckCircle className="w-4 h-4 text-emerald-600" />
            Authorized in HRMS
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            Leave / Regularization verified & closed.
          </p>
        </div>
      </div>

      {/* Visual Workflow Tree with Auto-Trigger & Manager Branching */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-6">
        <div className="flex items-center justify-between border-b border-slate-200 pb-3">
          <h3 className="text-base font-extrabold text-slate-900">
            End-to-End Automation Flowchart
          </h3>
          {activeCase && (
            <div className="text-xs bg-slate-100 px-3 py-1 rounded-full font-mono text-slate-700">
              Active Case: <strong className="text-slate-900">{activeCase.employeeName}</strong> ({activeCase.date} · {activeCase.code})
            </div>
          )}
        </div>

        {/* Tree Container */}
        <div className="space-y-4 max-w-4xl mx-auto">
          {/* Node 1: Attendance Check */}
          <div className="flex flex-col items-center">
            <div className="bg-[#0C4E75] text-white px-6 py-3 rounded-xl shadow-md text-center max-w-md w-full">
              <div className="text-[10px] uppercase font-bold text-[#BFD6E1]">
                Step 1: Automated Daily Attendance Scan (10:00 AM IST)
              </div>
              <div className="text-sm font-extrabold mt-0.5">
                Check employee attendance in biometric register
              </div>
            </div>
            <div className="w-0.5 h-6 bg-slate-300 my-1" />
          </div>

          {/* Node 2: Decision Absent / Irregular */}
          <div className="flex flex-col items-center">
            <div className="bg-amber-500 text-slate-950 px-6 py-2.5 rounded-xl shadow-md text-center font-black text-xs">
              Is employee Absent (A|A) or Missing Punches (M|M / PR|A)?
            </div>
            <div className="w-0.5 h-6 bg-slate-300 my-1" />
          </div>

          {/* Node 3: Stage 1 WhatsApp Template */}
          <div className="border border-slate-200 rounded-2xl p-4 bg-slate-50/50 space-y-3">
            <div className="text-center">
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-teal-100 text-teal-800 border border-teal-200 inline-flex items-center gap-1.5">
                <MessageSquare className="w-3.5 h-3.5" />
                Stage 1: Dispatched WhatsApp Template with 4 Quick Options
              </span>
            </div>

            {/* 4 Options Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2">
              {/* Option 1 */}
              <div
                className={`p-3.5 rounded-xl border text-xs space-y-2 transition ${
                  activeCase?.replyOption === 1
                    ? 'bg-teal-50 border-teal-500 shadow-sm ring-2 ring-teal-400'
                    : 'bg-slate-50 border-slate-200'
                }`}
              >
                <span className="font-black text-teal-800 block">1. Yes, was absent</span>
                <p className="text-[11px] text-slate-600">
                  System replies: "Please apply leave in the HRMS portal today."
                </p>
                <div className="pt-2 border-t border-slate-200 text-[10px] font-bold text-slate-500">
                  Status: Pending Leave
                </div>
              </div>

              {/* Option 2 */}
              <div
                className={`p-3.5 rounded-xl border text-xs space-y-2 transition ${
                  activeCase?.replyOption === 2
                    ? 'bg-teal-50 border-teal-500 shadow-sm ring-2 ring-teal-400'
                    : 'bg-slate-50 border-slate-200'
                }`}
              >
                <span className="font-black text-teal-800 block">2. No, was working</span>
                <p className="text-[11px] text-slate-600">
                  System replies: "Please submit attendance regularization."
                </p>
                <div className="pt-2 border-t border-slate-200 text-[10px] font-bold text-slate-500">
                  Status: Pending Regularization
                </div>
              </div>

              {/* Option 3 */}
              <div
                className={`p-3.5 rounded-xl border text-xs space-y-2 transition ${
                  activeCase?.replyOption === 3
                    ? 'bg-purple-50 border-purple-500 shadow-sm ring-2 ring-purple-400'
                    : 'bg-slate-50 border-slate-200'
                }`}
              >
                <span className="font-black text-purple-800 block">3. Applied leave</span>
                <p className="text-[11px] text-slate-600">
                  Automated trigger: Dispatches WhatsApp & Plivo call to Manager for authorization.
                </p>
                <div className="pt-2 border-t border-slate-200 text-[10px] font-bold text-purple-700">
                  Status: Manager Authorization
                </div>
              </div>

              {/* Option 4 */}
              <div
                className={`p-3.5 rounded-xl border text-xs space-y-2 transition ${
                  activeCase?.replyOption === 4
                    ? 'bg-purple-50 border-purple-500 shadow-sm ring-2 ring-purple-400'
                    : 'bg-slate-50 border-slate-200'
                }`}
              >
                <span className="font-black text-purple-800 block">4. Sent regularization</span>
                <p className="text-[11px] text-slate-600">
                  Automated trigger: Dispatches WhatsApp & Plivo call to Manager for approval.
                </p>
                <div className="pt-2 border-t border-slate-200 text-[10px] font-bold text-purple-700">
                  Status: Manager Authorization
                </div>
              </div>
            </div>
          </div>

          {/* Node 4: Stage 2 - 2-Day Reminder */}
          <div className="flex flex-col items-center">
            <div className="w-0.5 h-6 bg-slate-300 my-1" />
            <div className="bg-cyan-900 text-white px-6 py-4 rounded-xl shadow-md text-center max-w-lg border border-cyan-700">
              <div className="text-[10px] uppercase font-bold text-cyan-200 flex items-center justify-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                Stage 2: Wait 2 Days & Auto-Trigger Tailored Reminder
              </div>
              <div className="text-xs font-bold mt-1 text-slate-100">
                Options: 1. Done / Applied · 2. Not Done · 3. Need Help
              </div>
            </div>
            <div className="w-0.5 h-6 bg-slate-300 my-1" />
          </div>

          {/* Node 5: Stage 3 & Stage 4 Side-by-Side */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Stage 3: Voice Call */}
            <div className="p-4 rounded-xl border border-rose-200 bg-rose-50/70 space-y-2">
              <div className="flex items-center space-x-2 text-rose-800 font-extrabold text-xs">
                <PhoneCall className="w-4 h-4" />
                <span>Stage 3: Day 3 Outbound Voice Call via Plivo Virtual Line</span>
              </div>
              <p className="text-xs text-rose-900">
                Triggered automatically if: Employee replied "Not Done", "Need Help", or no response after 48 hrs.
              </p>
              <div className="text-[11px] text-rose-700 bg-white/70 p-2 rounded border border-rose-200 font-mono">
                Caller ID: {appSettings.plivoPhoneNumber} · Press # for Indian English Voice · Dialpad DTMF (1, 2, 3, 4)
              </div>
            </div>

            {/* Stage 4: Manager Escalation & Approval */}
            <div className="p-4 rounded-xl border border-purple-200 bg-purple-50/70 space-y-2">
              <div className="flex items-center space-x-2 text-purple-800 font-extrabold text-xs">
                <UserCheck className="w-4 h-4" />
                <span>Stage 4: Manager Escalation & Dual WhatsApp / IVR Approval</span>
              </div>
              <p className="text-xs text-purple-900">
                Triggered automatically when: Employee confirms application submitted. Manager receives WhatsApp notification and Plivo IVR call.
              </p>
              <div className="text-[11px] text-purple-700 bg-white/70 p-2 rounded border border-purple-200 font-mono">
                Manager approves (Press 1 / Portal) → Case Marked Regularized in HRMS & Employee Notified!
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

