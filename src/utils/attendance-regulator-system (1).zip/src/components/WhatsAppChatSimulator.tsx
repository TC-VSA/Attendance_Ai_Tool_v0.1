import React, { useState } from 'react';
import {
  Send,
  Sparkles,
  Phone,
  Video,
  MoreVertical,
  Check,
  CheckCheck,
  Clock,
  ArrowRight,
  PhoneCall,
  BellRing,
  HelpCircle,
} from 'lucide-react';
import { useAttendance } from '../context/AttendanceContext';
import { WORKFLOW_TEMPLATES } from '../data/followUpData';
import { classifyEmployeeReply } from '../utils/aiClassifier';

interface WhatsAppChatSimulatorProps {
  onNavigateToCallCenter?: () => void;
}

export const WhatsAppChatSimulator: React.FC<WhatsAppChatSimulatorProps> = ({
  onNavigateToCallCenter,
}) => {
  const {
    followUpCases,
    selectedCaseId,
    selectedCase,
    setSelectedCaseId,
    sendFirstWhatsApp,
    logEmployeeReply,
    sendTwoDayReminder,
    logTwoDayReply,
    toggleCaseLanguage,
  } = useAttendance();

  const [inputText, setInputText] = useState('');
  const [showAiBreakdown, setShowAiBreakdown] = useState(true);

  if (!selectedCase) {
    return (
      <div className="p-8 text-center text-slate-500 bg-white rounded-xl border border-slate-200">
        Please select a case from the Follow-up Cases table to test the WhatsApp agent.
      </div>
    );
  }

  const currentCaseLang = selectedCase.language || 'english';

  const handleSendCustomReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    logEmployeeReply(selectedCase.id, inputText);
    setInputText('');
  };

  const handleButtonReply = (option: 1 | 2 | 3 | 4, label: string) => {
    logEmployeeReply(selectedCase.id, label, option);
  };

  const isCallRequired =
    selectedCase.status === 'call-required' || selectedCase.stage === 'stage_3_call';

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* Left 4 cols: Case Context & Automation Controls */}
      <div className="lg:col-span-4 space-y-4">
        {/* Case Selector Dropdown */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-500 block mb-2">
            Switch Target Case
          </label>
          <select
            id="whatsapp-case-selector"
            value={selectedCaseId || ''}
            onChange={(e) => setSelectedCaseId(e.target.value)}
            className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500"
          >
            {followUpCases.map((c) => (
              <option key={c.id} value={c.id}>
                {c.employeeName} ({c.code} · {c.date})
              </option>
            ))}
          </select>
        </div>

        {/* Selected Case Summary Card */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-start justify-between">
            <div>
              <div className="text-xs font-bold text-teal-700 uppercase tracking-wider">
                {selectedCase.department}
              </div>
              <h3 className="text-lg font-black text-slate-900 mt-0.5">
                {selectedCase.employeeName}
              </h3>
              <div className="text-xs text-slate-500">
                Code: <span className="font-mono">{selectedCase.employeeCode || 'DPOD-001'}</span> · Manager: {selectedCase.reportingManager}
              </div>
            </div>

            <span
              className={`text-xs font-bold px-2.5 py-1 rounded-full ${
                selectedCase.code === 'A|A'
                  ? 'bg-rose-100 text-rose-800 border border-rose-200'
                  : 'bg-amber-100 text-amber-800 border border-amber-200'
              }`}
            >
              {selectedCase.code}
            </span>
          </div>

          <div className="pt-3 border-t border-slate-100 grid grid-cols-2 gap-2 text-xs">
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Absent Date</span>
              <span className="font-semibold text-slate-800 font-mono">{selectedCase.date}</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Mobile</span>
              <span className="font-semibold text-slate-800 font-mono">+{selectedCase.mobileNumber}</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Current Status</span>
              <span className="font-bold text-teal-700 capitalize">{selectedCase.status.replace('-', ' ')}</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Workflow Stage</span>
              <span className="font-bold text-indigo-700 capitalize">{selectedCase.stage.replace('_', ' ')}</span>
            </div>
          </div>
        </div>

        {/* Action Controls: Stage 1 / Stage 2 / Stage 3 */}
        <div className="bg-gradient-to-br from-[#073B5C] to-[#0A4E78] text-white p-5 rounded-xl shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-cyan-200 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              Workflow Triggers
            </span>
            <span className="text-[11px] bg-white/10 text-cyan-200 px-2 py-0.5 rounded">
              Dry Run
            </span>
          </div>

          {/* Trigger 1: Resend First WhatsApp */}
          <div>
            <button
              id="resend-first-wa-btn"
              onClick={() => sendFirstWhatsApp(selectedCase.id)}
              className="w-full flex items-center justify-center space-x-2 bg-teal-600 hover:bg-teal-500 text-white py-2 px-3 rounded-lg text-xs font-bold transition shadow-xs"
            >
              <span>Resend First WhatsApp Message</span>
            </button>
            <p className="text-[10px] text-cyan-100/70 mt-1">
              Sends attendance notice with 4 interactive quick-reply buttons.
            </p>
          </div>

          {/* Trigger 2: Send 2-Day Follow-up Reminder */}
          <div className="pt-3 border-t border-white/10">
            <button
              id="send-2day-reminder-btn"
              onClick={() => sendTwoDayReminder(selectedCase.id)}
              className="w-full flex items-center justify-center space-x-2 bg-cyan-700 hover:bg-cyan-600 text-white py-2 px-3 rounded-lg text-xs font-bold transition shadow-xs"
            >
              <BellRing className="w-3.5 h-3.5 text-cyan-300" />
              <span>Send 2-Day Reminder (Stage 2)</span>
            </button>
            <p className="text-[10px] text-cyan-100/70 mt-1">
              Sends tailored reminder checking if leave or regularization is approved.
            </p>
          </div>

          {/* Stage 3 Escalation CTA */}
          {isCallRequired && (
            <div className="pt-3 border-t border-white/10 bg-rose-950/40 -mx-5 -mb-5 p-5 rounded-b-xl border-t border-rose-500/30">
              <div className="flex items-center space-x-2 text-rose-300 font-bold text-xs mb-1">
                <PhoneCall className="w-4 h-4 animate-bounce" />
                <span>Day 3 Escalation: Call Required</span>
              </div>
              <p className="text-[11px] text-rose-100/80 mb-3">
                This case has reached Day 3 without resolution or employee requested help.
              </p>
              {onNavigateToCallCenter && (
                <button
                  id="nav-to-call-center-btn"
                  onClick={onNavigateToCallCenter}
                  className="w-full flex items-center justify-center space-x-1.5 bg-rose-600 hover:bg-rose-500 text-white py-2 px-3 rounded-lg text-xs font-bold transition shadow-sm"
                >
                  <span>Open Call Center Desk</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          )}
        </div>

        {/* AI Intent Classifier Inspector */}
        {selectedCase.aiClassification && (
          <div className="bg-emerald-50 border border-emerald-200 p-4 rounded-xl text-xs space-y-1.5">
            <div className="flex items-center justify-between font-bold text-emerald-800">
              <span className="flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                AI Reply Classification
              </span>
              <span className="text-[10px] bg-emerald-200 text-emerald-900 px-1.5 py-0.5 rounded">
                {(selectedCase.aiClassification.confidence * 100).toFixed(0)}% Confidence
              </span>
            </div>
            <p className="text-emerald-700 text-[11px]">
              {selectedCase.aiClassification.explanation}
            </p>
          </div>
        )}
      </div>

      {/* Right 8 cols: Smartphone Simulator / Live WhatsApp Chat Interface */}
      <div className="lg:col-span-8 flex justify-center">
        <div
          id="whatsapp-phone-mockup"
          className="w-full max-w-lg bg-slate-900 rounded-[2.5rem] p-3 shadow-2xl border-4 border-slate-700"
        >
          {/* Inner Phone Screen */}
          <div className="bg-[#0B141A] rounded-[2rem] overflow-hidden flex flex-col h-[650px]">
            {/* WhatsApp Header */}
            <div className="bg-[#1F2C34] px-4 py-3 text-white flex items-center justify-between shrink-0 shadow-md">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-teal-600 to-cyan-500 flex items-center justify-center text-white font-black text-sm shadow-inner">
                  TC
                </div>
                <div>
                  <h4 className="font-bold text-sm tracking-tight leading-tight">
                    Talent Carriage Attendance
                  </h4>
                  <p className="text-[11px] text-teal-400 font-medium">
                    Verified Business Account · Online
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-2 text-slate-300">
                {/* Header Language Badge / Toggle */}
                <button
                  id="whatsapp-header-lang-toggle"
                  onClick={() => toggleCaseLanguage(selectedCase.id)}
                  title="Click to toggle language between English and Hindi"
                  className="bg-[#2A3942] hover:bg-[#344854] text-cyan-300 border border-cyan-500/40 text-[11px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1 transition shadow-xs"
                >
                  <span>🌐</span>
                  <span>{currentCaseLang === 'hindi' ? 'हिंदी' : 'English'}</span>
                </button>
                <Phone className="w-4 h-4 cursor-pointer hover:text-white ml-1" />
                <MoreVertical className="w-4 h-4 cursor-pointer hover:text-white" />
              </div>
            </div>

            {/* Chat Messages Feed */}
            {selectedCase.regularizedByAgent && (
              <div className="bg-emerald-950/90 border border-emerald-500/50 p-2.5 mx-4 mt-2 rounded-xl text-emerald-200 text-xs flex items-center justify-between shadow-xs">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                  <div>
                    <span className="font-bold text-white">🤖 AI Agent Action Executed:</span>{' '}
                    <span>{selectedCase.autonomousActionTaken || 'Leave/Regularization Applied on Behalf'}</span>
                  </div>
                </div>
                <span className="text-[10px] bg-emerald-800/80 text-emerald-200 font-mono px-2 py-0.5 rounded">
                  Manager Notified
                </span>
              </div>
            )}

            <div
              id="whatsapp-messages-feed"
              className="flex-1 p-4 overflow-y-auto space-y-3 bg-[#0B141A] bg-opacity-95"
              style={{
                backgroundImage:
                  'radial-gradient(circle at 50% 50%, rgba(255, 255, 255, 0.03) 1px, transparent 1px)',
                backgroundSize: '20px 20px',
              }}
            >
              {/* Date Header Pill */}
              <div className="text-center my-2">
                <span className="bg-[#182229] text-slate-400 text-[10px] font-semibold uppercase tracking-wider px-3 py-1 rounded-full">
                  {selectedCase.date} · {currentCaseLang.toUpperCase()}
                </span>
              </div>

              {selectedCase.messages.map((msg) => {
                const isSystem = msg.sender === 'system';
                return (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${isSystem ? 'items-start' : 'items-end'}`}
                  >
                    <div
                      className={`max-w-[85%] rounded-xl p-3 text-xs leading-relaxed shadow-md ${
                        isSystem
                          ? 'bg-[#1F2C34] text-slate-100 rounded-tl-none border border-slate-700/50'
                          : 'bg-[#005C4B] text-white rounded-tr-none'
                      }`}
                    >
                      <p className="whitespace-pre-line">{msg.text}</p>

                      {/* Interactive Buttons rendered directly inside the chat bubble */}
                      {msg.buttons && msg.buttons.length > 0 && (
                        <div className="mt-3 pt-2 border-t border-slate-600/50 space-y-1.5">
                          {msg.buttons.map((btn, idx) => {
                            const isLangBtn = btn.includes('Change Language') || btn.includes('भाषा बदलें');
                            return (
                              <button
                                key={idx}
                                onClick={() => {
                                  if (isLangBtn) {
                                    toggleCaseLanguage(selectedCase.id);
                                  } else if (btn.includes('Done') || btn.includes('हो गया') || btn.includes('Approved')) {
                                    logTwoDayReply(selectedCase.id, 'done');
                                  } else if (btn.includes('Not Done') || btn.includes('नहीं हुआ') || btn.includes('Not Approved')) {
                                    logTwoDayReply(selectedCase.id, 'not_done');
                                  } else if (btn.includes('Need Help') || btn.includes('मदद चाहिए')) {
                                    logTwoDayReply(selectedCase.id, 'need_help');
                                  } else {
                                    // Process the exact button label through interactive flow engine
                                    logEmployeeReply(selectedCase.id, btn);
                                  }
                                }}
                                className={`w-full text-left font-semibold px-3 py-1.5 rounded text-xs transition flex items-center justify-between group ${
                                  isLangBtn
                                    ? 'bg-emerald-950/80 hover:bg-emerald-900/90 text-emerald-300 border border-emerald-500/50 shadow-xs'
                                    : 'bg-[#2A3942] hover:bg-[#344854] text-cyan-300 border border-cyan-500/30'
                                }`}
                              >
                                <span className="flex items-center gap-1.5">
                                  {isLangBtn && <span>🌐</span>}
                                  <span>{btn}</span>
                                </span>
                                <span className="text-[10px] text-cyan-400/60 group-hover:text-cyan-200">
                                  Tap to reply
                                </span>
                              </button>
                            );
                          })}
                        </div>
                      )}

                      {/* Timestamp & Status ticks */}
                      <div className="flex items-center justify-end space-x-1 mt-1 text-[10px] text-slate-400">
                        <span>{msg.timestamp}</span>
                        {isSystem && <CheckCheck className="w-3 h-3 text-cyan-400" />}
                        {!isSystem && <CheckCheck className="w-3 h-3 text-cyan-400" />}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Permanent Always-Visible "Change Language" Bar at End of Chat */}
            <div className="bg-[#182229] px-3.5 py-2 border-t border-slate-700/80 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-1.5 text-[11px] text-slate-300 font-medium">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                <span>Active Language:</span>
                <span className="font-bold text-white uppercase bg-slate-800 px-1.5 py-0.5 rounded border border-slate-700">
                  {currentCaseLang === 'hindi' ? 'हिंदी (Hindi)' : 'English'}
                </span>
              </div>

              {/* Requirement: In the whatsapp chat at the end last always change language button given */}
              <button
                id="whatsapp-always-change-lang-footer-btn"
                onClick={() => toggleCaseLanguage(selectedCase.id)}
                className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-3 py-1.5 rounded-lg shadow-sm flex items-center gap-1.5 transition active:scale-95"
                title="Switch between English and Hindi chat language"
              >
                <span>🌐</span>
                <span>Change Language / भाषा बदलें</span>
              </button>
            </div>

            {/* Dynamic Suggested Action Chips for Active Step */}
            {(() => {
              const lastSystemMsg = [...selectedCase.messages].reverse().find((m) => m.sender === 'system');
              const dynamicButtons =
                lastSystemMsg?.buttons?.filter(
                  (b) => !b.includes('Change Language') && !b.includes('भाषा बदलें')
                ) || [];

              if (dynamicButtons.length === 0) return null;

              return (
                <div className="bg-[#182229] px-3 py-2 border-t border-cyan-500/30 flex items-center space-x-2 overflow-x-auto shrink-0">
                  <span className="text-[10px] uppercase font-bold text-cyan-400 shrink-0 flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-cyan-400" />
                    Agent Options:
                  </span>
                  {dynamicButtons.map((btn, idx) => (
                    <button
                      key={idx}
                      onClick={() => logEmployeeReply(selectedCase.id, btn)}
                      className="shrink-0 bg-cyan-950/80 hover:bg-cyan-900 text-cyan-200 text-xs font-semibold px-3 py-1 rounded-full border border-cyan-500/50 shadow-xs transition active:scale-95 flex items-center gap-1"
                    >
                      <span>{btn}</span>
                    </button>
                  ))}
                </div>
              );
            })()}

            {/* Quick-reply shortcut pills for simulator */}
            <div className="bg-[#1F2C34] px-3 py-2 border-t border-slate-700/60 flex items-center space-x-1.5 overflow-x-auto shrink-0">
              <span className="text-[10px] uppercase font-bold text-slate-400 shrink-0 mr-1">
                Quick Reply:
              </span>
              {currentCaseLang === 'hindi' ? (
                <>
                  <button
                    onClick={() => handleButtonReply(1, '1. हाँ, मैं अनुपस्थित था')}
                    className="shrink-0 bg-[#2A3942] hover:bg-[#344854] text-xs text-slate-200 px-2.5 py-1 rounded-full border border-slate-600 transition"
                  >
                    1. अनुपस्थित (Absent)
                  </button>
                  <button
                    onClick={() => handleButtonReply(2, '2. नहीं, मैं काम कर रहा था')}
                    className="shrink-0 bg-[#2A3942] hover:bg-[#344854] text-xs text-slate-200 px-2.5 py-1 rounded-full border border-slate-600 transition"
                  >
                    2. काम कर रहा था (Working)
                  </button>
                  <button
                    onClick={() => handleButtonReply(3, '3. मैंने छुट्टी के लिए आवेदन कर दिया है')}
                    className="shrink-0 bg-[#2A3942] hover:bg-[#344854] text-xs text-slate-200 px-2.5 py-1 rounded-full border border-slate-600 transition"
                  >
                    3. छुट्टी (Leave)
                  </button>
                  <button
                    onClick={() => handleButtonReply(4, '4. मैंने नियमितीकरण भेज दिया है')}
                    className="shrink-0 bg-[#2A3942] hover:bg-[#344854] text-xs text-slate-200 px-2.5 py-1 rounded-full border border-slate-600 transition"
                  >
                    4. नियमितीकरण (Regularize)
                  </button>
                </>
              ) : (
                <>
                  <button
                    onClick={() => handleButtonReply(1, '1. Yes, I was absent')}
                    className="shrink-0 bg-[#2A3942] hover:bg-[#344854] text-xs text-slate-200 px-2.5 py-1 rounded-full border border-slate-600 transition"
                  >
                    1. Absent
                  </button>
                  <button
                    onClick={() => handleButtonReply(2, '2. No, I was working')}
                    className="shrink-0 bg-[#2A3942] hover:bg-[#344854] text-xs text-slate-200 px-2.5 py-1 rounded-full border border-slate-600 transition"
                  >
                    2. Working
                  </button>
                  <button
                    onClick={() => handleButtonReply(3, '3. I have already applied leave')}
                    className="shrink-0 bg-[#2A3942] hover:bg-[#344854] text-xs text-slate-200 px-2.5 py-1 rounded-full border border-slate-600 transition"
                  >
                    3. Applied leave
                  </button>
                  <button
                    onClick={() => handleButtonReply(4, '4. I have already sent regularization request')}
                    className="shrink-0 bg-[#2A3942] hover:bg-[#344854] text-xs text-slate-200 px-2.5 py-1 rounded-full border border-slate-600 transition"
                  >
                    4. Sent reg
                  </button>
                </>
              )}
              {/* Last quick-reply button is also Change Language */}
              <button
                onClick={() => toggleCaseLanguage(selectedCase.id)}
                className="shrink-0 bg-emerald-900/80 hover:bg-emerald-800 text-xs text-emerald-200 font-semibold px-3 py-1 rounded-full border border-emerald-500/50 transition flex items-center gap-1"
              >
                <span>🌐</span>
                <span>Change Language</span>
              </button>
            </div>

            {/* Employee Input Bar */}
            <form
              onSubmit={handleSendCustomReply}
              className="bg-[#1F2C34] p-2.5 flex items-center space-x-2 shrink-0 border-t border-slate-800"
            >
              <input
                id="whatsapp-input-field"
                type="text"
                placeholder="Type reply as employee (English or Hinglish)..."
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                className="flex-1 bg-[#2A3942] text-white placeholder-slate-400 rounded-lg px-3.5 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-teal-400"
              />
              <button
                id="whatsapp-send-btn"
                type="submit"
                disabled={!inputText.trim()}
                className="bg-[#00A884] hover:bg-[#009272] disabled:opacity-40 text-white p-2 rounded-lg transition"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
