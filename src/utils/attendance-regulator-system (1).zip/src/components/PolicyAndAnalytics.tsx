import React, { useState } from 'react';
import { useAttendance } from '../context/AttendanceContext';
import {
  Sliders,
  BarChart3,
  Download,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Sparkles,
  Save,
  Check,
} from 'lucide-react';

export const PolicyAndAnalytics: React.FC = () => {
  const {
    policy,
    updatePolicy,
    checkInRecords,
    regularizationRequests,
    employees,
    resetToDemoData,
  } = useAttendance();

  const [gracePeriod, setGracePeriod] = useState(policy.gracePeriodMinutes);
  const [minHours, setMinHours] = useState(policy.minFullDayHours);
  const [quotaLimit, setQuotaLimit] = useState(policy.monthlyRegularizationLimit);
  const [autoApproveMeetings, setAutoApproveMeetings] = useState(
    policy.autoApproveVerifiedCalendarMeetings
  );
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSavePolicy = (e: React.FormEvent) => {
    e.preventDefault();
    updatePolicy({
      gracePeriodMinutes: Number(gracePeriod),
      minFullDayHours: Number(minHours),
      monthlyRegularizationLimit: Number(quotaLimit),
      autoApproveVerifiedCalendarMeetings: autoApproveMeetings,
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2000);
  };

  // Compute analytics
  const totalRecords = checkInRecords.length;
  const compliantRecords = checkInRecords.filter((r) => r.regularityStatus === 'compliant').length;
  const regularizedRecords = checkInRecords.filter((r) => r.regularityStatus === 'regularized').length;
  const irregularRecords = checkInRecords.filter(
    (r) => r.regularityStatus === 'irregular' || r.regularityStatus === 'review_required'
  ).length;

  const compliancePercentage = totalRecords
    ? Math.round(((compliantRecords + regularizedRecords) / totalRecords) * 100)
    : 100;

  // Reason breakdown
  const reasonCounts: Record<string, number> = {};
  regularizationRequests.forEach((req) => {
    reasonCounts[req.reasonCategory] = (reasonCounts[req.reasonCategory] || 0) + 1;
  });

  // Export to CSV
  const handleExportCSV = () => {
    const headers = [
      'Record ID',
      'Employee ID',
      'Date',
      'Check-In Time',
      'Check-Out Time',
      'Work Mode',
      'Location',
      'Status',
      'Flags',
    ];
    const rows = checkInRecords.map((r) => [
      r.id,
      r.employeeId,
      r.date,
      r.checkInTime,
      r.checkOutTime || 'In-Progress',
      r.workMode,
      `"${r.locationName}"`,
      r.regularityStatus,
      `"${r.flags.join('; ')}"`,
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `attendance_audit_log_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Analytics KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">
            Effective Punctuality
          </span>
          <div className="flex items-baseline space-x-2 mt-1">
            <span className="text-3xl font-extrabold text-emerald-600">
              {compliancePercentage}%
            </span>
            <span className="text-xs text-slate-500">compliant</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            Includes auto-reconciled calendar events
          </p>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">
            Total Punches Logged
          </span>
          <div className="flex items-baseline space-x-2 mt-1">
            <span className="text-3xl font-extrabold text-slate-900">
              {totalRecords}
            </span>
            <span className="text-xs text-slate-500">sessions</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">Across 5 enterprise employees</p>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">
            Calendar Reconciled
          </span>
          <div className="flex items-baseline space-x-2 mt-1">
            <span className="text-3xl font-extrabold text-indigo-600">
              {regularizedRecords}
            </span>
            <span className="text-xs text-slate-500">resolved</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">Backed by calendar invites</p>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">
            Pending Discrepancies
          </span>
          <div className="flex items-baseline space-x-2 mt-1">
            <span className="text-3xl font-extrabold text-amber-600">
              {irregularRecords}
            </span>
            <span className="text-xs text-slate-500">unresolved</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">Awaiting employee/manager action</p>
        </div>
      </div>

      {/* Grid: Policy Settings on Left, Regularization Breakdown on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Attendance Regulation Policy Configurator */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-4">
            <div>
              <h3 className="text-base font-bold text-slate-900 flex items-center">
                <Sliders className="w-4 h-4 mr-2 text-indigo-600" />
                Attendance Policy Rules
              </h3>
              <p className="text-xs text-slate-500">
                Corporate parameters regulating grace periods, quotas, and calendar auto-approval
              </p>
            </div>
            {savedSuccess && (
              <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-800 border border-emerald-200 flex items-center">
                <Check className="w-3.5 h-3.5 mr-1" />
                Saved!
              </span>
            )}
          </div>

          <form onSubmit={handleSavePolicy} className="space-y-4 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Arrival Grace Period (Minutes)
              </label>
              <div className="flex items-center space-x-3">
                <input
                  type="number"
                  min="0"
                  max="60"
                  value={gracePeriod}
                  onChange={(e) => setGracePeriod(Number(e.target.value))}
                  className="w-24 px-3 py-2 border border-slate-200 rounded-xl font-bold font-mono-code text-slate-900 focus:ring-2 focus:ring-indigo-500/20"
                />
                <span className="text-slate-500">
                  Late flag triggers after 09:{String(gracePeriod).padStart(2, '0')} AM
                </span>
              </div>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Minimum Full-Day Working Hours
              </label>
              <div className="flex items-center space-x-3">
                <input
                  type="number"
                  min="4"
                  max="12"
                  step="0.5"
                  value={minHours}
                  onChange={(e) => setMinHours(Number(e.target.value))}
                  className="w-24 px-3 py-2 border border-slate-200 rounded-xl font-bold font-mono-code text-slate-900 focus:ring-2 focus:ring-indigo-500/20"
                />
                <span className="text-slate-500">
                  Shifts shorter than {minHours}h trigger Early Departure or Half-Day flag
                </span>
              </div>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Monthly Regularization Limit per Employee
              </label>
              <div className="flex items-center space-x-3">
                <input
                  type="number"
                  min="1"
                  max="10"
                  value={quotaLimit}
                  onChange={(e) => setQuotaLimit(Number(e.target.value))}
                  className="w-24 px-3 py-2 border border-slate-200 rounded-xl font-bold font-mono-code text-slate-900 focus:ring-2 focus:ring-indigo-500/20"
                />
                <span className="text-slate-500">
                  Max self-service regularizations allowed per calendar month
                </span>
              </div>
            </div>

            {/* Toggle: Auto-Approve Verified Calendar Meetings */}
            <div className="pt-2 border-t border-slate-100">
              <label className="flex items-start space-x-3 p-3 bg-indigo-50/70 border border-indigo-200 rounded-xl cursor-pointer">
                <input
                  type="checkbox"
                  checked={autoApproveMeetings}
                  onChange={(e) => setAutoApproveMeetings(e.target.checked)}
                  className="mt-0.5 rounded text-indigo-600 focus:ring-indigo-500 w-4 h-4 cursor-pointer"
                />
                <div>
                  <span className="font-bold text-indigo-950 block">
                    Auto-Approve Verified Calendar Client Meetings
                  </span>
                  <span className="text-[11px] text-indigo-800 leading-relaxed block mt-0.5">
                    When enabled, late check-ins that directly match a confirmed external calendar meeting or customer demo are regularized instantly without waiting for manual manager review.
                  </span>
                </div>
              </label>
            </div>

            <div className="flex items-center justify-end pt-3">
              <button
                type="submit"
                className="inline-flex items-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl shadow-xs transition-colors cursor-pointer"
              >
                <Save className="w-3.5 h-3.5 mr-1.5" />
                Save Policy Parameters
              </button>
            </div>
          </form>
        </div>

        {/* Regularization Reasons & Audit Export */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-4">
              <h3 className="text-base font-bold text-slate-900 flex items-center">
                <BarChart3 className="w-4 h-4 mr-2 text-indigo-600" />
                Regularization Breakdown
              </h3>
              <span className="text-xs text-slate-400">Monthly Distribution</span>
            </div>

            {/* Breakdown Bars */}
            <div className="space-y-3.5 text-xs">
              <div>
                <div className="flex justify-between text-slate-700 font-semibold mb-1">
                  <span>External Client Meetings / Onsite</span>
                  <span className="text-indigo-600">60%</span>
                </div>
                <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                  <div className="bg-emerald-500 h-full rounded-full" style={{ width: '60%' }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-slate-700 font-semibold mb-1">
                  <span>Offsite / Incident Duty</span>
                  <span className="text-indigo-600">25%</span>
                </div>
                <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                  <div className="bg-indigo-500 h-full rounded-full" style={{ width: '25%' }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-slate-700 font-semibold mb-1">
                  <span>Transit & Travel Disruption</span>
                  <span className="text-indigo-600">10%</span>
                </div>
                <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                  <div className="bg-blue-500 h-full rounded-full" style={{ width: '10%' }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-slate-700 font-semibold mb-1">
                  <span>Biometric Error / WFH</span>
                  <span className="text-indigo-600">5%</span>
                </div>
                <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                  <div className="bg-amber-400 h-full rounded-full" style={{ width: '5%' }} />
                </div>
              </div>
            </div>
          </div>

          {/* Export & Reset Actions */}
          <div className="pt-6 border-t border-slate-100 mt-6 space-y-2.5">
            <button
              onClick={handleExportCSV}
              className="w-full py-2.5 px-4 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center space-x-2 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Export Compliance Audit Log (CSV)</span>
            </button>

            <button
              onClick={resetToDemoData}
              className="w-full py-2 px-4 border border-slate-200 text-slate-600 hover:bg-slate-50 font-medium text-xs rounded-xl transition-colors flex items-center justify-center space-x-2 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5 text-slate-400" />
              <span>Reset All Records to Default Demo State</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
