import React from 'react';
import {
  LayoutDashboard,
  ClipboardList,
  MessageSquareText,
  PhoneCall,
  GitFork,
  UploadCloud,
  Clock,
  Settings,
  RotateCcw,
  Sparkles,
  ShieldAlert,
  UserCheck,
} from 'lucide-react';
import { TalentCarriageLogo } from './TalentCarriageLogo';
import { useAttendance } from '../context/AttendanceContext';

export type NavTab =
  | 'dashboard'
  | 'cases'
  | 'whatsapp'
  | 'callcenter'
  | 'manager_approvals'
  | 'workflow'
  | 'upload'
  | 'punch_terminal'
  | 'settings';

interface SidebarProps {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab }) => {
  const { followUpCases, appSettings, updateAppSettings, resetToDemoData, managerNotifications } = useAttendance();

  // Badges
  const waitingCount = followUpCases.filter((c) => c.status === 'waiting' || c.status === 'sent').length;
  const callRequiredCount = followUpCases.filter((c) => c.status === 'call-required' || c.stage === 'stage_3_call').length;
  const pendingApprovalsCount = managerNotifications.filter((m) => m.status === 'pending').length;

  const navItems: { id: NavTab; label: string; icon: React.ReactNode; badge?: number; badgeColor?: string }[] = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: <LayoutDashboard className="w-4 h-4 shrink-0" />,
    },
    {
      id: 'cases',
      label: 'Follow-up Cases',
      icon: <ClipboardList className="w-4 h-4 shrink-0" />,
      badge: followUpCases.length,
      badgeColor: 'bg-[#0C4E75] text-[#BFD6E1]',
    },
    {
      id: 'whatsapp',
      label: 'WhatsApp Agent',
      icon: <MessageSquareText className="w-4 h-4 shrink-0" />,
      badge: waitingCount > 0 ? waitingCount : undefined,
      badgeColor: 'bg-amber-500/20 text-amber-300 border border-amber-500/30',
    },
    {
      id: 'callcenter',
      label: 'Call Center (Plivo)',
      icon: <PhoneCall className="w-4 h-4 shrink-0" />,
      badge: callRequiredCount > 0 ? callRequiredCount : undefined,
      badgeColor: 'bg-rose-500/25 text-rose-300 border border-rose-500/40 animate-pulse',
    },
    {
      id: 'manager_approvals',
      label: 'Manager Approvals',
      icon: <UserCheck className="w-4 h-4 shrink-0" />,
      badge: pendingApprovalsCount > 0 ? pendingApprovalsCount : undefined,
      badgeColor: 'bg-purple-500/30 text-purple-200 border border-purple-400/40 font-bold',
    },
    {
      id: 'workflow',
      label: 'Workflow Visualizer',
      icon: <GitFork className="w-4 h-4 shrink-0" />,
    },
    {
      id: 'upload',
      label: 'Upload Register',
      icon: <UploadCloud className="w-4 h-4 shrink-0" />,
    },
    {
      id: 'punch_terminal',
      label: 'Punch & Calendar',
      icon: <Clock className="w-4 h-4 shrink-0" />,
    },
    {
      id: 'settings',
      label: 'Settings & Policy',
      icon: <Settings className="w-4 h-4 shrink-0" />,
    },
  ];

  return (
    <aside
      id="app-sidebar"
      className="w-72 bg-[#073B5C] text-[#BFD6E1] flex flex-col shrink-0 border-r border-[#0A476F] shadow-xl z-20 min-h-screen"
    >
      {/* Brand Header */}
      <div className="p-5 border-b border-[#0C4E75]/80 bg-[#052C46]/50">
        <TalentCarriageLogo size="md" variant="dark" />
        <div className="mt-3 flex items-center justify-between">
          <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-[#0C4E75] text-cyan-300 border border-cyan-400/20">
            Attendance Agent
          </span>
          <span className="text-[11px] text-[#86A8BA] font-medium truncate max-w-[130px]">
            DPOD Lifestyle
          </span>
        </div>
      </div>

      {/* Navigation List */}
      <nav className="flex-1 py-4 px-3 space-y-1 overflow-y-auto">
        <div className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-widest text-[#6E95A8]">
          Operations Desk
        </div>

        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              id={`nav-item-${item.id}`}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-semibold transition-all duration-150 ${
                isActive
                  ? 'bg-[#0C4E75] text-white shadow-sm border border-cyan-400/30'
                  : 'text-[#BFD6E1] hover:bg-[#0A476F]/60 hover:text-white'
              }`}
            >
              <div className="flex items-center space-x-3 truncate">
                <span className={isActive ? 'text-cyan-300' : 'text-[#8EAEC0]'}>
                  {item.icon}
                </span>
                <span className="truncate">{item.label}</span>
              </div>

              {item.badge !== undefined && (
                <span
                  className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
                    item.badgeColor || 'bg-[#0A476F] text-white'
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Bottom Status Panel */}
      <div className="p-4 border-t border-[#0C4E75]/80 bg-[#052C46]/60 space-y-3">
        {/* WhatsApp Mode Toggle */}
        <div className="flex items-center justify-between p-2.5 rounded-lg bg-[#073B5C] border border-[#0C4E75]">
          <div className="flex items-center space-x-2">
            <span
              className={`w-2 h-2 rounded-full ${
                appSettings.dryRun ? 'bg-amber-400 animate-pulse' : 'bg-emerald-400'
              }`}
            />
            <span className="text-xs font-semibold text-white">WhatsApp Mode</span>
          </div>

          <button
            id="toggle-dry-run-btn"
            onClick={() => updateAppSettings({ dryRun: !appSettings.dryRun })}
            className={`text-[11px] font-bold px-2 py-0.5 rounded transition ${
              appSettings.dryRun
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
            }`}
          >
            {appSettings.dryRun ? 'Dry Run' : 'Live Mode'}
          </button>
        </div>

        {/* AI Classifier indicator */}
        <div className="flex items-center justify-between text-xs text-[#8EAEC0] px-1">
          <div className="flex items-center space-x-1.5">
            <Sparkles className="w-3.5 h-3.5 text-cyan-300" />
            <span>AI Intent Classifier</span>
          </div>
          <span className="text-[11px] font-bold text-cyan-300">Active</span>
        </div>

        {/* Reset button */}
        <button
          id="sidebar-reset-btn"
          onClick={() => {
            if (window.confirm('Reset all follow-up cases and data to default demo state?')) {
              resetToDemoData();
            }
          }}
          className="w-full flex items-center justify-center space-x-1.5 py-1.5 px-3 rounded text-xs font-medium text-[#8EAEC0] hover:text-white hover:bg-[#0A476F] transition"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset Demo Data</span>
        </button>
      </div>
    </aside>
  );
};
