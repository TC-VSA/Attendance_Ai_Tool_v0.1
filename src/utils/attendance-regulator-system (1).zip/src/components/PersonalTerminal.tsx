import React, { useState, useEffect, useMemo } from 'react';
import { useAttendance } from '../context/AttendanceContext';
import { WorkMode } from '../types';
import {
  Clock,
  MapPin,
  Coffee,
  LogOut,
  LogIn,
  AlertCircle,
  CalendarCheck,
  CheckCircle2,
  Sparkles,
  Navigation,
  Laptop,
  Briefcase,
  Building,
  Plane,
  ChevronRight,
  ShieldCheck,
  AlertTriangle,
} from 'lucide-react';

interface PersonalTerminalProps {
  onOpenRegularizationModal: (presetDate?: string, calendarEventId?: string) => void;
}

export const PersonalTerminal: React.FC<PersonalTerminalProps> = ({
  onOpenRegularizationModal,
}) => {
  const {
    currentEmployee,
    todayRecord,
    checkIn,
    checkOut,
    startBreak,
    endBreak,
    currentTime,
    policy,
    calendarEvents,
    detectCalendarReconciliation,
    checkInRecords,
  } = useAttendance();

  const [selectedWorkMode, setSelectedWorkMode] = useState<WorkMode>('office');
  const [locationName, setLocationName] = useState<string>('HQ San Francisco - Floor 7');
  const [punchNote, setPunchNote] = useState<string>('');
  const [detectingGps, setDetectingGps] = useState<boolean>(false);
  const [gpsCoordinates, setGpsCoordinates] = useState<{ lat: number; lng: number } | undefined>();
  const [breakMenuOpen, setBreakMenuOpen] = useState<boolean>(false);

  // Sync default location when workMode changes
  useEffect(() => {
    if (selectedWorkMode === 'office') {
      setLocationName('HQ San Francisco - Floor 7');
    } else if (selectedWorkMode === 'remote') {
      setLocationName('Home Office - Berkeley, CA');
    } else if (selectedWorkMode === 'client_site') {
      setLocationName('Acme Corp HQ - Mission St');
    } else if (selectedWorkMode === 'business_trip') {
      setLocationName('Equinix SV5 Colocation Facility');
    } else {
      setLocationName('External Work Site');
    }
  }, [selectedWorkMode]);

  // Determine current active break if any
  const activeBreak = useMemo(() => {
    if (!todayRecord) return null;
    return todayRecord.breaks.find((b) => !b.endTime) || null;
  }, [todayRecord]);

  // Elapsed work duration calculation
  const [elapsedDuration, setElapsedDuration] = useState<string>('00:00:00');
  const [breakDuration, setBreakDuration] = useState<string>('00:00:00');

  useEffect(() => {
    if (!todayRecord || todayRecord.checkOutTime) {
      if (todayRecord?.checkOutTime) {
        const hrs = Math.floor(todayRecord.totalWorkMinutes / 60);
        const mins = todayRecord.totalWorkMinutes % 60;
        setElapsedDuration(`${hrs}h ${mins}m (Completed)`);
      } else {
        setElapsedDuration('00:00:00');
      }
      return;
    }

    const todayStr = currentTime.toISOString().split('T')[0];
    const checkInDateTime = new Date(`${todayStr}T${todayRecord.checkInTime}`);
    const now = currentTime.getTime();

    // Work out total break milliseconds
    let breakMs = todayRecord.breaks.reduce((acc, b) => {
      if (b.endTime) {
        const start = new Date(`${todayStr}T${b.startTime}`).getTime();
        const end = new Date(`${todayStr}T${b.endTime}`).getTime();
        return acc + (end - start);
      } else {
        const start = new Date(`${todayStr}T${b.startTime}`).getTime();
        return acc + (now - start);
      }
    }, 0);

    const workedMs = Math.max(0, now - checkInDateTime.getTime() - breakMs);
    const totalSecs = Math.floor(workedMs / 1000);
    const hrs = Math.floor(totalSecs / 3600);
    const mins = Math.floor((totalSecs % 3600) / 60);
    const secs = totalSecs % 60;

    setElapsedDuration(
      `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`
    );

    // Active break duration
    if (activeBreak) {
      const breakStart = new Date(`${todayStr}T${activeBreak.startTime}`).getTime();
      const currentBreakSecs = Math.max(0, Math.floor((now - breakStart) / 1000));
      const bHrs = Math.floor(currentBreakSecs / 3600);
      const bMins = Math.floor((currentBreakSecs % 3600) / 60);
      const bSecs = currentBreakSecs % 60;
      setBreakDuration(
        `${String(bHrs).padStart(2, '0')}:${String(bMins).padStart(2, '0')}:${String(bSecs).padStart(2, '0')}`
      );
    }
  }, [currentTime, todayRecord, activeBreak]);

  // GPS Geolocation Handler
  const handleDetectLocation = () => {
    setDetectingGps(true);
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setGpsCoordinates({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
          setDetectingGps(false);
          setLocationName(`GPS Verified (Lat: ${position.coords.latitude.toFixed(3)}, Lng: ${position.coords.longitude.toFixed(3)})`);
        },
        (error) => {
          console.warn('Geolocation error or denied, using office fallback:', error);
          setDetectingGps(false);
          setLocationName('HQ San Francisco - Main Lobby (Verified IP)');
        },
        { timeout: 5000 }
      );
    } else {
      setDetectingGps(false);
      setLocationName('HQ San Francisco - Floor 7 (Default)');
    }
  };

  // Check if today or recent records have an irregularity
  const todayStr = currentTime.toISOString().split('T')[0];
  const matchedEvent = useMemo(() => {
    if (!todayRecord || todayRecord.regularityStatus !== 'irregular') return null;
    return detectCalendarReconciliation(currentEmployee.id, todayRecord.date, todayRecord.checkInTime);
  }, [todayRecord, detectCalendarReconciliation, currentEmployee.id]);

  // Also check if any recent record (like yesterday) is irregular or requires review
  const recentIrregularRecord = useMemo(() => {
    return checkInRecords.find(
      (r) =>
        r.employeeId === currentEmployee.id &&
        (r.regularityStatus === 'irregular' || r.regularityStatus === 'review_required')
    );
  }, [checkInRecords, currentEmployee.id]);

  return (
    <div className="space-y-6">
      {/* Smart Discrepancy & Calendar Reconciler Banner */}
      {recentIrregularRecord && (
        <div className="bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200/80 rounded-2xl p-5 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-start space-x-3.5">
              <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-600 shrink-0">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <span className="font-semibold text-slate-900 text-sm">
                    Attendance Irregularity Detected ({recentIrregularRecord.date})
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[11px] font-medium bg-amber-100 text-amber-800 border border-amber-200">
                    Action Required
                  </span>
                </div>
                <p className="text-xs text-slate-600 mt-1">
                  Check-in recorded at{' '}
                  <span className="font-mono-code font-bold text-slate-800">
                    {recentIrregularRecord.checkInTime.slice(0, 5)}
                  </span>{' '}
                  ({recentIrregularRecord.flags[0] || 'Late check-in'}).
                </p>

                {/* Show Calendar Evidence Cross-Check */}
                {matchedEvent && (
                  <div className="mt-2.5 flex items-center space-x-2 p-2 bg-white/80 border border-amber-200 rounded-lg text-xs text-slate-700">
                    <CalendarCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>
                      <strong className="text-slate-900">Calendar Evidence Matched:</strong>{' '}
                      &ldquo;{matchedEvent.title}&rdquo; ({matchedEvent.startTime} - {matchedEvent.endTime})
                    </span>
                    <span className="text-[10px] bg-emerald-50 text-emerald-700 border border-emerald-200 px-1.5 py-0.5 rounded-full font-medium ml-auto">
                      Auto-Eligible
                    </span>
                  </div>
                )}
              </div>
            </div>

            <div className="flex items-center space-x-2.5 sm:self-center shrink-0">
              <button
                onClick={() =>
                  onOpenRegularizationModal(
                    recentIrregularRecord.date,
                    matchedEvent ? matchedEvent.id : undefined
                  )
                }
                className="w-full sm:w-auto inline-flex items-center justify-center px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold shadow-xs hover:shadow transition-all cursor-pointer"
              >
                <Sparkles className="w-4 h-4 mr-1.5" />
                Regularize with Calendar Proof
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Terminal Grid: Punch Action + Shift Status */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Real-Time Check-In Terminal Card */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between pb-5 border-b border-slate-100">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Real-Time Attendance Terminal
              </h2>
              <p className="text-xs text-slate-500">
                Live biometric & calendar-synchronized employee check-in hub
              </p>
            </div>

            {/* Current Terminal Status Badge */}
            {todayRecord ? (
              todayRecord.checkOutTime ? (
                <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-200">
                  <CheckCircle2 className="w-3.5 h-3.5 mr-1.5 text-slate-500" />
                  Shift Completed
                </span>
              ) : activeBreak ? (
                <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200 animate-pulse">
                  <Coffee className="w-3.5 h-3.5 mr-1.5 text-amber-600" />
                  On Break ({activeBreak.type})
                </span>
              ) : (
                <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 mr-1.5 animate-ping" />
                  Currently Checked In
                </span>
              )
            ) : (
              <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-600 border border-slate-200">
                <Clock className="w-3.5 h-3.5 mr-1.5 text-slate-400" />
                Not Checked In Today
              </span>
            )}
          </div>

          {/* Running Clock & Work Duration Display */}
          <div className="my-6 bg-slate-50/80 rounded-2xl p-5 border border-slate-200/80 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-center sm:text-left">
              <span className="text-xs font-medium uppercase tracking-wider text-slate-400 block mb-1">
                Active Worked Duration
              </span>
              <div className="font-mono-code text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
                {elapsedDuration}
              </div>
              <div className="text-[11px] text-slate-500 mt-1 flex items-center justify-center sm:justify-start space-x-1.5">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                <span>
                  {todayRecord?.checkInTime
                    ? `Punched In at ${todayRecord.checkInTime.slice(0, 5)}`
                    : 'Awaiting initial punch'}
                </span>
              </div>
            </div>

            {/* If on break, show Break Clock */}
            {activeBreak && (
              <div className="bg-amber-100/70 border border-amber-200 px-4 py-3 rounded-xl text-center">
                <span className="text-[11px] font-semibold text-amber-800 uppercase tracking-wide block">
                  Break Duration
                </span>
                <span className="font-mono-code text-xl font-bold text-amber-900">
                  {breakDuration}
                </span>
                <span className="text-[10px] text-amber-700 block capitalize">
                  {activeBreak.type} Break
                </span>
              </div>
            )}
          </div>

          {/* Punch In Settings (Work Mode & Location) if not yet checked in */}
          {!todayRecord && (
            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-2">
                  Select Work Mode
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  <button
                    type="button"
                    onClick={() => setSelectedWorkMode('office')}
                    className={`flex items-center justify-center space-x-2 py-2.5 px-3 rounded-xl border text-xs font-medium transition-all cursor-pointer ${
                      selectedWorkMode === 'office'
                        ? 'bg-indigo-50 border-indigo-500 text-indigo-700 ring-2 ring-indigo-500/20'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <Building className="w-4 h-4" />
                    <span>In-Office (HQ)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSelectedWorkMode('remote')}
                    className={`flex items-center justify-center space-x-2 py-2.5 px-3 rounded-xl border text-xs font-medium transition-all cursor-pointer ${
                      selectedWorkMode === 'remote'
                        ? 'bg-indigo-50 border-indigo-500 text-indigo-700 ring-2 ring-indigo-500/20'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <Laptop className="w-4 h-4" />
                    <span>Remote / WFH</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSelectedWorkMode('client_site')}
                    className={`flex items-center justify-center space-x-2 py-2.5 px-3 rounded-xl border text-xs font-medium transition-all cursor-pointer ${
                      selectedWorkMode === 'client_site'
                        ? 'bg-indigo-50 border-indigo-500 text-indigo-700 ring-2 ring-indigo-500/20'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <Briefcase className="w-4 h-4" />
                    <span>Client Site</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSelectedWorkMode('business_trip')}
                    className={`flex items-center justify-center space-x-2 py-2.5 px-3 rounded-xl border text-xs font-medium transition-all cursor-pointer ${
                      selectedWorkMode === 'business_trip'
                        ? 'bg-indigo-50 border-indigo-500 text-indigo-700 ring-2 ring-indigo-500/20'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <Plane className="w-4 h-4" />
                    <span>On-Duty Trip</span>
                  </button>
                </div>
              </div>

              {/* Location Input with GPS Detection */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Location / Geofence Tag
                </label>
                <div className="flex items-center space-x-2">
                  <div className="relative flex-1">
                    <MapPin className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={locationName}
                      onChange={(e) => setLocationName(e.target.value)}
                      placeholder="e.g. HQ San Francisco - Floor 7"
                      className="w-full pl-9 pr-3 py-2 text-xs text-slate-900 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 bg-white"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={handleDetectLocation}
                    disabled={detectingGps}
                    className="inline-flex items-center px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-xl transition-colors cursor-pointer"
                  >
                    <Navigation className={`w-3.5 h-3.5 mr-1.5 ${detectingGps ? 'animate-spin' : ''}`} />
                    <span>{detectingGps ? 'Detecting...' : 'GPS Detect'}</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Action Buttons: Punch In / Punch Out / Break */}
          <div className="pt-2">
            {!todayRecord ? (
              <button
                type="button"
                onClick={() => checkIn(selectedWorkMode, locationName, punchNote, gpsCoordinates)}
                className="w-full py-3.5 px-6 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center space-x-2 cursor-pointer"
              >
                <LogIn className="w-4 h-4" />
                <span>Punch In (Check In Now)</span>
              </button>
            ) : todayRecord.checkOutTime ? (
              <div className="text-center py-4 bg-slate-50 border border-slate-200 rounded-xl">
                <CheckCircle2 className="w-6 h-6 text-emerald-600 mx-auto mb-1.5" />
                <p className="text-xs font-semibold text-slate-900">
                  You are checked out for the day
                </p>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Check-Out Time: {todayRecord.checkOutTime} • Total Work: {todayRecord.totalWorkMinutes} mins
                </p>
              </div>
            ) : activeBreak ? (
              <button
                type="button"
                onClick={endBreak}
                className="w-full py-3.5 px-6 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center space-x-2 cursor-pointer"
              >
                <LogIn className="w-4 h-4" />
                <span>Resume Work (End {activeBreak.type} Break)</span>
              </button>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Break Trigger Dropdown */}
                <div className="relative">
                  <button
                    type="button"
                    onClick={() => setBreakMenuOpen(!breakMenuOpen)}
                    className="w-full py-3 px-4 rounded-xl border border-slate-200 hover:border-slate-300 bg-white text-slate-700 font-semibold text-xs transition-colors flex items-center justify-center space-x-2 cursor-pointer"
                  >
                    <Coffee className="w-4 h-4 text-amber-600" />
                    <span>Start Break</span>
                  </button>

                  {breakMenuOpen && (
                    <div className="absolute bottom-full mb-2 left-0 w-full bg-white rounded-xl shadow-lg border border-slate-200 p-2 z-20 space-y-1">
                      <button
                        onClick={() => {
                          startBreak('lunch');
                          setBreakMenuOpen(false);
                        }}
                        className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-50 text-xs font-medium text-slate-700 flex items-center justify-between"
                      >
                        <span>🍽️ Lunch Break (45 min)</span>
                      </button>
                      <button
                        onClick={() => {
                          startBreak('coffee');
                          setBreakMenuOpen(false);
                        }}
                        className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-50 text-xs font-medium text-slate-700 flex items-center justify-between"
                      >
                        <span>☕ Coffee Break (15 min)</span>
                      </button>
                      <button
                        onClick={() => {
                          startBreak('personal');
                          setBreakMenuOpen(false);
                        }}
                        className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-50 text-xs font-medium text-slate-700 flex items-center justify-between"
                      >
                        <span>🚶 Personal Errand / Walk</span>
                      </button>
                    </div>
                  )}
                </div>

                {/* Punch Out Button */}
                <button
                  type="button"
                  onClick={() => checkOut()}
                  className="w-full py-3 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs shadow-xs transition-colors flex items-center justify-center space-x-2 cursor-pointer"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Punch Out (End Day)</span>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Shift Policy & Compliance Radar */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-4">
              <h3 className="text-sm font-bold text-slate-900 flex items-center">
                <ShieldCheck className="w-4 h-4 mr-1.5 text-indigo-600" />
                Shift Policy & Regulations
              </h3>
              <span className="text-[10px] font-semibold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full border border-indigo-200">
                Standard 9H
              </span>
            </div>

            <div className="space-y-3.5 text-xs text-slate-600">
              <div className="flex justify-between items-center py-1.5 border-b border-slate-50">
                <span className="text-slate-500">Official Shift Hours</span>
                <span className="font-semibold text-slate-900 font-mono-code">
                  {currentEmployee.shiftStart} – {currentEmployee.shiftEnd}
                </span>
              </div>

              <div className="flex justify-between items-center py-1.5 border-b border-slate-50">
                <span className="text-slate-500">Arrival Grace Period</span>
                <span className="font-semibold text-slate-900">
                  {currentEmployee.graceMinutes || policy.gracePeriodMinutes} mins (until 09:15)
                </span>
              </div>

              <div className="flex justify-between items-center py-1.5 border-b border-slate-50">
                <span className="text-slate-500">Min. Full-Day Hours</span>
                <span className="font-semibold text-slate-900">
                  {policy.minFullDayHours} hrs (4.0h for half-day)
                </span>
              </div>

              <div className="flex justify-between items-center py-1.5 border-b border-slate-50">
                <span className="text-slate-500">Regularization Quota</span>
                <span className="font-semibold text-slate-900">
                  {currentEmployee.regularizationsUsedThisMonth} of {currentEmployee.regularizationQuota} used
                </span>
              </div>

              <div className="flex justify-between items-center py-1.5 border-b border-slate-50">
                <span className="text-slate-500">Calendar Auto-Reconcile</span>
                <span className="inline-flex items-center font-semibold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">
                  <CheckCircle2 className="w-3 h-3 mr-1" />
                  Active
                </span>
              </div>
            </div>
          </div>

          {/* Quick Notice regarding Calendar Integration */}
          <div className="mt-6 p-3.5 bg-indigo-50/70 border border-indigo-100 rounded-xl text-xs text-indigo-900">
            <p className="font-semibold mb-1 flex items-center">
              <CalendarCheck className="w-3.5 h-3.5 mr-1.5 text-indigo-600" />
              Calendar Sync Enabled
            </p>
            <p className="text-[11px] text-indigo-700/90 leading-relaxed">
              When meetings, client calls, or business travel delay your check-in, the system automatically detects calendar invites and offers one-click regularization.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
