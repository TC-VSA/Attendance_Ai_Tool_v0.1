import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from 'react';
import {
  Employee,
  CheckInRecord,
  CalendarEvent,
  RegularizationRequest,
  AttendancePolicy,
  LiveActivityFeedItem,
  WorkMode,
  RegularizationReason,
  FollowUpCase,
  AppSettings,
  ChatMessage,
  AutoTriggerLog,
  ManagerNotificationItem,
  HrmsPunchRecord,
  AiModelSettings,
  HrmsSyncSettings,
  LiveKitSettings,
  MetaWhatsAppSettings,
} from '../types';
import {
  INITIAL_EMPLOYEES,
  INITIAL_POLICY,
  createInitialCalendarEvents,
  createInitialCheckInRecords,
  createInitialRegularizations,
  createInitialLiveActivity,
  getTodayStr,
} from '../data/initialData';
import {
  INITIAL_FOLLOW_UP_CASES,
  INITIAL_APP_SETTINGS,
  WORKFLOW_TEMPLATES,
} from '../data/followUpData';
import { WHATSAPP_FLOW_TREES } from '../data/attendanceConversationFlows';
import {
  INITIAL_HRMS_PUNCH_RECORDS,
  fetchLiveHrmsData,
  submitAgentRegularization,
} from '../utils/hrmsClient';
import { classifyEmployeeReply } from '../utils/aiClassifier';
import { initiatePlivoCall, initiatePlivoManagerCall } from '../utils/plivoClient';
import { testAiModelConnection } from '../utils/aiAgentEngine';

const STORAGE_KEY = 'attendance_regulator_app_v2';

interface AttendanceContextType {
  employees: Employee[];
  currentEmployee: Employee;
  setCurrentEmployeeId: (id: string) => void;
  policy: AttendancePolicy;
  updatePolicy: (policy: Partial<AttendancePolicy>) => void;
  checkInRecords: CheckInRecord[];
  calendarEvents: CalendarEvent[];
  regularizationRequests: RegularizationRequest[];
  liveActivities: LiveActivityFeedItem[];
  currentTime: Date;
  todayRecord: CheckInRecord | undefined;
  
  // Follow-up cases & WhatsApp flow
  followUpCases: FollowUpCase[];
  selectedCaseId: string | null;
  selectedCase: FollowUpCase | null;
  setSelectedCaseId: (id: string | null) => void;
  appSettings: AppSettings;
  updateAppSettings: (settings: Partial<AppSettings>) => void;
  sendFirstWhatsApp: (caseId: string) => void;
  logEmployeeReply: (caseId: string, replyText: string, optionOverride?: 1 | 2 | 3 | 4) => void;
  sendTwoDayReminder: (caseId: string) => void;
  logTwoDayReply: (caseId: string, replyChoice: 'done' | 'not_done' | 'need_help') => void;
  toggleCaseLanguage: (caseId: string) => void;
  triggerCall: (caseId: string) => void;
  logCallOutcome: (caseId: string, outcome: 'completed' | 'not_completed' | 'needs_help' | 'no_answer', notes?: string) => void;
  markCaseVerified: (caseId: string) => void;
  importParsedCases: (newCases: FollowUpCase[]) => void;
  runDailyCheckForDate: (dateStr: string) => { createdCount: number; message: string };

  // Workflow Auto-Trigger Engine
  autoTriggerLogs: AutoTriggerLog[];
  runWorkflowAutoTrigger: () => {
    stage1Count: number;
    stage2Count: number;
    stage3Count: number;
    managerNotifiedCount: number;
    message: string;
  };
  clearAutoTriggerLogs: () => void;

  // Plivo Voice Agent
  triggerPlivoCall: (caseId: string, language?: 'hindi' | 'english') => Promise<{ success: boolean; callUuid: string; message: string }>;
  triggerPlivoManagerCall: (caseId: string, language?: 'hindi' | 'english') => Promise<{ success: boolean; callUuid: string; message: string }>;

  // Response Processing & Agent Sync
  processAgentResponse: (
    caseId: string,
    responseOption: 1 | 2 | 3 | 4,
    source: 'whatsapp' | 'call',
    customNotes?: string
  ) => void;

  // Manager Call & WhatsApp Notifications & Approvals
  managerNotifications: ManagerNotificationItem[];
  sendManagerWhatsApp: (caseId: string) => void;
  approveByManager: (caseId: string, notes?: string) => void;
  rejectByManager: (caseId: string, reason?: string) => void;

  // HRMS 2x Daily Live Synchronization & Biometric Punches
  hrmsPunches: HrmsPunchRecord[];
  syncHrmsDataNow: () => Promise<{ success: boolean; message: string }>;
  agentRegularizePunchOnBehalf: (
    caseId: string,
    inTime?: string,
    outTime?: string,
    reason?: string
  ) => Promise<{ success: boolean; message: string }>;

  // Admin Configuration Updaters
  updateAiModelSettings: (settings: Partial<AiModelSettings>) => void;
  updateHrmsSyncSettings: (settings: Partial<HrmsSyncSettings>) => void;
  updateLiveKitSettings: (settings: Partial<LiveKitSettings>) => void;
  updateMetaWhatsAppSettings: (settings: Partial<MetaWhatsAppSettings>) => void;

  // Real-time Check-in actions
  checkIn: (workMode: WorkMode, locationName: string, notes?: string, coordinates?: { lat: number; lng: number }) => void;
  checkOut: (notes?: string) => void;
  startBreak: (type: 'lunch' | 'coffee' | 'personal') => void;
  endBreak: () => void;

  // Regularization actions
  submitRegularization: (data: {
    date: string;
    originalCheckIn?: string;
    originalCheckOut?: string;
    requestedCheckIn: string;
    requestedCheckOut: string;
    reasonCategory: RegularizationReason;
    explanation: string;
    linkedCalendarEventId?: string;
    linkedCalendarEventTitle?: string;
    calendarProofSnippet?: string;
  }) => { success: boolean; message: string; autoApproved?: boolean };
  approveRegularization: (requestId: string, reviewerNotes?: string) => void;
  rejectRegularization: (requestId: string, reviewerNotes?: string) => void;

  // Calendar actions
  addCalendarEvent: (event: Omit<CalendarEvent, 'id'>) => void;
  syncGoogleCalendarFeed: (employeeId: string) => void;

  // Utilities
  detectCalendarReconciliation: (employeeId: string, date: string, checkInTime: string) => CalendarEvent | null;
  resetToDemoData: () => void;
}

const AttendanceContext = createContext<AttendanceContextType | undefined>(undefined);

export const AttendanceProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Live clock updated every second
  const [currentTime, setCurrentTime] = useState<Date>(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Persistent storage loader
  const [employees, setEmployees] = useState<Employee[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_employees`);
      return saved ? JSON.parse(saved) : INITIAL_EMPLOYEES;
    } catch {
      return INITIAL_EMPLOYEES;
    }
  });

  const [currentEmployeeId, setCurrentEmployeeId] = useState<string>(() => {
    return employees[1]?.id || 'emp-2';
  });

  const [policy, setPolicy] = useState<AttendancePolicy>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_policy`);
      return saved ? JSON.parse(saved) : INITIAL_POLICY;
    } catch {
      return INITIAL_POLICY;
    }
  });

  const [checkInRecords, setCheckInRecords] = useState<CheckInRecord[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_records`);
      return saved ? JSON.parse(saved) : createInitialCheckInRecords();
    } catch {
      return createInitialCheckInRecords();
    }
  });

  const [calendarEvents, setCalendarEvents] = useState<CalendarEvent[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_events`);
      return saved ? JSON.parse(saved) : createInitialCalendarEvents();
    } catch {
      return createInitialCalendarEvents();
    }
  });

  const [regularizationRequests, setRegularizationRequests] = useState<RegularizationRequest[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_regularizations`);
      return saved ? JSON.parse(saved) : createInitialRegularizations();
    } catch {
      return createInitialRegularizations();
    }
  });

  const [liveActivities, setLiveActivities] = useState<LiveActivityFeedItem[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_activities`);
      return saved ? JSON.parse(saved) : createInitialLiveActivity();
    } catch {
      return createInitialLiveActivity();
    }
  });

  // Follow-up cases
  const [followUpCases, setFollowUpCases] = useState<FollowUpCase[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_follow_up_cases`);
      return saved ? JSON.parse(saved) : INITIAL_FOLLOW_UP_CASES;
    } catch {
      return INITIAL_FOLLOW_UP_CASES;
    }
  });

  const [selectedCaseId, setSelectedCaseId] = useState<string | null>(() => {
    return INITIAL_FOLLOW_UP_CASES[0]?.id || null;
  });

  const [appSettings, setAppSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_app_settings`);
      return saved ? JSON.parse(saved) : INITIAL_APP_SETTINGS;
    } catch {
      return INITIAL_APP_SETTINGS;
    }
  });

  const [managerNotifications, setManagerNotifications] = useState<ManagerNotificationItem[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_manager_notifications`);
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      {
        id: 'mn-1',
        caseId: 'case-6',
        employeeName: 'Pooja Vaghela',
        employeeCode: 'DPOD-218',
        managerName: 'Khyati Patel',
        managerPhone: '+919876543220',
        date: '18-Aug-2026',
        reason: 'Regularization request sent - Client presentation travel delay',
        type: 'both',
        status: 'pending',
        timestamp: '18-Aug-2026 10:45 AM',
        lastResponse: 'Awaiting manager response via WhatsApp or IVR Call',
      },
      {
        id: 'mn-2',
        caseId: 'case-5',
        employeeName: 'Krish Patel',
        employeeCode: 'DPOD-094',
        managerName: 'Aelin Gajjar',
        managerPhone: '+919876543221',
        date: '23-Aug-2026',
        reason: 'Applied leave in HRMS',
        type: 'whatsapp',
        status: 'pending',
        timestamp: '23-Aug-2026 11:20 AM',
        lastResponse: 'WhatsApp template delivered to manager',
      },
    ];
  });

  const [autoTriggerLogs, setAutoTriggerLogs] = useState<AutoTriggerLog[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_auto_trigger_logs`);
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      {
        id: 'atl-1',
        timestamp: '10:00:12 AM',
        triggerType: 'daily_sweep',
        caseId: 'all',
        employeeName: 'System Engine',
        status: 'success',
        details: 'Daily absentee scan triggered at scheduled check time (10:00 AM IST). Evaluated all cases.',
      },
      {
        id: 'atl-2',
        timestamp: '10:00:15 AM',
        triggerType: 'stage_1_whatsapp',
        caseId: 'case-1',
        employeeName: 'Leo Johnson',
        status: 'success',
        details: 'Dispatched Stage 1 WhatsApp prompt to Leo Johnson (+91 98765 43210).',
      },
      {
        id: 'atl-3',
        timestamp: '10:00:18 AM',
        triggerType: 'stage_2_reminder',
        caseId: 'case-3',
        employeeName: 'Jasvant Katariya',
        status: 'success',
        details: 'Automated 48-hr reminder sent for pending leave resolution.',
      },
      {
        id: 'atl-4',
        timestamp: '10:00:20 AM',
        triggerType: 'manager_notification',
        caseId: 'case-6',
        employeeName: 'Pooja Vaghela',
        status: 'escalated',
        details: 'Manager Khyati Patel notified via WhatsApp and Plivo IVR Call for pending regularization.',
      },
    ];
  });

  const [hrmsPunches, setHrmsPunches] = useState<HrmsPunchRecord[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_hrms_punches`);
      if (saved) return JSON.parse(saved);
    } catch {}
    return INITIAL_HRMS_PUNCH_RECORDS;
  });

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_employees`, JSON.stringify(employees));
      localStorage.setItem(`${STORAGE_KEY}_policy`, JSON.stringify(policy));
      localStorage.setItem(`${STORAGE_KEY}_records`, JSON.stringify(checkInRecords));
      localStorage.setItem(`${STORAGE_KEY}_events`, JSON.stringify(calendarEvents));
      localStorage.setItem(`${STORAGE_KEY}_regularizations`, JSON.stringify(regularizationRequests));
      localStorage.setItem(`${STORAGE_KEY}_activities`, JSON.stringify(liveActivities));
      localStorage.setItem(`${STORAGE_KEY}_follow_up_cases`, JSON.stringify(followUpCases));
      localStorage.setItem(`${STORAGE_KEY}_app_settings`, JSON.stringify(appSettings));
      localStorage.setItem(`${STORAGE_KEY}_manager_notifications`, JSON.stringify(managerNotifications));
      localStorage.setItem(`${STORAGE_KEY}_auto_trigger_logs`, JSON.stringify(autoTriggerLogs));
      localStorage.setItem(`${STORAGE_KEY}_hrms_punches`, JSON.stringify(hrmsPunches));
    } catch (e) {
      console.error('Failed saving to localStorage', e);
    }
  }, [
    employees,
    policy,
    checkInRecords,
    calendarEvents,
    regularizationRequests,
    liveActivities,
    followUpCases,
    appSettings,
    managerNotifications,
    autoTriggerLogs,
    hrmsPunches,
  ]);

  const selectedCase = useMemo(() => {
    return followUpCases.find((c) => c.id === selectedCaseId) || null;
  }, [followUpCases, selectedCaseId]);

  const updateAppSettings = useCallback((newSettings: Partial<AppSettings>) => {
    setAppSettings((prev) => ({ ...prev, ...newSettings }));
  }, []);

  // WhatsApp Action 1: Send initial WhatsApp template
  const sendFirstWhatsApp = useCallback((caseId: string) => {
    const nowStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setFollowUpCases((prev) =>
      prev.map((c) => {
        if (c.id !== caseId) return c;
        const targetLang = c.language || appSettings.defaultWhatsAppLanguage || 'english';
        const msgText = WORKFLOW_TEMPLATES.firstMessage(c.employeeName, c.date, c.code, targetLang);
        const newMsg: ChatMessage = {
          id: `msg-${Date.now()}`,
          sender: 'system',
          text: msgText,
          timestamp: nowStr,
          status: 'delivered',
          isTemplate: true,
          buttons: WORKFLOW_TEMPLATES.getOptionsForLang(targetLang),
        };
        return {
          ...c,
          language: targetLang,
          status: 'sent',
          stage: 'stage_1_initial',
          firstMessageSentAt: `${c.date} ${nowStr}`,
          messages: [...c.messages, newMsg],
        };
      })
    );
  }, [appSettings.defaultWhatsAppLanguage]);

  // WhatsApp Action: Toggle Language (English <-> Hindi) with Change Language button always at end
  const toggleCaseLanguage = useCallback((caseId: string) => {
    const nowStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setFollowUpCases((prev) =>
      prev.map((c) => {
        if (c.id !== caseId) return c;
        const currentLang = c.language || 'english';
        const nextLang: 'hindi' | 'english' = currentLang === 'hindi' ? 'english' : 'hindi';

        let switchText = '';
        let buttons: string[] = [];

        if (nextLang === 'hindi') {
          switchText = `भाषा बदलकर हिंदी कर दी गई है।\n\nनमस्ते ${c.employeeName.split(' ')[0]}, हमारी उपस्थिति रिकॉर्ड के अनुसार आप ${c.date} को अनुपस्थित दर्ज हैं। कृपया नीचे दिए गए विकल्पों में से एक चुनें:`;
          buttons = WORKFLOW_TEMPLATES.optionsHindi;
        } else {
          switchText = `Language changed to English.\n\nHi ${c.employeeName.split(' ')[0]}, our attendance record shows you are marked absent on ${c.date}. Please confirm your status by choosing an option below:`;
          buttons = WORKFLOW_TEMPLATES.options;
        }

        const userMsg: ChatMessage = {
          id: `msg-${Date.now()}-lang-req`,
          sender: 'employee',
          text: '🌐 Change Language / भाषा बदलें',
          timestamp: nowStr,
          status: 'read',
        };

        const sysMsg: ChatMessage = {
          id: `msg-${Date.now()}-lang-ack`,
          sender: 'system',
          text: switchText,
          timestamp: nowStr,
          status: 'delivered',
          buttons,
        };

        return {
          ...c,
          language: nextLang,
          messages: [...c.messages, userMsg, sysMsg],
        };
      })
    );
  }, []);

  // WhatsApp Action 2: Process employee reply with Multi-Step Trail Questions, Suggestions & Autonomous Actions
  const logEmployeeReply = useCallback((caseId: string, replyText: string, optionOverride?: 1 | 2 | 3 | 4) => {
    const nowStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    // Check if employee clicked or typed language toggle
    if (
      replyText.includes('Change Language') ||
      replyText.includes('भाषा बदलें') ||
      replyText.toLowerCase().includes('change language') ||
      replyText.toLowerCase().includes('hindi') ||
      replyText.toLowerCase().includes('english')
    ) {
      toggleCaseLanguage(caseId);
      return;
    }

    setFollowUpCases((prev) =>
      prev.map((c) => {
        if (c.id !== caseId) return c;

        const currentLang = c.language || 'english';
        const isHindi = currentLang === 'hindi';

        // 1. Check if user is responding to an active leave duration prompt
        const isDurationResponse =
          replyText.includes('Full Day') ||
          replyText.includes('पूरा दिन') ||
          replyText.includes('First Half') ||
          replyText.includes('पहला हाफ') ||
          replyText.includes('Second Half') ||
          replyText.includes('दूसरा हाफ') ||
          replyText.includes('Half Day') ||
          replyText.includes('आधा दिन');

        // 2. Check if user is choosing a leave type
        const isLeaveTypeResponse =
          replyText.includes('Sick Leave') ||
          replyText.includes('सिक लीव') ||
          replyText.includes('Casual Leave') ||
          replyText.includes('कैजुअल लीव') ||
          replyText.includes('Earned Leave') ||
          replyText.includes('अर्न्ड लीव') ||
          replyText.includes('प्रिविलेज') ||
          replyText.includes('SL') ||
          replyText.includes('CL') ||
          replyText.includes('EL');

        const isSelfLeaveResponse =
          replyText.includes('apply myself') ||
          replyText.includes('खुद पोर्टल पर') ||
          replyText.includes('खुद लगाऊंगा');

        // 3. Check if user is responding with a shift timing
        const isShiftTimingResponse =
          replyText.includes('General Shift') ||
          replyText.includes('जनरल शिफ्ट') ||
          replyText.includes('Morning Shift') ||
          replyText.includes('मॉर्निंग शिफ्ट') ||
          replyText.includes('Late Shift') ||
          replyText.includes('लेट शिफ्ट') ||
          replyText.includes('09:30') ||
          replyText.includes('09:00') ||
          replyText.includes('10:00') ||
          replyText.includes('Custom Timings') ||
          replyText.includes('कस्टम समय');

        // 4. Check if user is responding with punch reason
        const isPunchReasonResponse =
          replyText.includes('Biometric machine') ||
          replyText.includes('मशीन') ||
          replyText.includes('ID Card') ||
          replyText.includes('कार्ड') ||
          replyText.includes('Client') ||
          replyText.includes('क्लाइंट') ||
          replyText.includes('hurry') ||
          replyText.includes('भूल गया') ||
          replyText.includes('On Duty');

        // 5. Check if user is asking to ping/remind manager
        const isManagerPingResponse =
          replyText.includes('reminder to Manager') ||
          replyText.includes('रिमाइंडर भेजो') ||
          replyText.includes('Ping to Manager') ||
          replyText.includes('पिंग करें') ||
          replyText.includes('Pending with Manager') ||
          replyText.includes('पेंडिंग है');

        // 6. Check if user confirms manager already approved
        const isAlreadyApprovedResponse =
          replyText.includes('already approved') ||
          replyText.includes('स्वीकृत हो गया') ||
          replyText.includes('Approved by Manager') ||
          replyText.includes('अप्रूव कर दिया');

        // 7. Check if user is closing satisfied
        const isClosingResponse =
          replyText.includes('All Good') ||
          replyText.includes('सब ठीक है') ||
          replyText.includes('All Set') ||
          replyText.includes('Case Resolved') ||
          replyText.includes('केस क्लोज');

        let systemReplyText = '';
        let nextButtons: string[] = [];
        let newStatus: FollowUpCase['status'] = c.status;
        let newAction = c.action;
        let activeFlowId = c.activeFlowId || 'INITIAL';
        let selectedLeaveType = c.selectedLeaveType;
        let selectedLeaveDuration = c.selectedLeaveDuration;
        let selectedShiftTiming = c.selectedShiftTiming;
        let selectedPunchReason = c.selectedPunchReason;
        let regularizedByAgent = c.regularizedByAgent;
        let inTime = c.inTime;
        let outTime = c.outTime;
        let autonomousActionTaken = c.autonomousActionTaken;
        let determinedOption: 1 | 2 | 3 | 4 | undefined = c.replyOption;

        // --- BRANCH LOGIC ---

        if (isDurationResponse) {
          // Employee selected leave duration -> Execute Autonomous Leave Submission!
          selectedLeaveDuration = replyText.includes('First') || replyText.includes('पहला')
            ? 'First Half'
            : replyText.includes('Second') || replyText.includes('दूसरा')
            ? 'Second Half'
            : 'Full Day';
          const leaveType = selectedLeaveType || (isHindi ? 'सिक लीव (SL)' : 'Sick Leave (SL)');
          activeFlowId = 'FLOW_ABSENT_RESOLVED';
          regularizedByAgent = true;
          autonomousActionTaken = 'Leave Applied via AI Agent';
          newStatus = 'pending-leave';
          newAction = `Leave Applied (${leaveType} ${selectedLeaveDuration}) · Sent to ${c.reportingManager}`;

          systemReplyText = isHindi
            ? `✅ *लीव सफलतापूर्वक दर्ज!*\n\nटैलेंट कैरिज HR शेयर्ड सर्विसेज AI एजेंट ने आपकी ओर से *${c.date}* के लिए *${leaveType} (${selectedLeaveDuration})* HRMS में सबमिट कर दिया है।\n\nआपके रिपोर्टिंग मैनेजर *${c.reportingManager}* को 1-क्लिक अप्रूवल हेतु व्हाट्सएप अलर्ट भेज दिया गया है।`
            : `✅ *Leave Successfully Filed!*\n\nTalent Carriage HR Shared Services AI Agent has applied *${leaveType} (${selectedLeaveDuration})* for *${c.date}* in HRMS on your behalf.\n\nNotification sent to Reporting Manager *${c.reportingManager}* for 1-click authorization.`;

          nextButtons = [
            isHindi ? '👍 धन्यवाद, सब ठीक है!' : '👍 Thank you, All Good!',
            isHindi ? '📄 लीव रिक्वेस्ट देखें' : '📄 View Leave Request ID',
            '🌐 Change Language / भाषा बदलें',
          ];
        } else if (isLeaveTypeResponse) {
          // Employee selected leave type -> Ask trail question for Duration (Full day vs Half day)
          if (replyText.includes('Sick') || replyText.includes('सिक') || replyText.includes('SL')) {
            selectedLeaveType = isHindi ? 'सिक लीव (SL)' : 'Sick Leave (SL)';
            activeFlowId = 'FLOW_ABSENT_DURATION_SL';
          } else if (replyText.includes('Casual') || replyText.includes('कैजुअल') || replyText.includes('CL')) {
            selectedLeaveType = isHindi ? 'कैजुअल लीव (CL)' : 'Casual Leave (CL)';
            activeFlowId = 'FLOW_ABSENT_DURATION_CL';
          } else {
            selectedLeaveType = isHindi ? 'प्रिविलेज / अर्न्ड लीव (EL)' : 'Earned Leave (EL)';
            activeFlowId = 'FLOW_ABSENT_DURATION_EL';
          }

          systemReplyText = isHindi
            ? `आपने *${selectedLeaveType}* चुनी है।\n\nक्या यह पूरे दिन की छुट्टी (Full Day) है या हाफ-डे (Half Day)?`
            : `You selected *${selectedLeaveType}*.\n\nIs this a Full Day leave or Half Day?`;

          nextButtons = [
            isHindi ? '☀️ पूरा दिन (Full Day)' : '☀️ Full Day Leave (पूरा दिन)',
            isHindi ? '⛅ पहला हाफ (First Half)' : '⛅ First Half (पहला हाफ)',
            isHindi ? '🌙 दूसरा हाफ (Second Half)' : '🌙 Second Half (दूसरा हाफ)',
            '🌐 Change Language / भाषा बदलें',
          ];
        } else if (isSelfLeaveResponse) {
          // Employee chooses to apply on portal themselves
          activeFlowId = 'FLOW_ABSENT_SELF';
          newStatus = 'waiting';
          newAction = 'Employee applying on portal';
          systemReplyText = isHindi
            ? `ठीक है। कृपया आज शाम 6:00 बजे से पहले HRMS पोर्टल (hrms.talentcarriage.com) पर जाकर अपनी छुट्टी का आवेदन अवश्य कर दें, ताकि पेरोल में कटौतियां न हों।\n\nयदि बाद में सहायता चाहिए तो कभी भी यहाँ रिप्लाई कर सकते हैं।`
            : `Noted. Please ensure you log into the HRMS portal (hrms.talentcarriage.com) before 6:00 PM today to submit your leave, avoiding any payroll loss.\n\nFeel free to message here if you need any assistance.`;

          nextButtons = [
            isHindi ? '⏰ मुझे 2 घंटे बाद याद दिलाएं' : '⏰ Remind me in 2 hours',
            isHindi ? '🔄 एजेंट से ही अप्लाई करवाएं' : '🔄 Actually, please apply for me',
            '🌐 Change Language / भाषा बदलें',
          ];
        } else if (isPunchReasonResponse) {
          // Employee provided reason for missed punch -> Execute Autonomous Punch Regularization!
          selectedPunchReason = replyText.replace(/^[0-9]\.?\s*/, '').replace(/^[^\w\s]+\s*/, '');
          const shiftTiming = selectedShiftTiming || '09:30 AM - 06:30 PM';
          activeFlowId = 'FLOW_PUNCH_RESOLVED';
          regularizedByAgent = true;
          inTime = inTime || '09:30 AM';
          outTime = outTime || '06:30 PM';
          autonomousActionTaken = 'Punch Regularized in HRMS';
          newStatus = 'pending-regularization';
          newAction = `Punch Regularized (${shiftTiming}) · Sent to ${c.reportingManager}`;

          systemReplyText = isHindi
            ? `✅ *उपस्थिति नियमितीकरण दर्ज!*\n\nटैलेंट कैरिज HR शेयर्ड सर्विसेज AI एजेंट ने आपकी ओर से *${c.date}* के लिए *${shiftTiming}* (कारण: ${selectedPunchReason}) HRMS में नियमित कर दिया है।\n\nमैनेजर *${c.reportingManager}* को तत्काल व्हाट्सएप ऑथराइजेशन लिंक भेज दिया गया है।`
            : `✅ *Attendance Regularized!*\n\nTalent Carriage HR Shared Services AI Agent has regularized your attendance for *${c.date}* (${shiftTiming}, Reason: ${selectedPunchReason}) directly in HRMS on your behalf.\n\nAuthorization link sent to Manager *${c.reportingManager}*.`;

          nextButtons = [
            isHindi ? '👍 सब ठीक है, धन्यवाद!' : '👍 All Set, Thank You!',
            isHindi ? '📲 मैनेजर को अभी व्हाट्सएप पिंग करें' : '📲 Ping Manager on WhatsApp',
            '🌐 Change Language / भाषा बदलें',
          ];
        } else if (isShiftTimingResponse) {
          // Employee selected shift timing -> Ask trail question for Reason
          if (replyText.includes('Morning') || replyText.includes('मॉर्निंग') || replyText.includes('09:00')) {
            selectedShiftTiming = '09:00 AM - 06:00 PM';
            inTime = '09:00 AM';
            outTime = '06:00 PM';
          } else if (replyText.includes('Late') || replyText.includes('लेट') || replyText.includes('10:00')) {
            selectedShiftTiming = '10:00 AM - 07:00 PM';
            inTime = '10:00 AM';
            outTime = '07:00 PM';
          } else {
            selectedShiftTiming = '09:30 AM - 06:30 PM';
            inTime = '09:30 AM';
            outTime = '06:30 PM';
          }

          activeFlowId = 'FLOW_PUNCH_REASON';
          systemReplyText = isHindi
            ? `नियमितीकरण के लिए पंच मिस होने का कारण (Reason) क्या था?\nकृपया चुनें ताकि मैनेजर से तुरंत अप्रूवल मिल सके:`
            : `What was the reason for the missed punch?\nPlease select so your manager can authorize instantly:`;

          nextButtons = [
            isHindi ? '⚙️ बायोमेट्रिक मशीन में तकनीकी समस्या' : '⚙️ Biometric machine error / gate crowd',
            isHindi ? '🪪 आईडी कार्ड भूल गया / गेट पर एंट्री की' : '🪪 Forgot ID Card / Manual Entry at gate',
            isHindi ? '🚗 सीधे क्लाइंट साइट पर था / ऑन-ड्यूटी' : '🚗 Client Visit / Direct Field duty',
            isHindi ? '🏃‍♂️ जल्दी में आउट-पंच करना भूल गया' : '🏃‍♂️ In a hurry / Forgot to swipe out',
            '🌐 Change Language / भाषा बदलें',
          ];
        } else if (isManagerPingResponse) {
          // Employee requested urgent ping to manager
          activeFlowId = 'FLOW_MANAGER_REMINDER_SENT';
          newStatus = 'pending-regularization';
          newAction = `Urgent Ping sent to Manager ${c.reportingManager}`;

          systemReplyText = isHindi
            ? `🔔 *मैनेजर को रिमाइंडर प्रेषित!*\n\nहमने आपके रिपोर्टिंग मैनेजर *${c.reportingManager}* को व्हाट्सएप और सिस्टम नोटिफिकेशन पर प्राथमिकता संदेश भेज दिया है कि वे *${c.date}* की आपकी अर्जी तुरंत स्वीकृत करें।`
            : `🔔 *Manager Reminder Dispatched!*\n\nWe have dispatched a priority alert to your reporting manager *${c.reportingManager}* on WhatsApp to authorize your request for *${c.date}*.\n\nYour attendance will be updated immediately upon sign-off.`;

          nextButtons = [
            isHindi ? '👍 बहुत बढ़िया, धन्यवाद' : '👍 Perfect, Thank You',
            '🌐 Change Language / भाषा बदलें',
          ];
        } else if (isAlreadyApprovedResponse) {
          // Employee confirmed manager already approved
          activeFlowId = 'FLOW_CASE_VERIFIED';
          newStatus = 'verified';
          newAction = 'Verified & Authorized by Manager';

          systemReplyText = isHindi
            ? `🎉 *सत्यापित एवं क्लोज!*\n\nHRMS में रिकॉर्ड री-चेक कर लिया गया है। आपकी उपस्थिति *${c.date}* के लिए अनुमोदित (Approved) है। कोई आगे की कार्यवाही अपेक्षित नहीं है।`
            : `🎉 *Verified & Closed!*\n\nHRMS records re-checked. Your attendance for *${c.date}* is verified and authorized. No further action needed.`;

          nextButtons = [
            isHindi ? '👍 केस क्लोज करें' : '👍 Case Resolved',
            '🌐 Change Language / भाषा बदलें',
          ];
        } else if (isClosingResponse) {
          // Employee confirms satisfaction
          systemReplyText = isHindi
            ? `धन्यवाद! यदि आपको अटेंडेंस या पेरोल के संबंध में कोई अन्य सहायता चाहिए हो, तो आप किसी भी समय HR शेयर्ड सर्विसेज से संपर्क कर सकते हैं। आपका दिन शुभ हो!`
            : `Thank you! If you ever need attendance or payroll assistance, feel free to reach out to Talent Carriage HR Shared Services. Have a great day!`;

          nextButtons = [
            '🌐 Change Language / भाषा बदलें',
          ];
        } else {
          // ROOT LEVEL OR STANDARD OPTION BUTTONS 1-4
          if (!determinedOption) {
            if (replyText.includes('अनुपस्थित') || replyText.includes('absent') || replyText.startsWith('1')) {
              determinedOption = 1;
            } else if (replyText.includes('काम कर रहा') || replyText.includes('working') || replyText.startsWith('2')) {
              determinedOption = 2;
            } else if (replyText.includes('छुट्टी') || replyText.includes('leave') || replyText.startsWith('3')) {
              determinedOption = 3;
            } else if (replyText.includes('नियमितीकरण') || replyText.includes('regularization') || replyText.startsWith('4')) {
              determinedOption = 4;
            } else {
              const res = classifyEmployeeReply(replyText);
              determinedOption = res.option as 1 | 2 | 3 | 4;
            }
          }

          if (determinedOption === 1) {
            // USER REQUEST: If Option 1 (Yes, I was absent) selected -> Agent asks: "Can I apply leave on your behalf?" with options: Sick Leave, EL, CL, Nahi, etc.
            activeFlowId = 'FLOW_ABSENT_STEP1';
            newStatus = 'pending-leave';
            newAction = 'Agent Leave Application Initiated';

            systemReplyText = isHindi
              ? `समझ गया, आपकी अनुपस्थिति नोट कर ली गई है।\n\nक्या मैं आपकी ओर से HRMS पोर्टल पर लीव (Leave) अप्लाई कर दूँ ताकि आपकी सैलरी न कटे?\nकृपया अपनी लीव का प्रकार चुनें:`
              : `Understood, your absence has been noted.\n\nCan I apply for leave on your behalf in the HRMS portal so your salary is not deducted?\nPlease choose your leave type:`;

            nextButtons = [
              isHindi ? '🤒 सिक लीव (SL)' : '🤒 Sick Leave (SL)',
              isHindi ? '📋 कैजुअल लीव (CL)' : '📋 Casual Leave (CL)',
              isHindi ? '🏖️ प्रिविलेज / अर्न्ड लीव (EL)' : '🏖️ Earned Leave (EL)',
              isHindi ? '❌ नहीं, मैं खुद पोर्टल पर लगाऊंगा' : '❌ No, I will apply myself on portal',
              '🌐 Change Language / भाषा बदलें',
            ];
          } else if (determinedOption === 2) {
            // Option 2 (Working / Missed Punch) -> Agent asks to regularize timings & reasons
            activeFlowId = 'FLOW_WORKING_STEP1';
            newStatus = 'pending-regularization';
            newAction = 'Agent Regularization Initiated';

            systemReplyText = isHindi
              ? `समझ गया! आपका बायोमेट्रिक पंच मिस हुआ है।\n\nक्या मैं आपकी ओर से HRMS में अटेंडेंस रेगुलराइज (Regularize) कर दूँ?\nकृपया अपनी शिफ्ट का समय चुनें:`
              : `Got it! Your biometric punch was missed.\n\nCan I regularize your attendance punch in HRMS on your behalf?\nPlease select your shift timings:`;

            nextButtons = [
              isHindi ? '⏰ जनरल शिफ्ट (09:30 AM - 06:30 PM)' : '⏰ General Shift (09:30 AM - 06:30 PM)',
              isHindi ? '⏰ मॉर्निंग शिफ्ट (09:00 AM - 06:00 PM)' : '⏰ Morning Shift (09:00 AM - 06:00 PM)',
              isHindi ? '⏰ लेट शिफ्ट (10:00 AM - 07:00 PM)' : '⏰ Late Shift (10:00 AM - 07:00 PM)',
              isHindi ? '✏️ कस्टम समय दर्ज करें' : '✏️ Custom Timings (कस्टम समय)',
              '🌐 Change Language / भाषा बदलें',
            ];
          } else if (determinedOption === 3) {
            // Option 3 (Already applied leave) -> Ask status & offer 1-click manager reminder
            activeFlowId = 'FLOW_APPLIED_LEAVE_STEP1';
            newStatus = 'verification';
            newAction = 'Awaiting Manager Sign-off';

            systemReplyText = isHindi
              ? `धन्यवाद! आपकी लीव अर्जी की स्थिति क्या है?\nक्या मैनेजर द्वारा इसे अप्रूव कर दिया गया है या पेंडिंग है?`
              : `Thank you! What is the current status of your leave application?\nIs it pending manager authorization or already approved?`;

            nextButtons = [
              isHindi ? '⏳ मैनेजर अप्रूवल पेंडिंग है' : '⏳ Manager approval pending',
              isHindi ? '✅ मैनेजर ने अप्रूव कर दिया है' : '✅ Manager has already approved',
              isHindi ? '🔔 मैनेजर को तुरंत रिमाइंडर भेजो' : '🔔 Send urgent reminder to Manager',
              '🌐 Change Language / भाषा बदलें',
            ];
          } else if (determinedOption === 4) {
            // Option 4 (Already sent regularization) -> Ask status & offer 1-click manager alert
            activeFlowId = 'FLOW_REGULARIZATION_STEP1';
            newStatus = 'pending-regularization';
            newAction = 'Regularization Verification';

            systemReplyText = isHindi
              ? `शानदार! आपने नियमितीकरण भेजा है।\nक्या आपके रिपोर्टिंग मैनेजर *${c.reportingManager}* ने इसे ऑथराइज कर दिया है?`
              : `Great! You have sent regularization.\nHas your reporting manager *${c.reportingManager}* authorized it in the portal?`;

            nextButtons = [
              isHindi ? '⏳ मैनेजर के पास पेंडिंग है' : '⏳ Pending with Manager',
              isHindi ? '✅ मैनेजर द्वारा स्वीकृत हो गया' : '✅ Approved by Manager',
              isHindi ? '📲 मैनेजर को तत्काल व्हाट्सएप पिंग' : '📲 Urgent Ping to Manager',
              '🌐 Change Language / भाषा बदलें',
            ];
          } else {
            systemReplyText = WORKFLOW_TEMPLATES.unclearReply(c.date, currentLang);
            newStatus = 'waiting';
            newAction = 'Awaiting clarification';
            nextButtons = WORKFLOW_TEMPLATES.getOptionsForLang(currentLang);
          }
        }

        const userMsg: ChatMessage = {
          id: `msg-${Date.now()}-emp`,
          sender: 'employee',
          text: replyText,
          timestamp: nowStr,
          status: 'read',
        };

        const sysMsg: ChatMessage = {
          id: `msg-${Date.now()}-sys`,
          sender: 'system',
          text: systemReplyText,
          timestamp: nowStr,
          status: 'read',
          buttons: nextButtons,
        };

        return {
          ...c,
          reply: replyText,
          replyOption: determinedOption || c.replyOption,
          replyType: optionOverride ? 'button' : 'free_text',
          status: newStatus,
          action: newAction,
          stage: 'stage_1_initial',
          firstReplyReceivedAt: c.firstReplyReceivedAt || `${c.date} ${nowStr}`,
          activeFlowId,
          selectedLeaveType,
          selectedLeaveDuration,
          selectedShiftTiming,
          selectedPunchReason,
          regularizedByAgent,
          inTime,
          outTime,
          autonomousActionTaken,
          messages: [...c.messages, userMsg, sysMsg],
        };
      })
    );
  }, [toggleCaseLanguage]);

  // WhatsApp Action 3: Send 2-day reminder (Stage 2 in Workflow.svg)
  const sendTwoDayReminder = useCallback((caseId: string) => {
    const nowStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setFollowUpCases((prev) =>
      prev.map((c) => {
        if (c.id !== caseId) return c;
        const currentLang = c.language || 'english';
        const reminderText = WORKFLOW_TEMPLATES.twoDayReminder(c.replyOption, c.date, currentLang);
        const reminderMsg: ChatMessage = {
          id: `msg-${Date.now()}-rem`,
          sender: 'system',
          text: reminderText,
          timestamp: `${nowStr} (2 days later)`,
          status: 'delivered',
          buttons: currentLang === 'hindi' ? WORKFLOW_TEMPLATES.twoDayOptionsHindi : WORKFLOW_TEMPLATES.twoDayOptions,
        };
        return {
          ...c,
          stage: 'stage_2_followup',
          twoDayReminderSentAt: nowStr,
          messages: [...c.messages, reminderMsg],
        };
      })
    );
  }, []);

  // WhatsApp Action 4: Log 2-day reminder reply
  const logTwoDayReply = useCallback((caseId: string, replyChoice: 'done' | 'not_done' | 'need_help') => {
    const nowStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setFollowUpCases((prev) =>
      prev.map((c) => {
        if (c.id !== caseId) return c;

        let replyLabel = '';
        let newStatus = c.status;
        let newAction = c.action;
        let nextStage = c.stage;

        if (replyChoice === 'done') {
          replyLabel = c.language === 'hindi' ? '1. हो गया (Done)' : '1. Done';
          newStatus = 'verification';
          newAction = 'Wait for HR verification / close';
          nextStage = 'resolved';
        } else if (replyChoice === 'not_done') {
          replyLabel = c.language === 'hindi' ? '2. नहीं हुआ (Not Done)' : '2. Not Done';
          newStatus = 'call-required';
          newAction = 'Automated call required';
          nextStage = 'stage_3_call';
        } else {
          replyLabel = c.language === 'hindi' ? '3. मदद चाहिए (Need Help)' : '3. Need Help';
          newStatus = 'call-required';
          newAction = 'Call required / HR help required';
          nextStage = 'stage_3_call';
        }

        const replyMsg: ChatMessage = {
          id: `msg-${Date.now()}-rem-rep`,
          sender: 'employee',
          text: replyLabel,
          timestamp: nowStr,
          status: 'read',
        };

        return {
          ...c,
          twoDayReply: replyChoice,
          status: newStatus,
          action: newAction,
          stage: nextStage,
          messages: [...c.messages, replyMsg],
        };
      })
    );
  }, []);

  // Call Center Action 1: Trigger Automated Call
  const triggerCall = useCallback((caseId: string) => {
    const nowStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setFollowUpCases((prev) =>
      prev.map((c) => {
        if (c.id !== caseId) return c;
        return {
          ...c,
          status: 'call-logged',
          stage: 'stage_3_call',
          callTriggeredAt: nowStr,
        };
      })
    );
  }, []);

  // Call Center Action 2: Log Call Outcome
  const logCallOutcome = useCallback(
    (caseId: string, outcome: 'completed' | 'not_completed' | 'needs_help' | 'no_answer', notes?: string) => {
      setFollowUpCases((prev) =>
        prev.map((c) => {
          if (c.id !== caseId) return c;

          let newStatus: FollowUpCase['status'] = 'call-logged';
          let newAction = c.action;
          let newStage: FollowUpCase['stage'] = c.stage;

          if (outcome === 'completed') {
            newStatus = 'verified';
            newAction = 'Verified & Closed';
            newStage = 'resolved';
          } else if (outcome === 'not_completed') {
            newStatus = 'hr-escalated';
            newAction = 'HR Escalation Required';
          } else if (outcome === 'needs_help') {
            newStatus = 'hr-escalated';
            newAction = 'HR Follow-up Support Required';
          } else {
            newStatus = 'call-required';
            newAction = 'Retry / HR Escalation';
          }

          return {
            ...c,
            callOutcome: outcome,
            callNotes: notes,
            status: newStatus,
            action: newAction,
            stage: newStage,
          };
        })
      );
    },
    []
  );

  // Close / Verify case
  const markCaseVerified = useCallback((caseId: string) => {
    setFollowUpCases((prev) =>
      prev.map((c) => {
        if (c.id !== caseId) return c;
        return {
          ...c,
          status: 'verified',
          stage: 'resolved',
          action: 'Case Closed & Verified',
        };
      })
    );
  }, []);

  // Import parsed cases
  const importParsedCases = useCallback((newCases: FollowUpCase[]) => {
    setFollowUpCases((prev) => {
      // Merge by employeeCode + date
      const existingKeys = new Set(prev.map((c) => `${c.employeeName}_${c.date}`));
      const fresh = newCases.filter((c) => !existingKeys.has(`${c.employeeName}_${c.date}`));
      return [...fresh, ...prev];
    });
    if (newCases.length > 0) {
      setSelectedCaseId(newCases[0].id);
    }
  }, []);

  // Run daily check for specific date
  const runDailyCheckForDate = useCallback(
    (dateStr: string) => {
      // Look for check-in records or employees with absent marks on that date
      let created = 0;
      employees.forEach((emp) => {
        const existingCase = followUpCases.find((c) => c.employeeName === emp.name && c.date === dateStr);
        if (!existingCase) {
          const newCase: FollowUpCase = {
            id: `case-auto-${emp.id}-${Date.now()}`,
            employeeId: emp.id,
            employeeName: emp.name,
            employeeCode: emp.id.toUpperCase(),
            department: emp.department,
            reportingManager: 'Priya Sharma',
            mobileNumber: '919876543210',
            date: dateStr,
            code: 'A|A',
            reply: 'Waiting',
            action: 'Pending response',
            status: 'waiting',
            stage: 'stage_1_initial',
            firstMessageSentAt: `${dateStr} 10:00`,
            messages: [
              {
                id: `msg-${Date.now()}`,
                sender: 'system',
                text: WORKFLOW_TEMPLATES.firstMessage(emp.name, dateStr, 'A|A'),
                timestamp: '10:00 AM',
                status: 'delivered',
                isTemplate: true,
                buttons: WORKFLOW_TEMPLATES.options,
              },
            ],
          };
          created++;
          setFollowUpCases((prev) => [newCase, ...prev]);
        }
      });

      return {
        createdCount: created,
        message: `Attendance check completed for ${dateStr}. Flagged ${created} absentee follow-up cases.`,
      };
    },
    [employees, followUpCases]
  );

  // Manager Escalation: Send WhatsApp notification to Reporting Manager
  const sendManagerWhatsApp = useCallback((caseId: string) => {
    const nowStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const targetCase = followUpCases.find((c) => c.id === caseId);
    if (!targetCase) return;

    const actionText =
      targetCase.replyOption === 1 || targetCase.status === 'pending-leave'
        ? 'Leave'
        : 'Regularization';

    const managerMsg = WORKFLOW_TEMPLATES.managerWhatsAppNotification(
      targetCase.reportingManager,
      targetCase.employeeName,
      targetCase.date,
      actionText,
      targetCase.language || appSettings.defaultWhatsAppLanguage || 'english'
    );

    const newSysMsg: ChatMessage = {
      id: `msg-mgr-${Date.now()}`,
      sender: 'system',
      text: `📲 [Automated Manager Dispatch]\nSent WhatsApp to Reporting Manager (${targetCase.reportingManager}):\n\n"${managerMsg}"`,
      timestamp: nowStr,
      status: 'delivered',
      buttons: ['✅ Manager Approved', '❌ Manager Rejected'],
    };

    setFollowUpCases((prev) =>
      prev.map((c) => {
        if (c.id !== caseId) return c;
        return {
          ...c,
          managerNotifiedAt: `${c.date} ${nowStr}`,
          managerNotificationMethod: c.managerNotificationMethod === 'call' ? 'both' : 'whatsapp',
          managerApprovalStatus: 'pending',
          messages: [...c.messages, newSysMsg],
        };
      })
    );

    const notificationItem: ManagerNotificationItem = {
      id: `mn-${Date.now()}`,
      caseId,
      employeeName: targetCase.employeeName,
      employeeCode: targetCase.employeeCode,
      managerName: targetCase.reportingManager,
      managerPhone: targetCase.managerPhone || '+919876543220',
      date: targetCase.date,
      reason: targetCase.reply || `${actionText} application pending approval`,
      type: 'whatsapp',
      status: 'pending',
      timestamp: `${targetCase.date} ${nowStr}`,
      lastResponse: 'WhatsApp template delivered to manager',
    };

    setManagerNotifications((prev) => [
      notificationItem,
      ...prev.filter((item) => item.caseId !== caseId),
    ]);

    const activity: LiveActivityFeedItem = {
      id: `act-${Date.now()}`,
      employeeId: targetCase.employeeId || 'emp-2',
      employeeName: targetCase.employeeName,
      employeeAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
      action: 'regularize_submitted',
      timestamp: nowStr,
      details: `Dispatched WhatsApp authorization request to Manager ${targetCase.reportingManager}`,
    };
    setLiveActivities((prev) => [activity, ...prev.slice(0, 24)]);
  }, [followUpCases, appSettings]);

  // Plivo Call Action: Trigger outbound call to employee from Plivo Virtual Number
  const triggerPlivoCall = useCallback(
    async (caseId: string, language?: 'hindi' | 'english') => {
      const targetCase = followUpCases.find((c) => c.id === caseId);
      if (!targetCase) return { success: false, callUuid: '', message: 'Case not found' };

      const lang = language || targetCase.language || appSettings.defaultCallLanguage || 'hindi';
      const plivoRes = await initiatePlivoCall({
        to: targetCase.mobileNumber,
        caseId: targetCase.id,
        employeeName: targetCase.employeeName,
        date: targetCase.date,
        language: lang,
        customCallerId: appSettings.plivoPhoneNumber,
      });

      const nowStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

      setFollowUpCases((prev) =>
        prev.map((c) => {
          if (c.id !== caseId) return c;
          return {
            ...c,
            status: 'call-logged',
            stage: 'stage_3_call',
            callTriggeredAt: nowStr,
            plivoCallUuid: plivoRes.callUuid,
            plivoCallStatus: plivoRes.status,
            callerNumber: plivoRes.callerId,
            callNotes: `Outbound agent call via Plivo virtual number ${plivoRes.callerId} (${plivoRes.mode})`,
          };
        })
      );

      const log: AutoTriggerLog = {
        id: `atl-${Date.now()}`,
        timestamp: nowStr,
        triggerType: 'stage_3_plivo_call',
        caseId: targetCase.id,
        employeeName: targetCase.employeeName,
        status: 'success',
        details: `Plivo Call placed to ${targetCase.employeeName} from ${plivoRes.callerId} (Call UUID: ${plivoRes.callUuid})`,
      };
      setAutoTriggerLogs((prev) => [log, ...prev.slice(0, 49)]);

      return {
        success: plivoRes.success,
        callUuid: plivoRes.callUuid,
        message: plivoRes.message || `Outbound Plivo call connected from ${plivoRes.callerId}`,
      };
    },
    [followUpCases, appSettings]
  );

  // Plivo Manager Call Action: Trigger outbound IVR call to reporting manager
  const triggerPlivoManagerCall = useCallback(
    async (caseId: string, language?: 'hindi' | 'english') => {
      const targetCase = followUpCases.find((c) => c.id === caseId);
      if (!targetCase) return { success: false, callUuid: '', message: 'Case not found' };

      const lang = language || targetCase.language || appSettings.defaultCallLanguage || 'hindi';
      const plivoRes = await initiatePlivoManagerCall({
        to: targetCase.managerPhone || '+919876543220',
        caseId: targetCase.id,
        employeeName: targetCase.employeeName,
        managerName: targetCase.reportingManager,
        date: targetCase.date,
        language: lang,
        customCallerId: appSettings.plivoPhoneNumber,
      });

      const nowStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

      setFollowUpCases((prev) =>
        prev.map((c) => {
          if (c.id !== caseId) return c;
          return {
            ...c,
            managerNotifiedAt: `${c.date} ${nowStr}`,
            managerNotificationMethod: c.managerNotificationMethod === 'whatsapp' ? 'both' : 'call',
            managerApprovalStatus: 'pending',
          };
        })
      );

      const notificationItem: ManagerNotificationItem = {
        id: `mn-call-${Date.now()}`,
        caseId,
        employeeName: targetCase.employeeName,
        employeeCode: targetCase.employeeCode,
        managerName: targetCase.reportingManager,
        managerPhone: targetCase.managerPhone || '+919876543220',
        date: targetCase.date,
        reason: targetCase.reply || `Attendance authorization pending`,
        type: 'both',
        status: 'pending',
        timestamp: `${targetCase.date} ${nowStr}`,
        lastResponse: `Plivo IVR call placed (UUID: ${plivoRes.callUuid})`,
      };

      setManagerNotifications((prev) => [
        notificationItem,
        ...prev.filter((item) => item.caseId !== caseId),
      ]);

      const log: AutoTriggerLog = {
        id: `atl-${Date.now()}`,
        timestamp: nowStr,
        triggerType: 'manager_notification',
        caseId: targetCase.id,
        employeeName: targetCase.employeeName,
        status: 'escalated',
        details: `Plivo Manager IVR Call placed to ${targetCase.reportingManager} from ${plivoRes.callerId}`,
      };
      setAutoTriggerLogs((prev) => [log, ...prev.slice(0, 49)]);

      return {
        success: plivoRes.success,
        callUuid: plivoRes.callUuid,
        message: plivoRes.message || `Outbound Plivo Manager IVR Call connected`,
      };
    },
    [followUpCases, appSettings]
  );

  // Response Processing: Process Employee Agent Response (WhatsApp or Call) and update tool
  const processAgentResponse = useCallback(
    (
      caseId: string,
      responseOption: 1 | 2 | 3 | 4,
      source: 'whatsapp' | 'call',
      customNotes?: string
    ) => {
      const targetCase = followUpCases.find((c) => c.id === caseId);
      if (!targetCase) return;

      const nowStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

      let newStatus: FollowUpCase['status'] = targetCase.status;
      let newAction = targetCase.action;
      let replyLabel = '';

      if (responseOption === 1) {
        replyLabel = targetCase.language === 'hindi' ? '1. हाँ, मैं अनुपस्थित था' : '1. Yes, I was absent';
        newStatus = 'pending-leave';
        newAction = 'Apply leave';
      } else if (responseOption === 2) {
        replyLabel = targetCase.language === 'hindi' ? '2. नहीं, मैं काम कर रहा था' : '2. No, I was working';
        newStatus = 'pending-regularization';
        newAction = 'Apply regularization';
      } else if (responseOption === 3) {
        replyLabel = targetCase.language === 'hindi' ? '3. मैंने छुट्टी के लिए आवेदन कर दिया है' : '3. I have already applied leave';
        newStatus = 'verification';
        newAction = 'Verify leave in HRMS (Manager Authorization)';
      } else if (responseOption === 4) {
        replyLabel = targetCase.language === 'hindi' ? '4. मैंने नियमितीकरण भेज दिया है' : '4. I have already sent regularization request';
        newStatus = 'verification';
        newAction = 'Awaiting Manager Approval';
      }

      setFollowUpCases((prev) =>
        prev.map((c) => {
          if (c.id !== caseId) return c;
          const userMsg: ChatMessage = {
            id: `msg-${Date.now()}-${source}`,
            sender: 'employee',
            text: replyLabel,
            timestamp: nowStr,
            status: 'read',
          };
          return {
            ...c,
            reply: replyLabel,
            replyOption: responseOption,
            status: newStatus,
            action: newAction,
            firstReplyReceivedAt: `${c.date} ${nowStr}`,
            callOutcome: source === 'call' ? 'completed' : c.callOutcome,
            callNotes: customNotes || c.callNotes,
            messages: [...c.messages, userMsg],
          };
        })
      );

      // If employee confirms they have applied (option 3 or 4), automatically trigger Manager Notification!
      if (responseOption === 3 || responseOption === 4) {
        if (appSettings.autoNotifyManagerOnApplied) {
          sendManagerWhatsApp(caseId);
        }
        if (appSettings.autoCallManagerOnApplied) {
          triggerPlivoManagerCall(caseId);
        }
      }
    },
    [followUpCases, appSettings, sendManagerWhatsApp, triggerPlivoManagerCall]
  );

  // Manager Approval: Approve attendance regularization request
  const approveByManager = useCallback(
    (caseId: string, notes?: string) => {
      const now = new Date();
      const nowStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      const targetCase = followUpCases.find((c) => c.id === caseId);
      if (!targetCase) return;

      const approvalNote = notes || `Approved by ${targetCase.reportingManager}`;

      setFollowUpCases((prev) =>
        prev.map((c) => {
          if (c.id !== caseId) return c;
          const confirmMsg: ChatMessage = {
            id: `msg-mgr-appr-${Date.now()}`,
            sender: 'system',
            text: `🎉 *अटेंडेंस स्वीकृत*: आपके मैनेजर ${c.reportingManager} ने ${c.date} की उपस्थिति को नियमित कर दिया है। Your attendance regularization has been authorized and marked Regularized.`,
            timestamp: nowStr,
            status: 'read',
          };
          return {
            ...c,
            managerApprovalStatus: 'approved',
            managerApprovalNotes: approvalNote,
            managerApprovedAt: `${c.date} ${nowStr}`,
            status: 'verified',
            stage: 'resolved',
            action: 'Approved & Regularized by Manager',
            messages: [...c.messages, confirmMsg],
          };
        })
      );

      setManagerNotifications((prev) =>
        prev.map((item) => {
          if (item.caseId === caseId) {
            return {
              ...item,
              status: 'approved',
              approvalNotes: approvalNote,
              reviewedAt: nowStr,
              lastResponse: `Approved by manager (${approvalNote})`,
            };
          }
          return item;
        })
      );

      setRegularizationRequests((prev) =>
        prev.map((req) => {
          if (req.employeeName === targetCase.employeeName && req.date === targetCase.date) {
            return {
              ...req,
              status: 'approved',
              reviewedAt: `${req.date} ${nowStr}`,
              reviewedBy: targetCase.reportingManager,
              reviewerNotes: approvalNote,
            };
          }
          return req;
        })
      );

      setCheckInRecords((prev) =>
        prev.map((rec) => {
          if (rec.date === targetCase.date) {
            return {
              ...rec,
              regularityStatus: 'regularized',
              flags: [
                ...rec.flags.filter((f) => !f.toLowerCase().includes('pending')),
                'Manager Authorized & Regularized',
              ],
            };
          }
          return rec;
        })
      );

      const activity: LiveActivityFeedItem = {
        id: `act-${Date.now()}`,
        employeeId: targetCase.employeeId || 'emp-2',
        employeeName: targetCase.employeeName,
        employeeAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
        action: 'regularize_approved',
        timestamp: nowStr,
        details: `Regularization approved by Manager ${targetCase.reportingManager} for ${targetCase.date}`,
      };
      setLiveActivities((prev) => [activity, ...prev.slice(0, 24)]);
    },
    [followUpCases]
  );

  // Manager Approval: Reject attendance regularization request
  const rejectByManager = useCallback(
    (caseId: string, reason?: string) => {
      const nowStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      const targetCase = followUpCases.find((c) => c.id === caseId);
      if (!targetCase) return;

      const rejectReason = reason || 'Attendance regularization rejected by reporting manager';

      setFollowUpCases((prev) =>
        prev.map((c) => {
          if (c.id !== caseId) return c;
          const rejectMsg: ChatMessage = {
            id: `msg-mgr-rej-${Date.now()}`,
            sender: 'system',
            text: `⚠️ *अटेंडेंस अस्वीकृत*: आपके मैनेजर ${c.reportingManager} ने ${c.date} की उपस्थिति को अस्वीकार कर दिया है। कारण: "${rejectReason}"। कृपया HR टीम से संपर्क करें।`,
            timestamp: nowStr,
            status: 'read',
          };
          return {
            ...c,
            managerApprovalStatus: 'rejected',
            managerApprovalNotes: rejectReason,
            status: 'hr-escalated',
            action: 'Rejected by Manager (HR Escalation Required)',
            hrEscalationReason: rejectReason,
            messages: [...c.messages, rejectMsg],
          };
        })
      );

      setManagerNotifications((prev) =>
        prev.map((item) => {
          if (item.caseId === caseId) {
            return {
              ...item,
              status: 'rejected',
              approvalNotes: rejectReason,
              reviewedAt: nowStr,
              lastResponse: `Rejected by manager (${rejectReason})`,
            };
          }
          return item;
        })
      );
    },
    [followUpCases]
  );

  // Workflow Reminder Auto-Trigger Sweep
  const runWorkflowAutoTrigger = useCallback(() => {
    let s1 = 0;
    let s2 = 0;
    let s3 = 0;
    let mgrNotif = 0;
    const nowStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const newLogs: AutoTriggerLog[] = [];

    followUpCases.forEach((c) => {
      // Rule 1: Stage 1 WhatsApp prompt if case is waiting and never sent
      if (c.stage === 'stage_1_initial' && c.status === 'waiting' && !c.firstMessageSentAt) {
        sendFirstWhatsApp(c.id);
        s1++;
        newLogs.push({
          id: `atl-${Date.now()}-${s1}`,
          timestamp: nowStr,
          triggerType: 'stage_1_whatsapp',
          caseId: c.id,
          employeeName: c.employeeName,
          status: 'success',
          details: `Auto-sent initial WhatsApp prompt to ${c.employeeName} (${c.mobileNumber})`,
        });
      }

      // Rule 2: Stage 2 reminder if case is still pending after initial prompt
      if (
        c.stage === 'stage_1_initial' &&
        (c.status === 'pending-leave' || c.status === 'pending-regularization' || c.status === 'waiting') &&
        !c.twoDayReminderSentAt
      ) {
        sendTwoDayReminder(c.id);
        s2++;
        newLogs.push({
          id: `atl-${Date.now()}-${s2}`,
          timestamp: nowStr,
          triggerType: 'stage_2_reminder',
          caseId: c.id,
          employeeName: c.employeeName,
          status: 'success',
          details: `Auto-sent 48-hr follow-up reminder to ${c.employeeName}`,
        });
      }

      // Rule 3: Stage 3 automated call escalation if employee replied not_done or need_help
      if (
        c.stage === 'stage_2_followup' &&
        (c.twoDayReply === 'not_done' || c.twoDayReply === 'need_help' || c.status === 'call-required') &&
        !c.callTriggeredAt
      ) {
        triggerPlivoCall(c.id);
        s3++;
        newLogs.push({
          id: `atl-${Date.now()}-${s3}`,
          timestamp: nowStr,
          triggerType: 'stage_3_plivo_call',
          caseId: c.id,
          employeeName: c.employeeName,
          status: 'success',
          details: `Auto-initiated Plivo call from virtual number ${appSettings.plivoPhoneNumber} to ${c.employeeName}`,
        });
      }

      // Rule 4: Manager notification if employee has confirmed applied but manager not notified
      if (
        (c.replyOption === 3 || c.replyOption === 4 || c.twoDayReply === 'done') &&
        !c.managerNotifiedAt &&
        c.status !== 'verified'
      ) {
        sendManagerWhatsApp(c.id);
        if (appSettings.autoCallManagerOnApplied) {
          triggerPlivoManagerCall(c.id);
        }
        mgrNotif++;
        newLogs.push({
          id: `atl-${Date.now()}-${mgrNotif}`,
          timestamp: nowStr,
          triggerType: 'manager_notification',
          caseId: c.id,
          employeeName: c.employeeName,
          status: 'escalated',
          details: `Auto-notified Reporting Manager ${c.reportingManager} via WhatsApp & Plivo IVR Call`,
        });
      }
    });

    if (newLogs.length === 0) {
      newLogs.push({
        id: `atl-${Date.now()}-sweep`,
        timestamp: nowStr,
        triggerType: 'daily_sweep',
        caseId: 'all',
        employeeName: 'System Engine',
        status: 'success',
        details: `Active sweep verified all ${followUpCases.length} cases. All workflow states up to date.`,
      });
    }

    setAutoTriggerLogs((prev) => [...newLogs, ...prev.slice(0, 50)]);

    return {
      stage1Count: s1,
      stage2Count: s2,
      stage3Count: s3,
      managerNotifiedCount: mgrNotif,
      message: `Auto-trigger sweep executed: ${s1} Stage 1 prompts, ${s2} Stage 2 reminders, ${s3} Plivo calls, ${mgrNotif} manager alerts.`,
    };
  }, [
    followUpCases,
    sendFirstWhatsApp,
    sendTwoDayReminder,
    triggerPlivoCall,
    sendManagerWhatsApp,
    triggerPlivoManagerCall,
    appSettings,
  ]);

  const clearAutoTriggerLogs = useCallback(() => {
    setAutoTriggerLogs([]);
  }, []);

  // Background Auto-Trigger Interval
  useEffect(() => {
    if (!appSettings.autoTriggerEnabled) return;
    const intervalMs = Math.max(15, appSettings.autoTriggerIntervalMinutes || 30) * 60 * 1000;
    const timer = setInterval(() => {
      runWorkflowAutoTrigger();
    }, intervalMs);
    return () => clearInterval(timer);
  }, [appSettings.autoTriggerEnabled, appSettings.autoTriggerIntervalMinutes, runWorkflowAutoTrigger]);

  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_employees`, JSON.stringify(employees));
      localStorage.setItem(`${STORAGE_KEY}_policy`, JSON.stringify(policy));
      localStorage.setItem(`${STORAGE_KEY}_records`, JSON.stringify(checkInRecords));
      localStorage.setItem(`${STORAGE_KEY}_events`, JSON.stringify(calendarEvents));
      localStorage.setItem(`${STORAGE_KEY}_regularizations`, JSON.stringify(regularizationRequests));
      localStorage.setItem(`${STORAGE_KEY}_activities`, JSON.stringify(liveActivities));
    } catch (e) {
      console.warn('Failed to save to localStorage:', e);
    }
  }, [employees, policy, checkInRecords, calendarEvents, regularizationRequests, liveActivities]);

  const currentEmployee = useMemo(() => {
    return employees.find((e) => e.id === currentEmployeeId) || employees[0];
  }, [employees, currentEmployeeId]);

  const todayStr = getTodayStr();

  const todayRecord = useMemo(() => {
    return checkInRecords.find(
      (r) => r.employeeId === currentEmployee.id && r.date === todayStr
    );
  }, [checkInRecords, currentEmployee.id, todayStr]);

  // Match calendar event with attendance discrepancy
  const detectCalendarReconciliation = useCallback(
    (employeeId: string, date: string, checkInTime: string): CalendarEvent | null => {
      const empEvents = calendarEvents.filter(
        (ev) => ev.employeeId === employeeId && ev.date === date
      );
      if (empEvents.length === 0) return null;

      const [inH, inM] = checkInTime.split(':').map(Number);
      const checkInMinutes = inH * 60 + inM;

      // Find an event that started before or around check-in time (e.g., between 8:00 and 11:30)
      for (const ev of empEvents) {
        const [startH, startM] = ev.startTime.split(':').map(Number);
        const [endH, endM] = ev.endTime.split(':').map(Number);
        const evStartMinutes = startH * 60 + startM;
        const evEndMinutes = endH * 60 + endM;

        // If the event covers the standard shift start or ends near check-in time
        if (evStartMinutes <= 555 && evEndMinutes >= 540) {
          return ev;
        }
        if (Math.abs(checkInMinutes - evEndMinutes) <= 45 && evStartMinutes <= 570) {
          return ev;
        }
      }
      return empEvents[0] || null;
    },
    [calendarEvents]
  );

  // Check In Handler
  const checkIn = useCallback(
    (workMode: WorkMode, locationName: string, notes?: string, coordinates?: { lat: number; lng: number }) => {
      const now = new Date();
      const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(
        now.getMinutes()
      ).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
      const today = getTodayStr();

      const [shiftH, shiftM] = currentEmployee.shiftStart.split(':').map(Number);
      const shiftStartMinutes = shiftH * 60 + shiftM;
      const currentMinutes = now.getHours() * 60 + now.getMinutes();
      const graceMinutes = currentEmployee.graceMinutes || policy.gracePeriodMinutes;

      const isLate = currentMinutes > shiftStartMinutes + graceMinutes;
      const flags: string[] = [];
      let regularityStatus: CheckInRecord['regularityStatus'] = 'compliant';

      if (isLate) {
        const lateBy = currentMinutes - shiftStartMinutes;
        flags.push(`Late arrival (${lateBy}m past ${currentEmployee.shiftStart})`);
        regularityStatus = 'irregular';

        // Check if calendar event reconciles it
        const matchedEvent = detectCalendarReconciliation(currentEmployee.id, today, timeStr);
        if (matchedEvent) {
          flags.push(`Matches Calendar Event: "${matchedEvent.title}" (${matchedEvent.startTime} - ${matchedEvent.endTime})`);
        }
      } else {
        flags.push('Punctual check-in');
      }

      if (workMode === 'remote') {
        flags.push('Remote Work Logged');
      } else if (workMode === 'client_site') {
        flags.push('Client Site Attendance');
      }

      const newRecord: CheckInRecord = {
        id: `rec-${Date.now()}`,
        employeeId: currentEmployee.id,
        date: today,
        checkInTime: timeStr,
        workMode,
        locationName,
        coordinates,
        breaks: [],
        totalWorkMinutes: 1,
        totalBreakMinutes: 0,
        regularityStatus,
        flags,
        notes,
      };

      setCheckInRecords((prev) => {
        const filtered = prev.filter(
          (r) => !(r.employeeId === currentEmployee.id && r.date === today)
        );
        return [newRecord, ...filtered];
      });

      // Add to live activity
      const activity: LiveActivityFeedItem = {
        id: `act-${Date.now()}`,
        employeeId: currentEmployee.id,
        employeeName: currentEmployee.name,
        employeeAvatar: currentEmployee.avatar,
        action: 'check_in',
        timestamp: `${String(now.getHours() % 12 || 12).padStart(2, '0')}:${String(
          now.getMinutes()
        ).padStart(2, '0')} ${now.getHours() >= 12 ? 'PM' : 'AM'}`,
        workMode,
        details: `Checked in at ${locationName} [${regularityStatus === 'irregular' ? 'Flagged: Late arrival' : 'Compliant'}]`,
      };

      setLiveActivities((prev) => [activity, ...prev.slice(0, 24)]);
    },
    [currentEmployee, policy, detectCalendarReconciliation]
  );

  // Check Out Handler
  const checkOut = useCallback(
    (notes?: string) => {
      const now = new Date();
      const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(
        now.getMinutes()
      ).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
      const today = getTodayStr();

      setCheckInRecords((prev) =>
        prev.map((rec) => {
          if (rec.employeeId === currentEmployee.id && rec.date === today) {
            // Close any active break
            const updatedBreaks = rec.breaks.map((b) => {
              if (!b.endTime) {
                return {
                  ...b,
                  endTime: timeStr,
                  durationMinutes: Math.max(1, Math.round((Date.now() - new Date(`${today}T${b.startTime}`).getTime()) / 60000)),
                };
              }
              return b;
            });

            // Calculate total work minutes
            const checkInDate = new Date(`${today}T${rec.checkInTime}`);
            const totalShiftMinutes = Math.max(1, Math.round((now.getTime() - checkInDate.getTime()) / 60000));
            const totalBreakMinutes = updatedBreaks.reduce((acc, b) => acc + (b.durationMinutes || 0), 0);
            const actualWorkMinutes = Math.max(0, totalShiftMinutes - totalBreakMinutes);

            const isEarly = actualWorkMinutes < policy.minFullDayHours * 60;
            const updatedFlags = [...rec.flags];
            if (isEarly && rec.regularityStatus === 'compliant') {
              updatedFlags.push(`Early departure (${(actualWorkMinutes / 60).toFixed(1)} hrs worked)`);
            }

            return {
              ...rec,
              checkOutTime: timeStr,
              breaks: updatedBreaks,
              totalWorkMinutes: actualWorkMinutes,
              totalBreakMinutes,
              regularityStatus: isEarly ? 'irregular' : rec.regularityStatus,
              flags: updatedFlags,
              notes: notes ? `${rec.notes ? `${rec.notes} | ` : ''}${notes}` : rec.notes,
            };
          }
          return rec;
        })
      );

      const activity: LiveActivityFeedItem = {
        id: `act-${Date.now()}`,
        employeeId: currentEmployee.id,
        employeeName: currentEmployee.name,
        employeeAvatar: currentEmployee.avatar,
        action: 'check_out',
        timestamp: `${String(now.getHours() % 12 || 12).padStart(2, '0')}:${String(
          now.getMinutes()
        ).padStart(2, '0')} ${now.getHours() >= 12 ? 'PM' : 'AM'}`,
        details: `Checked out for the day`,
      };

      setLiveActivities((prev) => [activity, ...prev.slice(0, 24)]);
    },
    [currentEmployee, policy]
  );

  // Break controls
  const startBreak = useCallback(
    (type: 'lunch' | 'coffee' | 'personal') => {
      const now = new Date();
      const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(
        now.getMinutes()
      ).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
      const today = getTodayStr();

      setCheckInRecords((prev) =>
        prev.map((rec) => {
          if (rec.employeeId === currentEmployee.id && rec.date === today) {
            const newBreak = {
              id: `brk-${Date.now()}`,
              type,
              startTime: timeStr,
              durationMinutes: 0,
            };
            return {
              ...rec,
              breaks: [...rec.breaks, newBreak],
            };
          }
          return rec;
        })
      );

      const activity: LiveActivityFeedItem = {
        id: `act-${Date.now()}`,
        employeeId: currentEmployee.id,
        employeeName: currentEmployee.name,
        employeeAvatar: currentEmployee.avatar,
        action: 'start_break',
        timestamp: `${String(now.getHours() % 12 || 12).padStart(2, '0')}:${String(
          now.getMinutes()
        ).padStart(2, '0')} ${now.getHours() >= 12 ? 'PM' : 'AM'}`,
        details: `Started ${type} break`,
      };

      setLiveActivities((prev) => [activity, ...prev.slice(0, 24)]);
    },
    [currentEmployee]
  );

  const endBreak = useCallback(() => {
    const now = new Date();
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(
      now.getMinutes()
    ).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
    const today = getTodayStr();

    setCheckInRecords((prev) =>
      prev.map((rec) => {
        if (rec.employeeId === currentEmployee.id && rec.date === today) {
          let additionalBreakMinutes = 0;
          const updatedBreaks = rec.breaks.map((b) => {
            if (!b.endTime) {
              const dur = Math.max(1, Math.round((now.getTime() - new Date(`${today}T${b.startTime}`).getTime()) / 60000));
              additionalBreakMinutes += dur;
              return {
                ...b,
                endTime: timeStr,
                durationMinutes: dur,
              };
            }
            return b;
          });

          return {
            ...rec,
            breaks: updatedBreaks,
            totalBreakMinutes: rec.totalBreakMinutes + additionalBreakMinutes,
          };
        }
        return rec;
      })
    );

    const activity: LiveActivityFeedItem = {
      id: `act-${Date.now()}`,
      employeeId: currentEmployee.id,
      employeeName: currentEmployee.name,
      employeeAvatar: currentEmployee.avatar,
      action: 'end_break',
      timestamp: `${String(now.getHours() % 12 || 12).padStart(2, '0')}:${String(
        now.getMinutes()
      ).padStart(2, '0')} ${now.getHours() >= 12 ? 'PM' : 'AM'}`,
      details: `Resumed work from break`,
    };

    setLiveActivities((prev) => [activity, ...prev.slice(0, 24)]);
  }, [currentEmployee]);

  // Regularization Request Submission
  const submitRegularization = useCallback(
    (data: {
      date: string;
      originalCheckIn?: string;
      originalCheckOut?: string;
      requestedCheckIn: string;
      requestedCheckOut: string;
      reasonCategory: RegularizationReason;
      explanation: string;
      linkedCalendarEventId?: string;
      linkedCalendarEventTitle?: string;
      calendarProofSnippet?: string;
    }) => {
      // Check quota
      if (currentEmployee.regularizationsUsedThisMonth >= currentEmployee.regularizationQuota) {
        return {
          success: false,
          message: `Monthly regularization quota exceeded (${currentEmployee.regularizationQuota}/${currentEmployee.regularizationQuota} used). Please contact HR.`,
        };
      }

      // Check if auto-approved by calendar meeting verification policy
      const shouldAutoApprove =
        policy.autoApproveVerifiedCalendarMeetings &&
        Boolean(data.linkedCalendarEventId && data.reasonCategory === 'client_meeting');

      const reqId = `reg-${Date.now()}`;
      const now = new Date();
      const timeDisplay = `${String(now.getHours() % 12 || 12).padStart(2, '0')}:${String(
        now.getMinutes()
      ).padStart(2, '0')} ${now.getHours() >= 12 ? 'PM' : 'AM'}`;

      const newRequest: RegularizationRequest = {
        id: reqId,
        employeeId: currentEmployee.id,
        employeeName: currentEmployee.name,
        employeeAvatar: currentEmployee.avatar,
        date: data.date,
        originalCheckIn: data.originalCheckIn,
        originalCheckOut: data.originalCheckOut,
        requestedCheckIn: data.requestedCheckIn,
        requestedCheckOut: data.requestedCheckOut,
        reasonCategory: data.reasonCategory,
        explanation: data.explanation,
        linkedCalendarEventId: data.linkedCalendarEventId,
        linkedCalendarEventTitle: data.linkedCalendarEventTitle,
        calendarProofSnippet: data.calendarProofSnippet,
        status: shouldAutoApprove ? 'approved' : 'pending',
        submittedAt: `${data.date} ${timeDisplay}`,
        reviewedAt: shouldAutoApprove ? `${data.date} ${timeDisplay}` : undefined,
        reviewedBy: shouldAutoApprove ? 'System Policy Engine (Auto-Approved with Calendar Proof)' : undefined,
        reviewerNotes: shouldAutoApprove
          ? 'Auto-regularized: Confirmed client meeting verified on connected Google Calendar.'
          : undefined,
        autoRegularized: shouldAutoApprove,
      };

      setRegularizationRequests((prev) => [newRequest, ...prev]);

      // Update Employee quota count
      setEmployees((prev) =>
        prev.map((e) =>
          e.id === currentEmployee.id
            ? { ...e, regularizationsUsedThisMonth: e.regularizationsUsedThisMonth + 1 }
            : e
        )
      );

      // If auto-approved, immediately update the check-in record
      if (shouldAutoApprove) {
        setCheckInRecords((prev) =>
          prev.map((rec) => {
            if (rec.employeeId === currentEmployee.id && rec.date === data.date) {
              return {
                ...rec,
                checkInTime: `${data.requestedCheckIn}:00`,
                regularityStatus: 'regularized',
                flags: [
                  ...rec.flags.filter((f) => !f.toLowerCase().includes('late')),
                  `Regularized via Calendar Event: "${data.linkedCalendarEventTitle}"`,
                ],
                regularizationId: reqId,
              };
            }
            return rec;
          })
        );
      } else {
        // Mark as review_required / pending
        setCheckInRecords((prev) =>
          prev.map((rec) => {
            if (rec.employeeId === currentEmployee.id && rec.date === data.date) {
              return {
                ...rec,
                regularityStatus: 'review_required',
                flags: [...rec.flags, 'Attendance Regularization Request Pending Review'],
                regularizationId: reqId,
              };
            }
            return rec;
          })
        );
      }

      // Add to live activity
      const activity: LiveActivityFeedItem = {
        id: `act-${Date.now()}`,
        employeeId: currentEmployee.id,
        employeeName: currentEmployee.name,
        employeeAvatar: currentEmployee.avatar,
        action: shouldAutoApprove ? 'regularize_approved' : 'regularize_submitted',
        timestamp: timeDisplay,
        details: shouldAutoApprove
          ? `Attendance automatically regularized via Calendar Event (${data.linkedCalendarEventTitle})`
          : `Submitted attendance regularization for ${data.date} (${data.reasonCategory.replace('_', ' ')})`,
      };

      setLiveActivities((prev) => [activity, ...prev.slice(0, 24)]);

      return {
        success: true,
        message: shouldAutoApprove
          ? 'Attendance regularized automatically with verified calendar event evidence!'
          : 'Regularization request submitted to manager for review.',
        autoApproved: shouldAutoApprove,
      };
    },
    [currentEmployee, policy]
  );

  // Approve regularization
  const approveRegularization = useCallback(
    (requestId: string, reviewerNotes?: string) => {
      const now = new Date();
      const timeDisplay = `${now.getHours()}:${String(now.getMinutes()).padStart(2, '0')}`;

      let affectedReq: RegularizationRequest | undefined;

      setRegularizationRequests((prev) =>
        prev.map((req) => {
          if (req.id === requestId) {
            affectedReq = req;
            return {
              ...req,
              status: 'approved',
              reviewedAt: `${getTodayStr()} ${timeDisplay}`,
              reviewedBy: currentEmployee.name,
              reviewerNotes: reviewerNotes || 'Approved by Manager based on calendar verification.',
            };
          }
          return req;
        })
      );

      if (affectedReq) {
        const targetReq = affectedReq;
        setCheckInRecords((prev) =>
          prev.map((rec) => {
            if (rec.employeeId === targetReq.employeeId && rec.date === targetReq.date) {
              return {
                ...rec,
                checkInTime: `${targetReq.requestedCheckIn}:00`,
                regularityStatus: 'regularized',
                flags: [
                  ...rec.flags.filter((f) => !f.toLowerCase().includes('late') && !f.toLowerCase().includes('pending')),
                  `Regularized by ${currentEmployee.name} (${targetReq.reasonCategory})`,
                ],
                regularizationId: targetReq.id,
              };
            }
            return rec;
          })
        );

        const activity: LiveActivityFeedItem = {
          id: `act-${Date.now()}`,
          employeeId: targetReq.employeeId,
          employeeName: targetReq.employeeName,
          employeeAvatar: targetReq.employeeAvatar,
          action: 'regularize_approved',
          timestamp: timeDisplay,
          details: `Attendance regularized by manager ${currentEmployee.name} for ${targetReq.date}`,
        };
        setLiveActivities((prev) => [activity, ...prev.slice(0, 24)]);
      }
    },
    [currentEmployee]
  );

  // Reject regularization
  const rejectRegularization = useCallback(
    (requestId: string, reviewerNotes?: string) => {
      const now = new Date();
      const timeDisplay = `${now.getHours()}:${String(now.getMinutes()).padStart(2, '0')}`;

      setRegularizationRequests((prev) =>
        prev.map((req) => {
          if (req.id === requestId) {
            return {
              ...req,
              status: 'rejected',
              reviewedAt: `${getTodayStr()} ${timeDisplay}`,
              reviewedBy: currentEmployee.name,
              reviewerNotes: reviewerNotes || 'Regularization request could not be approved.',
            };
          }
          return req;
        })
      );
    },
    [currentEmployee]
  );

  // Add Calendar Event
  const addCalendarEvent = useCallback((eventData: Omit<CalendarEvent, 'id'>) => {
    const newEvent: CalendarEvent = {
      ...eventData,
      id: `cal-${Date.now()}`,
    };
    setCalendarEvents((prev) => [newEvent, ...prev]);
  }, []);

  // Sync / generate mock Google Calendar feed
  const syncGoogleCalendarFeed = useCallback(
    (employeeId: string) => {
      const today = getTodayStr();
      const newMockEvent: CalendarEvent = {
        id: `cal-gcal-${Date.now()}`,
        employeeId,
        title: 'Customer Advisory Council Q3 Briefing',
        description: 'Synchronized live from Google Calendar workspace',
        startTime: '13:30',
        endTime: '14:45',
        date: today,
        type: 'client_meeting',
        location: 'Google Meet (Enterprise HD)',
        isExternal: true,
        attendees: ['client.director@enterprise.com', 'advisor@gartner.com'],
        source: 'google_calendar',
      };
      setCalendarEvents((prev) => [...prev, newMockEvent]);
    },
    []
  );

  const updatePolicy = useCallback((newPolicy: Partial<AttendancePolicy>) => {
    setPolicy((prev) => ({ ...prev, ...newPolicy }));
  }, []);

  // HRMS 2x Daily Live Synchronization
  const syncHrmsDataNow = useCallback(async () => {
    const res = await fetchLiveHrmsData(appSettings.hrmsSyncSettings);
    if (res.records && res.records.length > 0) {
      setHrmsPunches(res.records);
    }
    const nowTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setAppSettings((prev) => ({
      ...prev,
      hrmsSyncSettings: {
        ...prev.hrmsSyncSettings,
        lastSyncTime: `Today at ${nowTime} IST`,
        lastSyncStatus: 'success',
        lastSyncMessage: `Synchronized ${res.records?.length || 0} biometric punch logs. Flagged missed punches and pending ARs.`,
      },
    }));
    return { success: true, message: `HRMS sync completed. Loaded ${res.records?.length || 0} punch records.` };
  }, [appSettings.hrmsSyncSettings]);

  // Autonomous Punch Regularization on Behalf of Employee
  const agentRegularizePunchOnBehalf = useCallback(
    async (caseId: string, inTime = '09:30', outTime = '18:30', reason = 'AI Agent Autonomous Regularization') => {
      const targetCase = followUpCases.find((c) => c.id === caseId);
      if (!targetCase) return { success: false, message: 'Case not found' };

      // Update follow-up case
      setFollowUpCases((prev) =>
        prev.map((c) => {
          if (c.id !== caseId) return c;
          return {
            ...c,
            status: 'pending-regularization',
            regularizedByAgent: true,
            autonomousActionTaken: `Autonomous Punch Regularization (${inTime} - ${outTime}) filed in HRMS`,
            selectedPunchReason: reason,
          };
        })
      );

      // Update HRMS punches table
      setHrmsPunches((prev) =>
        prev.map((p) => {
          if (p.employeeCode === targetCase.code || p.employeeName === targetCase.employeeName) {
            return {
              ...p,
              inTime,
              outTime,
              status: 'PR',
              arStatus: 'agent_regularized',
              notes: `Autonomous Regularization filed by AI Agent: ${reason}`,
            };
          }
          return p;
        })
      );

      return { success: true, message: `Autonomous regularization submitted for ${targetCase.employeeName}` };
    },
    [followUpCases]
  );

  // Admin Configuration Updaters
  const updateAiModelSettings = useCallback((settings: Partial<AiModelSettings>) => {
    setAppSettings((prev) => ({
      ...prev,
      aiModelSettings: { ...prev.aiModelSettings, ...settings },
    }));
  }, []);

  const updateHrmsSyncSettings = useCallback((settings: Partial<HrmsSyncSettings>) => {
    setAppSettings((prev) => ({
      ...prev,
      hrmsSyncSettings: { ...prev.hrmsSyncSettings, ...settings },
    }));
  }, []);

  const updateLiveKitSettings = useCallback((settings: Partial<LiveKitSettings>) => {
    setAppSettings((prev) => ({
      ...prev,
      livekitSettings: { ...prev.livekitSettings, ...settings },
    }));
  }, []);

  const updateMetaWhatsAppSettings = useCallback((settings: Partial<MetaWhatsAppSettings>) => {
    setAppSettings((prev) => ({
      ...prev,
      metaWhatsAppSettings: { ...prev.metaWhatsAppSettings, ...settings },
    }));
  }, []);

  const resetToDemoData = useCallback(() => {
    setEmployees(INITIAL_EMPLOYEES);
    setPolicy(INITIAL_POLICY);
    setCheckInRecords(createInitialCheckInRecords());
    setCalendarEvents(createInitialCalendarEvents());
    setRegularizationRequests(createInitialRegularizations());
    setLiveActivities(createInitialLiveActivity());
    setFollowUpCases(INITIAL_FOLLOW_UP_CASES);
    setAppSettings(INITIAL_APP_SETTINGS);
    setSelectedCaseId(INITIAL_FOLLOW_UP_CASES[0]?.id || null);
    setHrmsPunches(INITIAL_HRMS_PUNCH_RECORDS);
  }, []);

  return (
    <AttendanceContext.Provider
      value={{
        employees,
        currentEmployee,
        setCurrentEmployeeId,
        policy,
        updatePolicy,
        checkInRecords,
        calendarEvents,
        regularizationRequests,
        liveActivities,
        currentTime,
        todayRecord,
        checkIn,
        checkOut,
        startBreak,
        endBreak,
        submitRegularization,
        approveRegularization,
        rejectRegularization,
        addCalendarEvent,
        syncGoogleCalendarFeed,
        detectCalendarReconciliation,
        resetToDemoData,
        followUpCases,
        selectedCaseId,
        selectedCase,
        setSelectedCaseId,
        appSettings,
        updateAppSettings,
        sendFirstWhatsApp,
        logEmployeeReply,
        sendTwoDayReminder,
        logTwoDayReply,
        toggleCaseLanguage,
        triggerCall,
        logCallOutcome,
        markCaseVerified,
        importParsedCases,
        runDailyCheckForDate,
        autoTriggerLogs,
        runWorkflowAutoTrigger,
        clearAutoTriggerLogs,
        triggerPlivoCall,
        triggerPlivoManagerCall,
        processAgentResponse,
        managerNotifications,
        sendManagerWhatsApp,
        approveByManager,
        rejectByManager,
        hrmsPunches,
        syncHrmsDataNow,
        agentRegularizePunchOnBehalf,
        updateAiModelSettings,
        updateHrmsSyncSettings,
        updateLiveKitSettings,
        updateMetaWhatsAppSettings,
      }}
    >
      {children}
    </AttendanceContext.Provider>
  );
};

export const useAttendance = () => {
  const context = useContext(AttendanceContext);
  if (!context) {
    throw new Error('useAttendance must be used within an AttendanceProvider');
  }
  return context;
};
